﻿namespace CYCLE
{
    partial class AddAssigning
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.L_ID_Lable = new System.Windows.Forms.Label();
            this.StartTime_Lable = new System.Windows.Forms.Label();
            this.Topic_Lable = new System.Windows.Forms.Label();
            this.Status_Lable = new System.Windows.Forms.Label();
            this.L_ID_Input = new System.Windows.Forms.TextBox();
            this.AssStatus_Input = new System.Windows.Forms.ComboBox();
            this.StartTime_Input = new System.Windows.Forms.DateTimePicker();
            this.Ins_Lable = new System.Windows.Forms.Label();
            this.Back_Butt = new System.Windows.Forms.Button();
            this.Search_Butt = new System.Windows.Forms.Button();
            this.Add_Ass_Butt = new System.Windows.Forms.Button();
            this.Invalid_L_ID_Lable = new System.Windows.Forms.Label();
            this.Valid_L_ID_Lable = new System.Windows.Forms.Label();
            this.Search_Lecture_Butt = new System.Windows.Forms.Button();
            this.Invalid_Lecture_Lable = new System.Windows.Forms.Label();
            this.Topic_Input = new System.Windows.Forms.ComboBox();
            this.NewLectureQ_Label = new System.Windows.Forms.Label();
            this.NewLectureQ_Butt = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.AlreadyExist = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // L_ID_Lable
            // 
            this.L_ID_Lable.AutoSize = true;
            this.L_ID_Lable.BackColor = System.Drawing.Color.Transparent;
            this.L_ID_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.L_ID_Lable.Location = new System.Drawing.Point(84, 98);
            this.L_ID_Lable.Name = "L_ID_Lable";
            this.L_ID_Lable.Size = new System.Drawing.Size(105, 26);
            this.L_ID_Lable.TabIndex = 0;
            this.L_ID_Lable.Text = "Lecturer ID";
            // 
            // StartTime_Lable
            // 
            this.StartTime_Lable.AutoSize = true;
            this.StartTime_Lable.BackColor = System.Drawing.Color.Transparent;
            this.StartTime_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.StartTime_Lable.Location = new System.Drawing.Point(39, 265);
            this.StartTime_Lable.Name = "StartTime_Lable";
            this.StartTime_Lable.Size = new System.Drawing.Size(100, 26);
            this.StartTime_Lable.TabIndex = 1;
            this.StartTime_Lable.Text = "Start Time";
            // 
            // Topic_Lable
            // 
            this.Topic_Lable.AutoSize = true;
            this.Topic_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Topic_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Topic_Lable.Location = new System.Drawing.Point(39, 319);
            this.Topic_Lable.Name = "Topic_Lable";
            this.Topic_Lable.Size = new System.Drawing.Size(56, 26);
            this.Topic_Lable.TabIndex = 2;
            this.Topic_Lable.Text = "Topic";
            // 
            // Status_Lable
            // 
            this.Status_Lable.AutoSize = true;
            this.Status_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Status_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Status_Lable.Location = new System.Drawing.Point(39, 367);
            this.Status_Lable.Name = "Status_Lable";
            this.Status_Lable.Size = new System.Drawing.Size(150, 26);
            this.Status_Lable.TabIndex = 3;
            this.Status_Lable.Text = "Assigning Status";
            // 
            // L_ID_Input
            // 
            this.L_ID_Input.Location = new System.Drawing.Point(215, 99);
            this.L_ID_Input.Multiline = true;
            this.L_ID_Input.Name = "L_ID_Input";
            this.L_ID_Input.Size = new System.Drawing.Size(185, 25);
            this.L_ID_Input.TabIndex = 4;
            // 
            // AssStatus_Input
            // 
            this.AssStatus_Input.BackColor = System.Drawing.Color.White;
            this.AssStatus_Input.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AssStatus_Input.Font = new System.Drawing.Font("Calibri", 12F);
            this.AssStatus_Input.FormattingEnabled = true;
            this.AssStatus_Input.Location = new System.Drawing.Point(216, 365);
            this.AssStatus_Input.Name = "AssStatus_Input";
            this.AssStatus_Input.Size = new System.Drawing.Size(184, 27);
            this.AssStatus_Input.TabIndex = 6;
            // 
            // StartTime_Input
            // 
            this.StartTime_Input.CustomFormat = "dd/MM/yyyy HH:mm:ss";
            this.StartTime_Input.Font = new System.Drawing.Font("Calibri", 12F);
            this.StartTime_Input.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.StartTime_Input.Location = new System.Drawing.Point(215, 264);
            this.StartTime_Input.Name = "StartTime_Input";
            this.StartTime_Input.Size = new System.Drawing.Size(185, 27);
            this.StartTime_Input.TabIndex = 7;
            this.StartTime_Input.ValueChanged += new System.EventHandler(this.StartTime_Input_ValueChanged);
            // 
            // Ins_Lable
            // 
            this.Ins_Lable.AutoSize = true;
            this.Ins_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Ins_Lable.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.Ins_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Ins_Lable.Location = new System.Drawing.Point(190, 32);
            this.Ins_Lable.Name = "Ins_Lable";
            this.Ins_Lable.Size = new System.Drawing.Size(333, 29);
            this.Ins_Lable.TabIndex = 8;
            this.Ins_Lable.Text = "Please Insert The LecturerID";
            this.Ins_Lable.Click += new System.EventHandler(this.Ins_Lable_Click);
            // 
            // Back_Butt
            // 
            this.Back_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Back_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Back_Butt.ForeColor = System.Drawing.Color.White;
            this.Back_Butt.Location = new System.Drawing.Point(12, 540);
            this.Back_Butt.Name = "Back_Butt";
            this.Back_Butt.Size = new System.Drawing.Size(140, 68);
            this.Back_Butt.TabIndex = 9;
            this.Back_Butt.Text = "Back";
            this.Back_Butt.UseVisualStyleBackColor = false;
            this.Back_Butt.Click += new System.EventHandler(this.Back_Butt_Click);
            // 
            // Search_Butt
            // 
            this.Search_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Search_Butt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Search_Butt.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search_Butt.ForeColor = System.Drawing.Color.White;
            this.Search_Butt.Location = new System.Drawing.Point(438, 95);
            this.Search_Butt.Name = "Search_Butt";
            this.Search_Butt.Size = new System.Drawing.Size(128, 34);
            this.Search_Butt.TabIndex = 10;
            this.Search_Butt.Text = "Search";
            this.Search_Butt.UseVisualStyleBackColor = false;
            this.Search_Butt.Click += new System.EventHandler(this.Search_Butt_Click);
            // 
            // Add_Ass_Butt
            // 
            this.Add_Ass_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Add_Ass_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Add_Ass_Butt.ForeColor = System.Drawing.Color.White;
            this.Add_Ass_Butt.Location = new System.Drawing.Point(582, 540);
            this.Add_Ass_Butt.Name = "Add_Ass_Butt";
            this.Add_Ass_Butt.Size = new System.Drawing.Size(140, 68);
            this.Add_Ass_Butt.TabIndex = 11;
            this.Add_Ass_Butt.Text = "Add Optional Availability";
            this.Add_Ass_Butt.UseVisualStyleBackColor = false;
            this.Add_Ass_Butt.Click += new System.EventHandler(this.Add_Ass_Butt_Click);
            // 
            // Invalid_L_ID_Lable
            // 
            this.Invalid_L_ID_Lable.AutoSize = true;
            this.Invalid_L_ID_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Invalid_L_ID_Lable.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Invalid_L_ID_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Invalid_L_ID_Lable.Location = new System.Drawing.Point(191, 143);
            this.Invalid_L_ID_Lable.Name = "Invalid_L_ID_Lable";
            this.Invalid_L_ID_Lable.Size = new System.Drawing.Size(255, 23);
            this.Invalid_L_ID_Lable.TabIndex = 12;
            this.Invalid_L_ID_Lable.Text = "Please Insert A Valid Lecturer ID";
            // 
            // Valid_L_ID_Lable
            // 
            this.Valid_L_ID_Lable.AutoSize = true;
            this.Valid_L_ID_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Valid_L_ID_Lable.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Valid_L_ID_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Valid_L_ID_Lable.Location = new System.Drawing.Point(40, 210);
            this.Valid_L_ID_Lable.Name = "Valid_L_ID_Lable";
            this.Valid_L_ID_Lable.Size = new System.Drawing.Size(281, 26);
            this.Valid_L_ID_Lable.TabIndex = 13;
            this.Valid_L_ID_Lable.Text = "Please Insert The Following Info";
            // 
            // Search_Lecture_Butt
            // 
            this.Search_Lecture_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Search_Lecture_Butt.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Search_Lecture_Butt.ForeColor = System.Drawing.Color.White;
            this.Search_Lecture_Butt.Location = new System.Drawing.Point(453, 261);
            this.Search_Lecture_Butt.Name = "Search_Lecture_Butt";
            this.Search_Lecture_Butt.Size = new System.Drawing.Size(128, 34);
            this.Search_Lecture_Butt.TabIndex = 14;
            this.Search_Lecture_Butt.Text = "Search Lecture";
            this.Search_Lecture_Butt.UseVisualStyleBackColor = false;
            this.Search_Lecture_Butt.Click += new System.EventHandler(this.Search_Lecture_Butt_Click);
            // 
            // Invalid_Lecture_Lable
            // 
            this.Invalid_Lecture_Lable.AutoSize = true;
            this.Invalid_Lecture_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Invalid_Lecture_Lable.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Invalid_Lecture_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Invalid_Lecture_Lable.Location = new System.Drawing.Point(449, 298);
            this.Invalid_Lecture_Lable.Name = "Invalid_Lecture_Lable";
            this.Invalid_Lecture_Lable.Size = new System.Drawing.Size(189, 23);
            this.Invalid_Lecture_Lable.TabIndex = 15;
            this.Invalid_Lecture_Lable.Text = "Lecture Was Not Found";
            // 
            // Topic_Input
            // 
            this.Topic_Input.BackColor = System.Drawing.Color.White;
            this.Topic_Input.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Topic_Input.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Topic_Input.Font = new System.Drawing.Font("Calibri", 12F);
            this.Topic_Input.FormattingEnabled = true;
            this.Topic_Input.Location = new System.Drawing.Point(216, 317);
            this.Topic_Input.Name = "Topic_Input";
            this.Topic_Input.Size = new System.Drawing.Size(184, 27);
            this.Topic_Input.TabIndex = 16;
            // 
            // NewLectureQ_Label
            // 
            this.NewLectureQ_Label.AutoSize = true;
            this.NewLectureQ_Label.BackColor = System.Drawing.Color.Transparent;
            this.NewLectureQ_Label.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.NewLectureQ_Label.ForeColor = System.Drawing.Color.Navy;
            this.NewLectureQ_Label.Location = new System.Drawing.Point(437, 369);
            this.NewLectureQ_Label.Name = "NewLectureQ_Label";
            this.NewLectureQ_Label.Size = new System.Drawing.Size(278, 23);
            this.NewLectureQ_Label.TabIndex = 17;
            this.NewLectureQ_Label.Text = "Would you like to add new lecture?";
            // 
            // NewLectureQ_Butt
            // 
            this.NewLectureQ_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.NewLectureQ_Butt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.NewLectureQ_Butt.ForeColor = System.Drawing.Color.White;
            this.NewLectureQ_Butt.Location = new System.Drawing.Point(441, 395);
            this.NewLectureQ_Butt.Name = "NewLectureQ_Butt";
            this.NewLectureQ_Butt.Size = new System.Drawing.Size(103, 34);
            this.NewLectureQ_Butt.TabIndex = 18;
            this.NewLectureQ_Butt.Text = "Yes";
            this.NewLectureQ_Butt.UseVisualStyleBackColor = false;
            this.NewLectureQ_Butt.Click += new System.EventHandler(this.NewLectureQ_Butt_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            // 
            // AlreadyExist
            // 
            this.AlreadyExist.AutoSize = true;
            this.AlreadyExist.BackColor = System.Drawing.Color.Transparent;
            this.AlreadyExist.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.AlreadyExist.ForeColor = System.Drawing.Color.Navy;
            this.AlreadyExist.Location = new System.Drawing.Point(179, 437);
            this.AlreadyExist.Name = "AlreadyExist";
            this.AlreadyExist.Size = new System.Drawing.Size(238, 23);
            this.AlreadyExist.TabIndex = 23;
            this.AlreadyExist.Text = "This Assigning Is Already Exist";
            // 
            // AddAssigning
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.AlreadyExist);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.NewLectureQ_Butt);
            this.Controls.Add(this.NewLectureQ_Label);
            this.Controls.Add(this.Topic_Input);
            this.Controls.Add(this.Invalid_Lecture_Lable);
            this.Controls.Add(this.Search_Lecture_Butt);
            this.Controls.Add(this.Valid_L_ID_Lable);
            this.Controls.Add(this.Invalid_L_ID_Lable);
            this.Controls.Add(this.Add_Ass_Butt);
            this.Controls.Add(this.Search_Butt);
            this.Controls.Add(this.Back_Butt);
            this.Controls.Add(this.Ins_Lable);
            this.Controls.Add(this.StartTime_Input);
            this.Controls.Add(this.AssStatus_Input);
            this.Controls.Add(this.L_ID_Input);
            this.Controls.Add(this.Status_Lable);
            this.Controls.Add(this.Topic_Lable);
            this.Controls.Add(this.StartTime_Lable);
            this.Controls.Add(this.L_ID_Lable);
            this.Name = "AddAssigning";
            this.Text = "AddAssigning";
            this.Load += new System.EventHandler(this.AddAssigning_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label L_ID_Lable;
        private System.Windows.Forms.Label StartTime_Lable;
        private System.Windows.Forms.Label Topic_Lable;
        private System.Windows.Forms.Label Status_Lable;
        private System.Windows.Forms.TextBox L_ID_Input;
        private System.Windows.Forms.ComboBox AssStatus_Input;
        private System.Windows.Forms.DateTimePicker StartTime_Input;
        private System.Windows.Forms.Label Ins_Lable;
        private System.Windows.Forms.Button Back_Butt;
        private System.Windows.Forms.Button Search_Butt;
        private System.Windows.Forms.Button Add_Ass_Butt;
        private System.Windows.Forms.Label Invalid_L_ID_Lable;
        private System.Windows.Forms.Label Valid_L_ID_Lable;
        private System.Windows.Forms.Button Search_Lecture_Butt;
        private System.Windows.Forms.Label Invalid_Lecture_Lable;
        private System.Windows.Forms.ComboBox Topic_Input;
        private System.Windows.Forms.Label NewLectureQ_Label;
        private System.Windows.Forms.Button NewLectureQ_Butt;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label AlreadyExist;
    }
}