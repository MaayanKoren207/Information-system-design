﻿
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CYCLE
{
    public class Supplier
    {
        private string S_ID;
        private string SupplierName;
        private string SupplierAddress;
        private string ContactName;
        private string ContactPhoneNumber;
        private string ContactEmail;
        private string BankAccountInfo;
        public System.Collections.Generic.List<Product> Products;
        public System.Collections.Generic.List<Order> Orders;




        public Supplier(string S_ID, string SupplierName, string SupplierAddress, string ContactName, string ContactPhoneNumber, string ContactEmail, String BankAccountInfo, bool is_new)
        {
            this.S_ID = S_ID;
            this.SupplierName = SupplierName;
            this.SupplierAddress = SupplierAddress;
            this.ContactName = ContactName;
            this.ContactPhoneNumber = ContactPhoneNumber;
            this.ContactEmail = ContactEmail;
            this.BankAccountInfo = BankAccountInfo;
            if (is_new)
            {
                this.create_Supplier();
                Program.Suppliers.Add(this);

            }
        }


        public string get_ID()
        {
            return this.S_ID;
        }


        public string get_Name()
        {
            return this.SupplierName;
        }

        public string get_SupplierAddress()
        {
            return this.SupplierAddress;
        }

        public string get_ContactName()
        {
            return this.ContactName;
        }


        public string get_ContactPhoneNumber()
        {
            return this.ContactPhoneNumber;
        }

        public string get_ContactEmail()
        {
            return this.ContactEmail;
        }

        public string get_BankAccountInfo()
        {
            return this.BankAccountInfo;
        }

        public void set_FullName(string st)
        {
            this.SupplierName = st;

        }

        public void set_Address(string st)
        {
            this.SupplierAddress = st;
        }

        public void set_ContactFullName(string st)
        {
            this.ContactName = st;

        }

        public void set_ContactPhoneNumber(string st)
        {
            this.ContactPhoneNumber = st;

        }
        public void set_ContactEmail(string st)
        {
            this.ContactEmail = st;
        }

        public void set_BankAccountInfo(string st)
        {
            this.BankAccountInfo = st;
        }

       
        public System.Collections.Generic.List<Product> products // get and set for the whole list
        {
            get
            {
                if (Products == null)
                    Products = new System.Collections.Generic.List<Product>();
                return Products;
            }
            set
            {
                RemoveAllProducts();
                if (value != null)
                {
                    foreach (Product pProduct in value)
                        AddProducts(pProduct);
                }
            }
        }
       

        
        public void AddProducts(Product newProduct)
        {
            if (newProduct == null)
                return;
            if (this.Products == null)
                this.Products = new System.Collections.Generic.List<Product>();
            if (!this.Products.Contains(newProduct))
            {
                this.Products.Add(newProduct);
                newProduct.supplier = this;
            }
        }
        

        public void RemoveProducts(Product oldProduct)
        {
            if (oldProduct == null)
                return;
            if (this.products != null)
                if (this.products.Contains(oldProduct))
                {
                    this.products.Remove(oldProduct);
                    oldProduct.supplier = null;
                }
        }

        public void RemoveAllProducts()
        {
            if (products != null)
            {
                foreach (Product product in products)
                    product.supplier = null;
                products.Clear();
            }
        }
       

       
        public System.Collections.Generic.List<Order> orders // get and set for the whole list
        {
            get
            {
                if (Orders == null)
                    Orders = new System.Collections.Generic.List<Order>();
                return Orders;
            }
            set
            {
                RemoveAllOrders();
                if (value != null)
                {
                    foreach (Order oOrder in value)
                        AddOrders(oOrder);
                }
            }
        }



        public void AddOrders(Order newOrder)
        {
            if (newOrder == null)
                return;
            if (this.Orders == null)
                this.Orders = new System.Collections.Generic.List<Order>();
            if (!this.Orders.Contains(newOrder))
            {
                this.Orders.Add(newOrder);
                newOrder.Supplier = this;
            }
        }

        public void RemoveOrders(Order oldOrder)
        {
            if (oldOrder == null)
                return;
            if (this.Orders != null)
                if (this.Orders.Contains(oldOrder))
                {
                    this.Orders.Remove(oldOrder);
                    oldOrder.Supplier = null;
                }
        }

        public void RemoveAllOrders()
        {
            if (Orders != null)
            {
                foreach (Order order in Orders)
                    order.Supplier = null;
                Orders.Clear();
            }
        }
       

        public void create_Supplier()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_add_Supplier @S_ID, @SupplierName, @SupplierAddress, @ContactName, @ContactPhoneNumber, @ContactEmail, @BankAccountInfo";
            c.Parameters.AddWithValue("@S_ID", this.S_ID);
            c.Parameters.AddWithValue("@SupplierName", this.SupplierName);
            c.Parameters.AddWithValue("@SupplierAddress", this.SupplierAddress);
            c.Parameters.AddWithValue("@ContactName", this.ContactName);
            c.Parameters.AddWithValue("@ContactPhoneNumber", this.ContactPhoneNumber);
            c.Parameters.AddWithValue("@ContactEmail", this.ContactEmail);
            c.Parameters.AddWithValue("@BankAccountInfo", this.BankAccountInfo);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Update_Supplier()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_Update_Supplier @S_ID, @SupplierName, @SupplierAddress, @ContactName, @ContactPhoneNumber, @ContactEmail, @BankAccountInfo";
            c.Parameters.AddWithValue("@S_ID", this.S_ID);
            c.Parameters.AddWithValue("@SupplierName", this.SupplierName);
            c.Parameters.AddWithValue("@SupplierAddress", this.SupplierAddress);
            c.Parameters.AddWithValue("@ContactName", this.ContactName);
            c.Parameters.AddWithValue("@ContactPhoneNumber", this.ContactPhoneNumber);
            c.Parameters.AddWithValue("@ContactEmail", this.ContactEmail);
            c.Parameters.AddWithValue("@BankAccountInfo", this.BankAccountInfo);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Delete_Supplier()
        {
            Program.Suppliers.Remove(this);
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_delete_Supplier @S_ID";
            c.Parameters.AddWithValue("S_ID", this.S_ID);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }
        

    }

}



