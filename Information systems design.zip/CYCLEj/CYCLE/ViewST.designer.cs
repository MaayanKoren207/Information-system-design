﻿namespace CYCLE
{
    partial class ViewST
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CandidateID = new System.Windows.Forms.Label();
            this.Date = new System.Windows.Forms.Label();
            this.DateDisplay = new System.Windows.Forms.ComboBox();
            this.Cat1 = new System.Windows.Forms.Label();
            this.Cat2 = new System.Windows.Forms.Label();
            this.Cat3 = new System.Windows.Forms.Label();
            this.Cat4 = new System.Windows.Forms.Label();
            this.Cat5 = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.AverageScore = new System.Windows.Forms.Label();
            this.ChangeRateCalc = new System.Windows.Forms.Button();
            this.Percentage1 = new System.Windows.Forms.ComboBox();
            this.Prg1 = new System.Windows.Forms.Label();
            this.Prg2 = new System.Windows.Forms.Label();
            this.Percentage2 = new System.Windows.Forms.ComboBox();
            this.Prg3 = new System.Windows.Forms.Label();
            this.Percentage3 = new System.Windows.Forms.ComboBox();
            this.Prg4 = new System.Windows.Forms.Label();
            this.Percentage4 = new System.Windows.Forms.ComboBox();
            this.Prg5 = new System.Windows.Forms.Label();
            this.Percentage5 = new System.Windows.Forms.ComboBox();
            this.Calc = new System.Windows.Forms.Button();
            this.Prg_Error = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // CandidateID
            // 
            this.CandidateID.AutoSize = true;
            this.CandidateID.BackColor = System.Drawing.Color.Transparent;
            this.CandidateID.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Underline);
            this.CandidateID.ForeColor = System.Drawing.Color.Navy;
            this.CandidateID.Location = new System.Drawing.Point(240, 105);
            this.CandidateID.Name = "CandidateID";
            this.CandidateID.Size = new System.Drawing.Size(64, 26);
            this.CandidateID.TabIndex = 0;
            this.CandidateID.Text = "label1";
            // 
            // Date
            // 
            this.Date.AutoSize = true;
            this.Date.BackColor = System.Drawing.Color.Transparent;
            this.Date.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Date.Location = new System.Drawing.Point(227, 34);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(52, 26);
            this.Date.TabIndex = 1;
            this.Date.Text = "Date";
            // 
            // DateDisplay
            // 
            this.DateDisplay.Font = new System.Drawing.Font("Calibri", 12F);
            this.DateDisplay.FormattingEnabled = true;
            this.DateDisplay.Location = new System.Drawing.Point(285, 35);
            this.DateDisplay.Name = "DateDisplay";
            this.DateDisplay.Size = new System.Drawing.Size(121, 27);
            this.DateDisplay.TabIndex = 2;
            this.DateDisplay.SelectedIndexChanged += new System.EventHandler(this.DateDisplay_SelectedIndexChanged);
            // 
            // Cat1
            // 
            this.Cat1.AutoSize = true;
            this.Cat1.BackColor = System.Drawing.Color.Transparent;
            this.Cat1.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Cat1.Location = new System.Drawing.Point(249, 204);
            this.Cat1.Name = "Cat1";
            this.Cat1.Size = new System.Drawing.Size(64, 26);
            this.Cat1.TabIndex = 3;
            this.Cat1.Text = "label1";
            // 
            // Cat2
            // 
            this.Cat2.AutoSize = true;
            this.Cat2.BackColor = System.Drawing.Color.Transparent;
            this.Cat2.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Cat2.Location = new System.Drawing.Point(249, 261);
            this.Cat2.Name = "Cat2";
            this.Cat2.Size = new System.Drawing.Size(64, 26);
            this.Cat2.TabIndex = 4;
            this.Cat2.Text = "label1";
            // 
            // Cat3
            // 
            this.Cat3.AutoSize = true;
            this.Cat3.BackColor = System.Drawing.Color.Transparent;
            this.Cat3.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Cat3.Location = new System.Drawing.Point(249, 313);
            this.Cat3.Name = "Cat3";
            this.Cat3.Size = new System.Drawing.Size(64, 26);
            this.Cat3.TabIndex = 5;
            this.Cat3.Text = "label1";
            // 
            // Cat4
            // 
            this.Cat4.AutoSize = true;
            this.Cat4.BackColor = System.Drawing.Color.Transparent;
            this.Cat4.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Cat4.Location = new System.Drawing.Point(249, 366);
            this.Cat4.Name = "Cat4";
            this.Cat4.Size = new System.Drawing.Size(64, 26);
            this.Cat4.TabIndex = 6;
            this.Cat4.Text = "label1";
            // 
            // Cat5
            // 
            this.Cat5.AutoSize = true;
            this.Cat5.BackColor = System.Drawing.Color.Transparent;
            this.Cat5.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Cat5.Location = new System.Drawing.Point(249, 419);
            this.Cat5.Name = "Cat5";
            this.Cat5.Size = new System.Drawing.Size(64, 26);
            this.Cat5.TabIndex = 7;
            this.Cat5.Text = "label1";
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.BackButton.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.BackButton.ForeColor = System.Drawing.Color.White;
            this.BackButton.Location = new System.Drawing.Point(26, 531);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(140, 68);
            this.BackButton.TabIndex = 9;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // AverageScore
            // 
            this.AverageScore.AutoSize = true;
            this.AverageScore.BackColor = System.Drawing.Color.Transparent;
            this.AverageScore.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Underline);
            this.AverageScore.ForeColor = System.Drawing.Color.Navy;
            this.AverageScore.Location = new System.Drawing.Point(240, 146);
            this.AverageScore.Name = "AverageScore";
            this.AverageScore.Size = new System.Drawing.Size(64, 26);
            this.AverageScore.TabIndex = 10;
            this.AverageScore.Text = "label1";
            // 
            // ChangeRateCalc
            // 
            this.ChangeRateCalc.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.ChangeRateCalc.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.ChangeRateCalc.ForeColor = System.Drawing.Color.White;
            this.ChangeRateCalc.Location = new System.Drawing.Point(427, 531);
            this.ChangeRateCalc.Name = "ChangeRateCalc";
            this.ChangeRateCalc.Size = new System.Drawing.Size(140, 68);
            this.ChangeRateCalc.TabIndex = 24;
            this.ChangeRateCalc.Text = "Change Rate Calculation Metrics";
            this.ChangeRateCalc.UseVisualStyleBackColor = false;
            this.ChangeRateCalc.Click += new System.EventHandler(this.ChangeRateCalc_Click);
            // 
            // Percentage1
            // 
            this.Percentage1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Percentage1.FormattingEnabled = true;
            this.Percentage1.Location = new System.Drawing.Point(450, 209);
            this.Percentage1.Name = "Percentage1";
            this.Percentage1.Size = new System.Drawing.Size(55, 21);
            this.Percentage1.TabIndex = 25;
            // 
            // Prg1
            // 
            this.Prg1.AutoSize = true;
            this.Prg1.BackColor = System.Drawing.Color.Transparent;
            this.Prg1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Prg1.Location = new System.Drawing.Point(511, 209);
            this.Prg1.Name = "Prg1";
            this.Prg1.Size = new System.Drawing.Size(20, 19);
            this.Prg1.TabIndex = 26;
            this.Prg1.Text = "%";
            // 
            // Prg2
            // 
            this.Prg2.AutoSize = true;
            this.Prg2.BackColor = System.Drawing.Color.Transparent;
            this.Prg2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Prg2.Location = new System.Drawing.Point(511, 267);
            this.Prg2.Name = "Prg2";
            this.Prg2.Size = new System.Drawing.Size(20, 19);
            this.Prg2.TabIndex = 28;
            this.Prg2.Text = "%";
            // 
            // Percentage2
            // 
            this.Percentage2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Percentage2.FormattingEnabled = true;
            this.Percentage2.Location = new System.Drawing.Point(450, 267);
            this.Percentage2.Name = "Percentage2";
            this.Percentage2.Size = new System.Drawing.Size(55, 21);
            this.Percentage2.TabIndex = 27;
            // 
            // Prg3
            // 
            this.Prg3.AutoSize = true;
            this.Prg3.BackColor = System.Drawing.Color.Transparent;
            this.Prg3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Prg3.Location = new System.Drawing.Point(511, 313);
            this.Prg3.Name = "Prg3";
            this.Prg3.Size = new System.Drawing.Size(20, 19);
            this.Prg3.TabIndex = 30;
            this.Prg3.Text = "%";
            // 
            // Percentage3
            // 
            this.Percentage3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Percentage3.FormattingEnabled = true;
            this.Percentage3.Location = new System.Drawing.Point(450, 313);
            this.Percentage3.Name = "Percentage3";
            this.Percentage3.Size = new System.Drawing.Size(55, 21);
            this.Percentage3.TabIndex = 29;
            // 
            // Prg4
            // 
            this.Prg4.AutoSize = true;
            this.Prg4.BackColor = System.Drawing.Color.Transparent;
            this.Prg4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Prg4.Location = new System.Drawing.Point(511, 371);
            this.Prg4.Name = "Prg4";
            this.Prg4.Size = new System.Drawing.Size(20, 19);
            this.Prg4.TabIndex = 32;
            this.Prg4.Text = "%";
            // 
            // Percentage4
            // 
            this.Percentage4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Percentage4.FormattingEnabled = true;
            this.Percentage4.Location = new System.Drawing.Point(450, 371);
            this.Percentage4.Name = "Percentage4";
            this.Percentage4.Size = new System.Drawing.Size(55, 21);
            this.Percentage4.TabIndex = 31;
            // 
            // Prg5
            // 
            this.Prg5.AutoSize = true;
            this.Prg5.BackColor = System.Drawing.Color.Transparent;
            this.Prg5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Prg5.Location = new System.Drawing.Point(511, 424);
            this.Prg5.Name = "Prg5";
            this.Prg5.Size = new System.Drawing.Size(20, 19);
            this.Prg5.TabIndex = 34;
            this.Prg5.Text = "%";
            // 
            // Percentage5
            // 
            this.Percentage5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Percentage5.FormattingEnabled = true;
            this.Percentage5.Location = new System.Drawing.Point(450, 424);
            this.Percentage5.Name = "Percentage5";
            this.Percentage5.Size = new System.Drawing.Size(55, 21);
            this.Percentage5.TabIndex = 33;
            // 
            // Calc
            // 
            this.Calc.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Calc.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Calc.ForeColor = System.Drawing.Color.White;
            this.Calc.Location = new System.Drawing.Point(582, 531);
            this.Calc.Name = "Calc";
            this.Calc.Size = new System.Drawing.Size(140, 68);
            this.Calc.TabIndex = 35;
            this.Calc.Text = "Calculate New Average";
            this.Calc.UseVisualStyleBackColor = false;
            this.Calc.Click += new System.EventHandler(this.Calc_Click);
            // 
            // Prg_Error
            // 
            this.Prg_Error.AutoSize = true;
            this.Prg_Error.BackColor = System.Drawing.Color.Transparent;
            this.Prg_Error.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Prg_Error.ForeColor = System.Drawing.Color.Navy;
            this.Prg_Error.Location = new System.Drawing.Point(250, 470);
            this.Prg_Error.Name = "Prg_Error";
            this.Prg_Error.Size = new System.Drawing.Size(268, 23);
            this.Prg_Error.TabIndex = 36;
            this.Prg_Error.Text = "Total Percentage is not equal 100!";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 45;
            this.pictureBox2.TabStop = false;
            // 
            // ViewST
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Prg_Error);
            this.Controls.Add(this.Calc);
            this.Controls.Add(this.Prg5);
            this.Controls.Add(this.Percentage5);
            this.Controls.Add(this.Prg4);
            this.Controls.Add(this.Percentage4);
            this.Controls.Add(this.Prg3);
            this.Controls.Add(this.Percentage3);
            this.Controls.Add(this.Prg2);
            this.Controls.Add(this.Percentage2);
            this.Controls.Add(this.Prg1);
            this.Controls.Add(this.Percentage1);
            this.Controls.Add(this.ChangeRateCalc);
            this.Controls.Add(this.AverageScore);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.Cat5);
            this.Controls.Add(this.Cat4);
            this.Controls.Add(this.Cat3);
            this.Controls.Add(this.Cat2);
            this.Controls.Add(this.Cat1);
            this.Controls.Add(this.DateDisplay);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.CandidateID);
            this.Name = "ViewST";
            this.Text = "View Sorting Test";
            this.Load += new System.EventHandler(this.ViewST_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label CandidateID;
        private System.Windows.Forms.Label Date;
        private System.Windows.Forms.ComboBox DateDisplay;
        private System.Windows.Forms.Label Cat1;
        private System.Windows.Forms.Label Cat2;
        private System.Windows.Forms.Label Cat3;
        private System.Windows.Forms.Label Cat4;
        private System.Windows.Forms.Label Cat5;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label AverageScore;
        private System.Windows.Forms.Button ChangeRateCalc;
        private System.Windows.Forms.ComboBox Percentage1;
        private System.Windows.Forms.Label Prg1;
        private System.Windows.Forms.Label Prg2;
        private System.Windows.Forms.ComboBox Percentage2;
        private System.Windows.Forms.Label Prg3;
        private System.Windows.Forms.ComboBox Percentage3;
        private System.Windows.Forms.Label Prg4;
        private System.Windows.Forms.ComboBox Percentage4;
        private System.Windows.Forms.Label Prg5;
        private System.Windows.Forms.ComboBox Percentage5;
        private System.Windows.Forms.Button Calc;
        private System.Windows.Forms.Label Prg_Error;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}