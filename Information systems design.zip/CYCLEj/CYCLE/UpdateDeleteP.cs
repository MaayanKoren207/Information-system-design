﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace CYCLE
{
    public partial class UpdateP : Form
    {


        private Label P_SIDud;
        private Label P_IDud;
        private Label P_Nameud;
        private Label P_AmountUD;
        private Label P_PriceUD;
        private Label P_CategoryUD;
        private TextBox PSIDinputUD;
        private TextBox PNameInput;
        private TextBox P_AmountInputID;
        private TextBox P_priceUDinput;
        private Button P_BackUD;
        private Button P_Update;
        private Label P_Valid;
        private Label P_OKText;
        private Button P_ID_Search;
        private ComboBox PCategoryInputUD;

        public Supplier S_Exist { get; private set; }
        public Product P_Exist { get; private set; }

        public UpdateP()
        {
            InitializeComponent();
            PCategoryInputUD.DataSource = Enum.GetValues(typeof(ProductCategory));
            P_Valid.Hide();
            PNameInput.Hide();
            P_AmountInputID.Hide();
            P_priceUDinput.Hide();
            PCategoryInputUD.Hide();
            P_Nameud.Hide();
            P_AmountUD.Hide();
            P_PriceUD.Hide();
            P_CategoryUD.Hide();
            P_Update.Hide();
            label11.Hide();
            //P_Delete.Hide();
            P_IDinputUD1.Hide();
            P_IDud.Hide();
            Search_P_ID.Hide();
        }

        private void UpdateDeleteP_Load(object sender, EventArgs e)
        {

        }

        private void P_BackUD_Click(object sender, EventArgs e)
        {
            ProductCRUD pc = new ProductCRUD();
            pc.Show();
            this.Close();

        }

        private void UpdateDeleteP_Load_1(object sender, EventArgs e)
        {

        }

        private bool IsValidInput()
        {

            if (!Int32.TryParse(P_IDinputUD1.Text, out int Value) || !Int32.TryParse(s: P_AmountInputID.Text, result: out Value) || !Double.TryParse(P_priceUDinput.Text, out double value) || !Int32.TryParse(PSIDinputUD.Text, out Value))
            {
                return false; //Making sure ID, Price, Amount are all numbers
            }

            else if (P_IDinputUD1.Text == null || PNameInput.Text == null || P_AmountInputID.Text == null || P_priceUDinput.Text == null || PSIDinputUD.Text == null || PCategoryInputUD.SelectedIndex < 0)
            {
                return false; // Making sure no input is to stay null
            }

            else if (Regex.IsMatch(PNameInput.Text, @"^[a-zA-Z][a-z]*$") == false)
            {
                return false;// Making sure name containing only letters
            }

            else if (Double.TryParse(P_priceUDinput.Text, out value) && value < 0 || int.TryParse(P_IDinputUD1.Text, out Value) && Value < 0 || int.TryParse(PSIDinputUD.Text, out Value) && Value < 0 || int.TryParse(P_AmountInputID.Text, out Value) && Value < 0)
                return false;

            else
                return true;
        }

        private void P_Update_Click(object sender, EventArgs e)
        {
            if (IsValidInput())
            {
                P_Valid.Hide();
                P_Exist.set_ProductName(PNameInput.Text);
                P_Exist.set_Amount(int.Parse(P_AmountInputID.Text));
                P_Exist.set_Price(double.Parse(P_priceUDinput.Text));
                P_Exist.set_ProductCategory((ProductCategory)Enum.Parse(typeof(ProductCategory), PCategoryInputUD.SelectedItem.ToString()));
                P_Exist.Update_Product();
            }

            else
            {
                P_Valid.Show();
                if (P_Valid.Font.Size <= 20)
                    P_Valid.Font = new Font(P_Valid.Font.FontFamily, P_Valid.Font.Size + 1);
                else if (P_Valid.ForeColor == Color.Red)
                    P_Valid.ForeColor = Color.Gold;
                else
                    P_Valid.ForeColor = Color.Red;
            }

        }

        private void P_ID_Search_Click(object sender, EventArgs e)
        {
            P_IDinputUD1.Show();
            P_IDud.Show();
            Search_P_ID.Show();
        }

        private void P_Delete_Click(object sender, EventArgs e)
        {
            P_Exist.Delete_Product();
            ProductCRUD pc = new ProductCRUD();
            pc.Show();
            this.Close();
        }

        private void Search_P_ID_Click(object sender, EventArgs e)
        {
            
            S_Exist = Program.seekSupplier(PSIDinputUD.Text);
            P_Exist = Program.seekProduct(P_IDinputUD1.Text);
            if ((P_Exist != null) && (S_Exist != null))

            {
                PNameInput.Show();
                P_AmountInputID.Show();
                P_priceUDinput.Show();
                PCategoryInputUD.Show();
                P_Nameud.Show();
                P_AmountUD.Show();
                P_PriceUD.Show();
                P_CategoryUD.Show();
                P_Update.Show();
                label11.Show();
               // P_Delete.Show();
                P_Valid.Hide();
                PNameInput.Text = P_Exist.get_Name();
                P_AmountInputID.Text = P_Exist.get_CurrentNumOfUnits().ToString();
                P_priceUDinput.Text = P_Exist.get_PricePerUnit().ToString();
                PCategoryInputUD.Text = P_Exist.get_ProductCategory().ToString();

            }
            else
            {
                P_Valid.Show();
                PNameInput.Hide();
                P_AmountInputID.Hide();
                P_priceUDinput.Hide();
                PCategoryInputUD.Hide();
                P_Nameud.Hide();
                P_AmountUD.Hide();
                P_PriceUD.Hide();
                P_CategoryUD.Hide();
                P_Update.Hide();
                label11.Hide();
               // P_Delete.Hide();
            }
        }
    }


}
