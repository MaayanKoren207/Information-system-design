﻿namespace CYCLE
{
    partial class UpdateEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.E_Valid = new System.Windows.Forms.Label();
            this.E_OKText = new System.Windows.Forms.Label();
            this.E_IDInput = new System.Windows.Forms.TextBox();
            this.E_ID = new System.Windows.Forms.Label();
            this.E_FnameInput = new System.Windows.Forms.TextBox();
            this.E_FirstName = new System.Windows.Forms.Label();
            this.E_LnameInput = new System.Windows.Forms.TextBox();
            this.E_LastName = new System.Windows.Forms.Label();
            this.EU_EmployeeTypeInput = new System.Windows.Forms.ComboBox();
            this.EU_EmployeeType = new System.Windows.Forms.Label();
            this.EU_Email = new System.Windows.Forms.Label();
            this.EU_EmpolyeeInput = new System.Windows.Forms.TextBox();
            this.EU_PhoneNum = new System.Windows.Forms.Label();
            this.EU_PhoneNumInput = new System.Windows.Forms.TextBox();
            this.EU_StartingDate = new System.Windows.Forms.Label();
            this.dateTimePickerEmployeeU = new System.Windows.Forms.DateTimePicker();
            this.EU_Status = new System.Windows.Forms.Label();
            this.EU_StatusEnumInput = new System.Windows.Forms.ComboBox();
            this.E_Delete = new System.Windows.Forms.Button();
            this.E_Back = new System.Windows.Forms.Button();
            this.E_ID_Search = new System.Windows.Forms.Button();
            this.EU_Update = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // E_Valid
            // 
            this.E_Valid.AutoSize = true;
            this.E_Valid.BackColor = System.Drawing.Color.Transparent;
            this.E_Valid.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_Valid.ForeColor = System.Drawing.Color.Navy;
            this.E_Valid.Location = new System.Drawing.Point(104, 178);
            this.E_Valid.Name = "E_Valid";
            this.E_Valid.Size = new System.Drawing.Size(221, 26);
            this.E_Valid.TabIndex = 40;
            this.E_Valid.Text = "Please Insert valid input!";
            // 
            // E_OKText
            // 
            this.E_OKText.AutoSize = true;
            this.E_OKText.BackColor = System.Drawing.Color.Transparent;
            this.E_OKText.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.E_OKText.ForeColor = System.Drawing.Color.Navy;
            this.E_OKText.Location = new System.Drawing.Point(12, 62);
            this.E_OKText.Name = "E_OKText";
            this.E_OKText.Size = new System.Drawing.Size(372, 33);
            this.E_OKText.TabIndex = 41;
            this.E_OKText.Text = "Please Input A Valid Employee ID";
            // 
            // E_IDInput
            // 
            this.E_IDInput.Location = new System.Drawing.Point(151, 140);
            this.E_IDInput.Multiline = true;
            this.E_IDInput.Name = "E_IDInput";
            this.E_IDInput.Size = new System.Drawing.Size(185, 25);
            this.E_IDInput.TabIndex = 43;
            this.E_IDInput.TextChanged += new System.EventHandler(this.E_IDInput_TextChanged);
            // 
            // E_ID
            // 
            this.E_ID.AutoSize = true;
            this.E_ID.BackColor = System.Drawing.Color.Transparent;
            this.E_ID.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_ID.Location = new System.Drawing.Point(12, 139);
            this.E_ID.Name = "E_ID";
            this.E_ID.Size = new System.Drawing.Size(119, 26);
            this.E_ID.TabIndex = 44;
            this.E_ID.Text = "Employee ID";
            this.E_ID.Click += new System.EventHandler(this.E_ID_Click_1);
            // 
            // E_FnameInput
            // 
            this.E_FnameInput.Location = new System.Drawing.Point(151, 245);
            this.E_FnameInput.Multiline = true;
            this.E_FnameInput.Name = "E_FnameInput";
            this.E_FnameInput.Size = new System.Drawing.Size(185, 25);
            this.E_FnameInput.TabIndex = 45;
            // 
            // E_FirstName
            // 
            this.E_FirstName.AutoSize = true;
            this.E_FirstName.BackColor = System.Drawing.Color.Transparent;
            this.E_FirstName.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_FirstName.Location = new System.Drawing.Point(4, 243);
            this.E_FirstName.Name = "E_FirstName";
            this.E_FirstName.Size = new System.Drawing.Size(105, 26);
            this.E_FirstName.TabIndex = 46;
            this.E_FirstName.Text = "First Name";
            // 
            // E_LnameInput
            // 
            this.E_LnameInput.Location = new System.Drawing.Point(151, 297);
            this.E_LnameInput.Multiline = true;
            this.E_LnameInput.Name = "E_LnameInput";
            this.E_LnameInput.Size = new System.Drawing.Size(185, 25);
            this.E_LnameInput.TabIndex = 47;
            // 
            // E_LastName
            // 
            this.E_LastName.AutoSize = true;
            this.E_LastName.BackColor = System.Drawing.Color.Transparent;
            this.E_LastName.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_LastName.Location = new System.Drawing.Point(4, 296);
            this.E_LastName.Name = "E_LastName";
            this.E_LastName.Size = new System.Drawing.Size(102, 26);
            this.E_LastName.TabIndex = 48;
            this.E_LastName.Text = "Last Name";
            // 
            // EU_EmployeeTypeInput
            // 
            this.EU_EmployeeTypeInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EU_EmployeeTypeInput.Font = new System.Drawing.Font("Calibri", 12F);
            this.EU_EmployeeTypeInput.FormattingEnabled = true;
            this.EU_EmployeeTypeInput.Location = new System.Drawing.Point(151, 400);
            this.EU_EmployeeTypeInput.Name = "EU_EmployeeTypeInput";
            this.EU_EmployeeTypeInput.Size = new System.Drawing.Size(185, 27);
            this.EU_EmployeeTypeInput.TabIndex = 49;
            // 
            // EU_EmployeeType
            // 
            this.EU_EmployeeType.AutoSize = true;
            this.EU_EmployeeType.BackColor = System.Drawing.Color.Transparent;
            this.EU_EmployeeType.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.EU_EmployeeType.Location = new System.Drawing.Point(4, 401);
            this.EU_EmployeeType.Name = "EU_EmployeeType";
            this.EU_EmployeeType.Size = new System.Drawing.Size(141, 26);
            this.EU_EmployeeType.TabIndex = 50;
            this.EU_EmployeeType.Text = "Empolyee Type";
            // 
            // EU_Email
            // 
            this.EU_Email.AutoSize = true;
            this.EU_Email.BackColor = System.Drawing.Color.Transparent;
            this.EU_Email.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.EU_Email.Location = new System.Drawing.Point(384, 245);
            this.EU_Email.Name = "EU_Email";
            this.EU_Email.Size = new System.Drawing.Size(59, 26);
            this.EU_Email.TabIndex = 51;
            this.EU_Email.Text = "Email";
            this.EU_Email.Click += new System.EventHandler(this.EU_Email_Click);
            // 
            // EU_EmpolyeeInput
            // 
            this.EU_EmpolyeeInput.Location = new System.Drawing.Point(508, 244);
            this.EU_EmpolyeeInput.Multiline = true;
            this.EU_EmpolyeeInput.Name = "EU_EmpolyeeInput";
            this.EU_EmpolyeeInput.Size = new System.Drawing.Size(185, 25);
            this.EU_EmpolyeeInput.TabIndex = 52;
            this.EU_EmpolyeeInput.TextChanged += new System.EventHandler(this.EU_EmpolyeeInput_TextChanged);
            // 
            // EU_PhoneNum
            // 
            this.EU_PhoneNum.AutoSize = true;
            this.EU_PhoneNum.BackColor = System.Drawing.Color.Transparent;
            this.EU_PhoneNum.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.EU_PhoneNum.Location = new System.Drawing.Point(4, 349);
            this.EU_PhoneNum.Name = "EU_PhoneNum";
            this.EU_PhoneNum.Size = new System.Drawing.Size(141, 26);
            this.EU_PhoneNum.TabIndex = 53;
            this.EU_PhoneNum.Text = "Phone Number";
            this.EU_PhoneNum.Click += new System.EventHandler(this.EU_PhoneNum_Click);
            // 
            // EU_PhoneNumInput
            // 
            this.EU_PhoneNumInput.Location = new System.Drawing.Point(151, 351);
            this.EU_PhoneNumInput.Multiline = true;
            this.EU_PhoneNumInput.Name = "EU_PhoneNumInput";
            this.EU_PhoneNumInput.Size = new System.Drawing.Size(185, 25);
            this.EU_PhoneNumInput.TabIndex = 54;
            // 
            // EU_StartingDate
            // 
            this.EU_StartingDate.AutoSize = true;
            this.EU_StartingDate.BackColor = System.Drawing.Color.Transparent;
            this.EU_StartingDate.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.EU_StartingDate.Location = new System.Drawing.Point(384, 296);
            this.EU_StartingDate.Name = "EU_StartingDate";
            this.EU_StartingDate.Size = new System.Drawing.Size(117, 26);
            this.EU_StartingDate.TabIndex = 55;
            this.EU_StartingDate.Text = "Staring Date";
            this.EU_StartingDate.Click += new System.EventHandler(this.EU_StartingDate_Click);
            // 
            // dateTimePickerEmployeeU
            // 
            this.dateTimePickerEmployeeU.CustomFormat = "dd/MM/yyyy HH:mm:ss";
            this.dateTimePickerEmployeeU.Font = new System.Drawing.Font("Calibri", 12F);
            this.dateTimePickerEmployeeU.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerEmployeeU.Location = new System.Drawing.Point(507, 295);
            this.dateTimePickerEmployeeU.Name = "dateTimePickerEmployeeU";
            this.dateTimePickerEmployeeU.Size = new System.Drawing.Size(187, 27);
            this.dateTimePickerEmployeeU.TabIndex = 56;
            // 
            // EU_Status
            // 
            this.EU_Status.AutoSize = true;
            this.EU_Status.BackColor = System.Drawing.Color.Transparent;
            this.EU_Status.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.EU_Status.Location = new System.Drawing.Point(384, 345);
            this.EU_Status.Name = "EU_Status";
            this.EU_Status.Size = new System.Drawing.Size(65, 26);
            this.EU_Status.TabIndex = 57;
            this.EU_Status.Text = "Status";
            // 
            // EU_StatusEnumInput
            // 
            this.EU_StatusEnumInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EU_StatusEnumInput.Font = new System.Drawing.Font("Calibri", 12F);
            this.EU_StatusEnumInput.FormattingEnabled = true;
            this.EU_StatusEnumInput.Location = new System.Drawing.Point(507, 347);
            this.EU_StatusEnumInput.Name = "EU_StatusEnumInput";
            this.EU_StatusEnumInput.Size = new System.Drawing.Size(187, 27);
            this.EU_StatusEnumInput.TabIndex = 58;
            // 
            // E_Delete
            // 
            this.E_Delete.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.E_Delete.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_Delete.ForeColor = System.Drawing.Color.White;
            this.E_Delete.Location = new System.Drawing.Point(418, 531);
            this.E_Delete.Name = "E_Delete";
            this.E_Delete.Size = new System.Drawing.Size(140, 68);
            this.E_Delete.TabIndex = 59;
            this.E_Delete.Text = "Delete Employee";
            this.E_Delete.UseVisualStyleBackColor = false;
            this.E_Delete.Click += new System.EventHandler(this.E_Delete_Click);
            // 
            // E_Back
            // 
            this.E_Back.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.E_Back.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_Back.ForeColor = System.Drawing.Color.White;
            this.E_Back.Location = new System.Drawing.Point(9, 531);
            this.E_Back.Name = "E_Back";
            this.E_Back.Size = new System.Drawing.Size(140, 68);
            this.E_Back.TabIndex = 61;
            this.E_Back.Text = "Back";
            this.E_Back.UseVisualStyleBackColor = false;
            this.E_Back.Click += new System.EventHandler(this.E_Back_Click);
            // 
            // E_ID_Search
            // 
            this.E_ID_Search.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.E_ID_Search.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E_ID_Search.ForeColor = System.Drawing.Color.White;
            this.E_ID_Search.Location = new System.Drawing.Point(378, 140);
            this.E_ID_Search.Name = "E_ID_Search";
            this.E_ID_Search.Size = new System.Drawing.Size(106, 28);
            this.E_ID_Search.TabIndex = 62;
            this.E_ID_Search.Text = "Search";
            this.E_ID_Search.UseVisualStyleBackColor = false;
            this.E_ID_Search.Click += new System.EventHandler(this.E_ID_Search_Click);
            // 
            // EU_Update
            // 
            this.EU_Update.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.EU_Update.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.EU_Update.ForeColor = System.Drawing.Color.White;
            this.EU_Update.Location = new System.Drawing.Point(582, 531);
            this.EU_Update.Name = "EU_Update";
            this.EU_Update.Size = new System.Drawing.Size(140, 68);
            this.EU_Update.TabIndex = 63;
            this.EU_Update.Text = "Update Employee";
            this.EU_Update.UseVisualStyleBackColor = false;
            this.EU_Update.Click += new System.EventHandler(this.EU_Update_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 64;
            this.pictureBox2.TabStop = false;
            // 
            // UpdateEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.EU_Update);
            this.Controls.Add(this.E_ID_Search);
            this.Controls.Add(this.E_Back);
            this.Controls.Add(this.E_Delete);
            this.Controls.Add(this.EU_StatusEnumInput);
            this.Controls.Add(this.EU_Status);
            this.Controls.Add(this.dateTimePickerEmployeeU);
            this.Controls.Add(this.EU_StartingDate);
            this.Controls.Add(this.EU_PhoneNumInput);
            this.Controls.Add(this.EU_PhoneNum);
            this.Controls.Add(this.EU_EmpolyeeInput);
            this.Controls.Add(this.EU_Email);
            this.Controls.Add(this.EU_EmployeeType);
            this.Controls.Add(this.EU_EmployeeTypeInput);
            this.Controls.Add(this.E_LastName);
            this.Controls.Add(this.E_LnameInput);
            this.Controls.Add(this.E_FirstName);
            this.Controls.Add(this.E_FnameInput);
            this.Controls.Add(this.E_ID);
            this.Controls.Add(this.E_IDInput);
            this.Controls.Add(this.E_OKText);
            this.Controls.Add(this.E_Valid);
            this.Name = "UpdateEmployee";
            this.Text = "UpdateEmployee";
            this.Load += new System.EventHandler(this.UpdateEmployee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label E_Valid;
        private System.Windows.Forms.Label E_OKText;
        private System.Windows.Forms.TextBox E_IDInput;
        private System.Windows.Forms.Label E_ID;
        private System.Windows.Forms.TextBox E_FnameInput;
        private System.Windows.Forms.Label E_FirstName;
        private System.Windows.Forms.TextBox E_LnameInput;
        private System.Windows.Forms.Label E_LastName;
        private System.Windows.Forms.ComboBox EU_EmployeeTypeInput;
        private System.Windows.Forms.Label EU_EmployeeType;
        private System.Windows.Forms.Label EU_Email;
        private System.Windows.Forms.TextBox EU_EmpolyeeInput;
        private System.Windows.Forms.Label EU_PhoneNum;
        private System.Windows.Forms.TextBox EU_PhoneNumInput;
        private System.Windows.Forms.Label EU_StartingDate;
        private System.Windows.Forms.DateTimePicker dateTimePickerEmployeeU;
        private System.Windows.Forms.Label EU_Status;
        private System.Windows.Forms.ComboBox EU_StatusEnumInput;
        private System.Windows.Forms.Button E_Delete;
        private System.Windows.Forms.Button E_Back;
        private System.Windows.Forms.Button E_ID_Search;
        private System.Windows.Forms.Button EU_Update;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}