﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class ApprenticeCRUD : Form
    {
        public ApprenticeCRUD()
        {
            InitializeComponent();
        }

        private void To_A_Add_Click(object sender, EventArgs e)
        {
            AddApprentice add_A = new AddApprentice();
            add_A.Show();
            this.Hide();
        }

        private void ApprenticeCRUD_Load(object sender, EventArgs e)
        {

        }

        private void To_A_Update_Click(object sender, EventArgs e)
        {
            UpdateApprentice update_A = new UpdateApprentice();
            update_A.Show();
            this.Hide();
        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            HomePage hp = new HomePage();
            hp.Show();
            this.Hide();
        }
    }
}
