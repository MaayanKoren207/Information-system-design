﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
       
    public partial class UpdateSession : Form
    {
        private Session S_Exist;

        //S_SessionDate //S_Duration //Topic //S_Number //S_Location //S_IsCanceld
        //dateTimePickerSessionU //S_DurationInput .//S_TopicInput //S_NumberInput // SU_LocationEnumInput // Status_MeetingInput
        //S_delete //SU_Update

        public UpdateSession()
        {
            InitializeComponent();
            SU_LocationEnumInput.DataSource = Enum.GetValues(typeof(Location));
            SU_LocationEnumInput.SelectedIndex = -1;
            S_Valid.Hide();

            S_Duration.Hide();
            Topic.Hide();
            S_Number.Hide();
            S_Location.Hide();

            S_DurationInput.Hide();
            S_TopicInput.Hide();
            S_NumberInput.Hide();
            SU_LocationEnumInput.Hide();
            Status_MeetingInput.Hide();

            S_delete.Hide();
            SU_Update.Hide();
        }
        private void S_Session_Search_Click(object sender, EventArgs e)
        {            
            S_Exist = Program.seekSession(DateTime.Parse(dateTimePickerSessionU.Text));
            if (S_Exist != null)
            {
                S_FormatText.Hide();

                S_Duration.Show();
                Topic.Show();
                S_Number.Show();
                S_Location.Show();

                S_DurationInput.Show();
                S_TopicInput.Show();
                S_NumberInput.Show();
                SU_LocationEnumInput.Show();

                S_delete.Show();
                SU_Update.Show();
                
                S_DurationInput.Text = S_Exist.get_Duration().ToString();
                S_TopicInput.Text = S_Exist.get_Topic();
                S_NumberInput.Text = S_Exist.get_SessionNumber().ToString();
                SU_LocationEnumInput.Text = S_Exist.get_SessionLocation().ToString();
            }
            else
            {
                S_FormatText.Show();                
            }
        }

        private void S_delete_Click(object sender, EventArgs e)
        {
            S_Exist.set_IsCancelled(1); //Update Session status to cancelled; 
            SendMailToList(S_Exist, 0); 
        }

        private void S_Back_Click(object sender, EventArgs e)
        {
            SessionOptions ac = new SessionOptions();
            ac.Show();
            this.Hide();
        }
      
        private void SU_Update_Click(object sender, EventArgs e) 
        {
            if (IsValidInput())
            {
                S_Valid.Hide();
                S_Exist.set_Duration(int.Parse(S_DurationInput.Text));
                S_Exist.set_Topic(S_TopicInput.Text);
                S_Exist.set_SessionNumber(int.Parse(S_NumberInput.Text));
                S_Exist.set_SessionLocation((Location)Enum.Parse(typeof(Location), SU_LocationEnumInput.Text));
                S_Exist.set_IsCancelled(0); //Session wasn't cancelled 
                S_Exist.Update_Session();

                SendMailToList(S_Exist, 1);
            }
            else
            {
                S_Valid.Show();
                if (S_Valid.Font.Size <= 20)
                    S_Valid.Font = new Font(S_Valid.Font.FontFamily, S_Valid.Font.Size + 1);
                else if (S_Valid.ForeColor == Color.Red)
                    S_Valid.ForeColor = Color.Gold;
                else
                    S_Valid.ForeColor = Color.Red;
            }
        }

        private bool IsValidInput()
        {
            if (!Int32.TryParse(S_NumberInput.Text, out int Value) || !Int32.TryParse(S_DurationInput.Text, out Value))
                return false; //Making sure sessionNumber and durration is numbers

            else if (S_DurationInput.Text == null || S_TopicInput.Text == null || S_NumberInput.Text == null || Status_MeetingInput.Text == null || S_TopicInput.Text == null)
                return false; // Making sure no input is to stay null
   
            else
                return true;
        }

        private void SendMailToList(Session s, int i) // i=0 > cancle, i=1 > update
        {
            if (s != null)
            {
                string SessionDT = s.get_SessionDate().ToString();
                string SessionTopic = s.get_Topic();
                string SessionDuration = s.get_Duration().ToString();
                string SessionLoc = s.get_SessionLocation().ToString();

                string EmailSub;
                string[] EmailCont;
                EmailCont = new string[20];

                if (i == 1)  // Relocation Annoucement
                {
                    EmailSub = "Cycle Session Update Annoucement";

                    EmailCont[0] = "Hello, ";
                    EmailCont[1] = "We would like to inform you that an update has occured in the session that is planned to be on the " + SessionDT + " at " + SessionLoc + ".";
                    EmailCont[2] = "The session will last " + SessionDuration + " minutes.";
                    EmailCont[3] = "Thank you,";
                    EmailCont[4] = "Cycle Team";
                }
                else // Cancelation Annoucement
                {
                    EmailSub = "Cycle Session Cancelation Annoucement";

                    EmailCont[0] = "Hello, ";
                    EmailCont[1] = "We would like to inform you that the session that was scheduled on " + SessionDT + "was canceled.";
                    EmailCont[2] = "We will contact you soon to re-schedule your planned lecture.";
                    EmailCont[3] = "Thank you for the understanding,";
                    EmailCont[4] = "Cycle Team";
                }
                
                SendEmailToList sendMail = new SendEmailToList(EmailSub, EmailCont);
                sendMail.Owner = this;
                sendMail.Show();
                this.Hide();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void UpdateSession_Load(object sender, EventArgs e)
        {

        }

        private void E_FnameInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void S_durationInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void SU_LocationEnumInput_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePickerSessionU_ValueChanged(object sender, EventArgs e)
        {

        }

        private void S_Numbrt_Click(object sender, EventArgs e)
        {

        }

       

        private void SU_LocationEnumInput_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

       
        private void S_Valid_Click(object sender, EventArgs e)
        {

        }

        private void Mail_Click(object sender, EventArgs e)
        {
            /*
            if (S_Exist != null)
            {
                string SessionDT = S_Exist.get_SessionDate().ToString();
                string SessionTopic = S_Exist.get_Topic();
                string SessionDuration = S_Exist.get_Duration().ToString();
                string SessionLoc = S_Exist.get_SessionLocation().ToString();
                
                SendMail sendMail = new SendMail();
                sendMail.Show();
                this.Hide();
            }
            */
            }
        }
}
