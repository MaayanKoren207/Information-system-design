﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;

namespace CYCLE
{
    public partial class SendMail : Form
    {
        public SendMail()
        {
            InitializeComponent();
        }

        public SendMail(string email)
        {
            InitializeComponent();
            Send_To.Text = email;
        }

        public SendMail(string email, string sub, string[] contArr)
        {
            InitializeComponent();

            Send_To.Text = email;
            Subject_Input.Text = sub;
            ContentInput.Lines = contArr;

        }


        private void Subject_Click(object sender, EventArgs e)
        {

        }

        private void Send_To_TextChanged(object sender, EventArgs e)
        {

        }

        private void Subject_Input_TextChanged(object sender, EventArgs e)
        {

        }

        private void ContentInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void To_text_Click(object sender, EventArgs e)
        {

        }

        private void content_Click(object sender, EventArgs e)
        {

        }

        private void Send_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    //inputUsers
                    string to = Send_To.Text;
                    string subject = Subject_Input.Text;
                    string body = ContentInput.Text;

                    // Set up the SMTP client
                    SmtpClient CycleMail = new SmtpClient();
                    CycleMail.Port = 587;
                    CycleMail.Host = "smtp.gmail.com";
                    CycleMail.EnableSsl = true;
                    CycleMail.Timeout = 10000;
                    CycleMail.DeliveryMethod = SmtpDeliveryMethod.Network;
                    CycleMail.UseDefaultCredentials = false;
                    CycleMail.Credentials = new NetworkCredential("groupcycle29@gmail.com", "yuaxacmcvdnnvved");

                    // Create the message
                    MailMessage message = new MailMessage("groupcycle29@gmail.com", to, subject, body);
                    message.BodyEncoding = UTF8Encoding.UTF8;
                    message.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
                    // Send the email
                    CycleMail.Send(message);

                    // Show a success message
                    MessageBox.Show("Email sent successfully!");
                }
                catch (Exception ex)
                {
                    // Show an error message
                    MessageBox.Show("Error: " + ex.Message);
                }

            }
        }

        private void back_Click(object sender, EventArgs e)
        {
            FindLecturerForAssigning FIFA = new FindLecturerForAssigning();
            FIFA.Show();
            this.Close();
        }

        private void SendMail_Load(object sender, EventArgs e)
        {

        }

        private void mail_Text_Click(object sender, EventArgs e)
        {

        }
    }
}
