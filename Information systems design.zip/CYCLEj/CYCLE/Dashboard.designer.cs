﻿namespace CYCLE
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.Select_Filters = new System.Windows.Forms.Label();
            this.StartDate = new System.Windows.Forms.Label();
            this.FinishDate = new System.Windows.Forms.Label();
            this.GroupBySuppliers = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.SortBySuppliersAnswer = new System.Windows.Forms.CheckBox();
            this.SortByStatusAnswer = new System.Windows.Forms.CheckBox();
            this.DashboardTitle = new System.Windows.Forms.Label();
            this.Produce = new System.Windows.Forms.Button();
            this.saD_29DataSet1 = new CYCLE.SAD_29DataSet();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.HideChart_Butt = new System.Windows.Forms.Button();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.ProductsDashboard = new System.Windows.Forms.Button();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.HideChart1_Butt = new System.Windows.Forms.Button();
            this.Hide_Chart3_Butt = new System.Windows.Forms.Button();
            this.Back_Butt = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.saD_29DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            this.SuspendLayout();
            // 
            // Select_Filters
            // 
            this.Select_Filters.AutoSize = true;
            this.Select_Filters.ForeColor = System.Drawing.Color.DimGray;
            this.Select_Filters.Location = new System.Drawing.Point(489, 70);
            this.Select_Filters.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Select_Filters.Name = "Select_Filters";
            this.Select_Filters.Size = new System.Drawing.Size(93, 17);
            this.Select_Filters.TabIndex = 1;
            this.Select_Filters.Text = "Select Filters:";
            // 
            // StartDate
            // 
            this.StartDate.AutoSize = true;
            this.StartDate.BackColor = System.Drawing.Color.Transparent;
            this.StartDate.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StartDate.Location = new System.Drawing.Point(316, 116);
            this.StartDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.StartDate.Name = "StartDate";
            this.StartDate.Size = new System.Drawing.Size(87, 23);
            this.StartDate.TabIndex = 2;
            this.StartDate.Text = "Start Date";
            this.StartDate.Click += new System.EventHandler(this.StartDate_Click);
            // 
            // FinishDate
            // 
            this.FinishDate.AutoSize = true;
            this.FinishDate.BackColor = System.Drawing.Color.Transparent;
            this.FinishDate.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.FinishDate.Location = new System.Drawing.Point(313, 161);
            this.FinishDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.FinishDate.Name = "FinishDate";
            this.FinishDate.Size = new System.Drawing.Size(95, 23);
            this.FinishDate.TabIndex = 3;
            this.FinishDate.Text = "Finish Date";
            this.FinishDate.Click += new System.EventHandler(this.FinishDate_Click);
            // 
            // GroupBySuppliers
            // 
            this.GroupBySuppliers.AutoSize = true;
            this.GroupBySuppliers.BackColor = System.Drawing.Color.Transparent;
            this.GroupBySuppliers.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.GroupBySuppliers.Location = new System.Drawing.Point(315, 196);
            this.GroupBySuppliers.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.GroupBySuppliers.Name = "GroupBySuppliers";
            this.GroupBySuppliers.Size = new System.Drawing.Size(132, 23);
            this.GroupBySuppliers.TabIndex = 4;
            this.GroupBySuppliers.Text = "Sort By Supplier";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.label1.Location = new System.Drawing.Point(316, 225);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(203, 23);
            this.label1.TabIndex = 5;
            this.label1.Text = "Sort By Product Category";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(432, 117);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(265, 23);
            this.dateTimePicker1.TabIndex = 6;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(432, 161);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(265, 23);
            this.dateTimePicker2.TabIndex = 8;
            this.dateTimePicker2.ValueChanged += new System.EventHandler(this.dateTimePicker2_ValueChanged);
            // 
            // SortBySuppliersAnswer
            // 
            this.SortBySuppliersAnswer.AutoSize = true;
            this.SortBySuppliersAnswer.BackColor = System.Drawing.Color.White;
            this.SortBySuppliersAnswer.Location = new System.Drawing.Point(537, 196);
            this.SortBySuppliersAnswer.Margin = new System.Windows.Forms.Padding(4);
            this.SortBySuppliersAnswer.Name = "SortBySuppliersAnswer";
            this.SortBySuppliersAnswer.Size = new System.Drawing.Size(51, 21);
            this.SortBySuppliersAnswer.TabIndex = 9;
            this.SortBySuppliersAnswer.Text = "Yes";
            this.SortBySuppliersAnswer.UseVisualStyleBackColor = false;
            // 
            // SortByStatusAnswer
            // 
            this.SortByStatusAnswer.AutoSize = true;
            this.SortByStatusAnswer.BackColor = System.Drawing.Color.White;
            this.SortByStatusAnswer.Location = new System.Drawing.Point(537, 225);
            this.SortByStatusAnswer.Margin = new System.Windows.Forms.Padding(4);
            this.SortByStatusAnswer.Name = "SortByStatusAnswer";
            this.SortByStatusAnswer.Size = new System.Drawing.Size(51, 21);
            this.SortByStatusAnswer.TabIndex = 10;
            this.SortByStatusAnswer.Text = "Yes";
            this.SortByStatusAnswer.UseVisualStyleBackColor = false;
            // 
            // DashboardTitle
            // 
            this.DashboardTitle.AutoSize = true;
            this.DashboardTitle.BackColor = System.Drawing.Color.Indigo;
            this.DashboardTitle.Font = new System.Drawing.Font("Adobe Fan Heiti Std B", 36F, System.Drawing.FontStyle.Bold);
            this.DashboardTitle.ForeColor = System.Drawing.SystemColors.Control;
            this.DashboardTitle.Location = new System.Drawing.Point(422, 28);
            this.DashboardTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.DashboardTitle.Name = "DashboardTitle";
            this.DashboardTitle.Size = new System.Drawing.Size(310, 60);
            this.DashboardTitle.TabIndex = 11;
            this.DashboardTitle.Text = "DASHBOARD";
            this.DashboardTitle.Click += new System.EventHandler(this.DashboardTitle_Click);
            // 
            // Produce
            // 
            this.Produce.BackColor = System.Drawing.Color.Indigo;
            this.Produce.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Produce.ForeColor = System.Drawing.Color.White;
            this.Produce.Location = new System.Drawing.Point(941, 28);
            this.Produce.Margin = new System.Windows.Forms.Padding(4);
            this.Produce.Name = "Produce";
            this.Produce.Size = new System.Drawing.Size(204, 94);
            this.Produce.TabIndex = 12;
            this.Produce.Text = "Produce Budget Dashboard";
            this.Produce.UseVisualStyleBackColor = false;
            this.Produce.Click += new System.EventHandler(this.Produce_Click);
            // 
            // saD_29DataSet1
            // 
            this.saD_29DataSet1.DataSetName = "SAD_29DataSet";
            this.saD_29DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // chart2
            // 
            this.chart2.BackColor = System.Drawing.Color.Transparent;
            this.chart2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.chart2.BackImageWrapMode = System.Windows.Forms.DataVisualization.Charting.ChartImageWrapMode.Unscaled;
            chartArea1.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart2.Legends.Add(legend1);
            this.chart2.Location = new System.Drawing.Point(13, 595);
            this.chart2.Margin = new System.Windows.Forms.Padding(4);
            this.chart2.Name = "chart2";
            this.chart2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Order Per Month";
            this.chart2.Series.Add(series1);
            this.chart2.Size = new System.Drawing.Size(1147, 395);
            this.chart2.TabIndex = 16;
            this.chart2.Text = "chart2";
            // 
            // HideChart_Butt
            // 
            this.HideChart_Butt.BackColor = System.Drawing.Color.Indigo;
            this.HideChart_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.HideChart_Butt.ForeColor = System.Drawing.Color.White;
            this.HideChart_Butt.Location = new System.Drawing.Point(46, 37);
            this.HideChart_Butt.Margin = new System.Windows.Forms.Padding(4);
            this.HideChart_Butt.Name = "HideChart_Butt";
            this.HideChart_Butt.Size = new System.Drawing.Size(177, 39);
            this.HideChart_Butt.TabIndex = 17;
            this.HideChart_Butt.Text = "Hide Chart";
            this.HideChart_Butt.UseVisualStyleBackColor = false;
            this.HideChart_Butt.Click += new System.EventHandler(this.HideChart_Butt_Click);
            // 
            // chart1
            // 
            chartArea2.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea2);
            this.chart1.Cursor = System.Windows.Forms.Cursors.IBeam;
            legend2.Name = "Legend1";
            this.chart1.Legends.Add(legend2);
            this.chart1.Location = new System.Drawing.Point(627, 269);
            this.chart1.Margin = new System.Windows.Forms.Padding(4);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(545, 318);
            this.chart1.TabIndex = 18;
            this.chart1.Text = "chart1";
            // 
            // ProductsDashboard
            // 
            this.ProductsDashboard.BackColor = System.Drawing.Color.Indigo;
            this.ProductsDashboard.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.ProductsDashboard.ForeColor = System.Drawing.Color.White;
            this.ProductsDashboard.Location = new System.Drawing.Point(941, 138);
            this.ProductsDashboard.Margin = new System.Windows.Forms.Padding(4);
            this.ProductsDashboard.Name = "ProductsDashboard";
            this.ProductsDashboard.Size = new System.Drawing.Size(204, 94);
            this.ProductsDashboard.TabIndex = 19;
            this.ProductsDashboard.Text = "Produce Products Dashboard";
            this.ProductsDashboard.UseVisualStyleBackColor = false;
            this.ProductsDashboard.Click += new System.EventHandler(this.ProductsDashboard_Click);
            // 
            // chart3
            // 
            chartArea3.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.chart3.Legends.Add(legend3);
            this.chart3.Location = new System.Drawing.Point(39, 269);
            this.chart3.Margin = new System.Windows.Forms.Padding(4);
            this.chart3.Name = "chart3";
            this.chart3.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SeaGreen;
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            this.chart3.Series.Add(series3);
            this.chart3.Size = new System.Drawing.Size(543, 318);
            this.chart3.TabIndex = 20;
            this.chart3.Text = "chart3";
            // 
            // HideChart1_Butt
            // 
            this.HideChart1_Butt.BackColor = System.Drawing.Color.Indigo;
            this.HideChart1_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.HideChart1_Butt.ForeColor = System.Drawing.Color.White;
            this.HideChart1_Butt.Location = new System.Drawing.Point(46, 167);
            this.HideChart1_Butt.Margin = new System.Windows.Forms.Padding(4);
            this.HideChart1_Butt.Name = "HideChart1_Butt";
            this.HideChart1_Butt.Size = new System.Drawing.Size(177, 39);
            this.HideChart1_Butt.TabIndex = 21;
            this.HideChart1_Butt.Text = "Hide Chart";
            this.HideChart1_Butt.UseVisualStyleBackColor = false;
            this.HideChart1_Butt.Click += new System.EventHandler(this.HideChart1_Butt_Click_1);
            // 
            // Hide_Chart3_Butt
            // 
            this.Hide_Chart3_Butt.BackColor = System.Drawing.Color.Indigo;
            this.Hide_Chart3_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Hide_Chart3_Butt.ForeColor = System.Drawing.Color.White;
            this.Hide_Chart3_Butt.Location = new System.Drawing.Point(46, 101);
            this.Hide_Chart3_Butt.Margin = new System.Windows.Forms.Padding(4);
            this.Hide_Chart3_Butt.Name = "Hide_Chart3_Butt";
            this.Hide_Chart3_Butt.Size = new System.Drawing.Size(177, 39);
            this.Hide_Chart3_Butt.TabIndex = 22;
            this.Hide_Chart3_Butt.Text = "Hide Chart";
            this.Hide_Chart3_Butt.UseVisualStyleBackColor = false;
            this.Hide_Chart3_Butt.Click += new System.EventHandler(this.Hide_Chart3_Butt_Click);
            // 
            // Back_Butt
            // 
            this.Back_Butt.BackColor = System.Drawing.Color.Indigo;
            this.Back_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Back_Butt.ForeColor = System.Drawing.Color.White;
            this.Back_Butt.Location = new System.Drawing.Point(13, 981);
            this.Back_Butt.Name = "Back_Butt";
            this.Back_Butt.Size = new System.Drawing.Size(140, 68);
            this.Back_Butt.TabIndex = 23;
            this.Back_Butt.Text = "back";
            this.Back_Butt.UseVisualStyleBackColor = false;
            this.Back_Butt.Click += new System.EventHandler(this.Back_Butt_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1195, 1061);
            this.Controls.Add(this.Back_Butt);
            this.Controls.Add(this.Hide_Chart3_Butt);
            this.Controls.Add(this.HideChart1_Butt);
            this.Controls.Add(this.chart3);
            this.Controls.Add(this.ProductsDashboard);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.HideChart_Butt);
            this.Controls.Add(this.chart2);
            this.Controls.Add(this.Produce);
            this.Controls.Add(this.DashboardTitle);
            this.Controls.Add(this.SortByStatusAnswer);
            this.Controls.Add(this.SortBySuppliersAnswer);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GroupBySuppliers);
            this.Controls.Add(this.FinishDate);
            this.Controls.Add(this.StartDate);
            this.Controls.Add(this.Select_Filters);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Dashboard";
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.Dashboard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.saD_29DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label Select_Filters;
        private System.Windows.Forms.Label StartDate;
        private System.Windows.Forms.Label FinishDate;
        private System.Windows.Forms.Label GroupBySuppliers;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.CheckBox SortBySuppliersAnswer;
        private System.Windows.Forms.CheckBox SortByStatusAnswer;
        private System.Windows.Forms.Label DashboardTitle;
        private SAD_29DataSet saD_29DataSet1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.Button HideChart_Butt;
        private System.Windows.Forms.Button Produce;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Button ProductsDashboard;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private System.Windows.Forms.Button HideChart1_Butt;
        private System.Windows.Forms.Button Hide_Chart3_Butt;
        private System.Windows.Forms.Button Back_Butt;
    }
}