﻿namespace CYCLE
{
    partial class ProductCRUD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.To_P_Update = new System.Windows.Forms.Button();
            this.To_P_Add = new System.Windows.Forms.Button();
            this.Back_Butt = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Lectures = new System.Windows.Forms.Label();
            this.Products = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // To_P_Update
            // 
            this.To_P_Update.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.To_P_Update.Font = new System.Drawing.Font("Calibri", 18F);
            this.To_P_Update.ForeColor = System.Drawing.Color.White;
            this.To_P_Update.Location = new System.Drawing.Point(89, 321);
            this.To_P_Update.Name = "To_P_Update";
            this.To_P_Update.Size = new System.Drawing.Size(218, 95);
            this.To_P_Update.TabIndex = 0;
            this.To_P_Update.Text = "Update/Delete Product";
            this.To_P_Update.UseVisualStyleBackColor = false;
            this.To_P_Update.Click += new System.EventHandler(this.To_P_Update_Click);
            // 
            // To_P_Add
            // 
            this.To_P_Add.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.To_P_Add.Font = new System.Drawing.Font("Calibri", 18F);
            this.To_P_Add.ForeColor = System.Drawing.Color.White;
            this.To_P_Add.Location = new System.Drawing.Point(419, 321);
            this.To_P_Add.Name = "To_P_Add";
            this.To_P_Add.Size = new System.Drawing.Size(218, 95);
            this.To_P_Add.TabIndex = 1;
            this.To_P_Add.Text = "Add Product";
            this.To_P_Add.UseVisualStyleBackColor = false;
            this.To_P_Add.Click += new System.EventHandler(this.To_P_Add_Click_1);
            // 
            // Back_Butt
            // 
            this.Back_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Back_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Back_Butt.ForeColor = System.Drawing.Color.White;
            this.Back_Butt.Location = new System.Drawing.Point(12, 531);
            this.Back_Butt.Name = "Back_Butt";
            this.Back_Butt.Size = new System.Drawing.Size(140, 68);
            this.Back_Butt.TabIndex = 2;
            this.Back_Butt.Text = "Back";
            this.Back_Butt.UseVisualStyleBackColor = false;
            this.Back_Butt.Click += new System.EventHandler(this.Back_Butt_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 24;
            this.pictureBox2.TabStop = false;
            // 
            // Lectures
            // 
            this.Lectures.AutoSize = true;
            this.Lectures.BackColor = System.Drawing.Color.Transparent;
            this.Lectures.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lectures.ForeColor = System.Drawing.Color.Navy;
            this.Lectures.Location = new System.Drawing.Point(273, 276);
            this.Lectures.Name = "Lectures";
            this.Lectures.Size = new System.Drawing.Size(0, 59);
            this.Lectures.TabIndex = 47;
            // 
            // Products
            // 
            this.Products.AutoSize = true;
            this.Products.BackColor = System.Drawing.Color.Transparent;
            this.Products.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Products.ForeColor = System.Drawing.Color.Navy;
            this.Products.Location = new System.Drawing.Point(283, 151);
            this.Products.Name = "Products";
            this.Products.Size = new System.Drawing.Size(196, 59);
            this.Products.TabIndex = 48;
            this.Products.Text = "Products";
            // 
            // ProductCRUD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.Products);
            this.Controls.Add(this.Lectures);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Back_Butt);
            this.Controls.Add(this.To_P_Add);
            this.Controls.Add(this.To_P_Update);
            this.Name = "ProductCRUD";
            this.Text = "ProductCRUD";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button To_P_Update;
        private System.Windows.Forms.Button To_P_Add;
        private System.Windows.Forms.Button Back_Butt;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Lectures;
        private System.Windows.Forms.Label Products;
    }
}