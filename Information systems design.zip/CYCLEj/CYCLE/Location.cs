﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CYCLE
{
    public enum Location

    {
        [Description("Harman Israel")] HarmanIsrael,
        [Description("Hubstare Hod Hasharon")] HubstareHodHasharon,
        [Description("Park Raanana")] ParkRaanana
    }

}

