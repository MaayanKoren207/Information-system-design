﻿namespace CYCLE
{
    partial class AddST
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.CandidateID = new System.Windows.Forms.Label();
            this.Date = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.AverageScore = new System.Windows.Forms.Label();
            this.CatRate1 = new System.Windows.Forms.ComboBox();
            this.CatRate2 = new System.Windows.Forms.ComboBox();
            this.CatRate3 = new System.Windows.Forms.ComboBox();
            this.CatRate4 = new System.Windows.Forms.ComboBox();
            this.CatRate5 = new System.Windows.Forms.ComboBox();
            this.AddButton = new System.Windows.Forms.Button();
            this.Cat1 = new System.Windows.Forms.ComboBox();
            this.Cat2 = new System.Windows.Forms.ComboBox();
            this.Cat3 = new System.Windows.Forms.ComboBox();
            this.Cat4 = new System.Windows.Forms.ComboBox();
            this.Cat5 = new System.Windows.Forms.ComboBox();
            this.Warning = new System.Windows.Forms.Label();
            this.DateTimeInput = new System.Windows.Forms.DateTimePicker();
            this.Datetimewarning = new System.Windows.Forms.Label();
            this.EmptyWarning = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // CandidateID
            // 
            this.CandidateID.AutoSize = true;
            this.CandidateID.BackColor = System.Drawing.Color.Transparent;
            this.CandidateID.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CandidateID.ForeColor = System.Drawing.Color.Indigo;
            this.CandidateID.Location = new System.Drawing.Point(23, 153);
            this.CandidateID.Name = "CandidateID";
            this.CandidateID.Size = new System.Drawing.Size(64, 26);
            this.CandidateID.TabIndex = 0;
            this.CandidateID.Text = "label1";
            // 
            // Date
            // 
            this.Date.AutoSize = true;
            this.Date.BackColor = System.Drawing.Color.Transparent;
            this.Date.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Date.Location = new System.Drawing.Point(227, 30);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(52, 26);
            this.Date.TabIndex = 1;
            this.Date.Text = "Date";
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.BackButton.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.BackButton.ForeColor = System.Drawing.Color.White;
            this.BackButton.Location = new System.Drawing.Point(12, 536);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(140, 68);
            this.BackButton.TabIndex = 9;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // AverageScore
            // 
            this.AverageScore.AutoSize = true;
            this.AverageScore.BackColor = System.Drawing.Color.Transparent;
            this.AverageScore.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AverageScore.ForeColor = System.Drawing.Color.Indigo;
            this.AverageScore.Location = new System.Drawing.Point(93, 153);
            this.AverageScore.Name = "AverageScore";
            this.AverageScore.Size = new System.Drawing.Size(64, 26);
            this.AverageScore.TabIndex = 10;
            this.AverageScore.Text = "label1";
            // 
            // CatRate1
            // 
            this.CatRate1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CatRate1.Font = new System.Drawing.Font("Calibri", 12F);
            this.CatRate1.FormattingEnabled = true;
            this.CatRate1.Items.AddRange(new object[] {
            "1.0",
            "2.0",
            "3.0",
            "4.0",
            "5.0"});
            this.CatRate1.Location = new System.Drawing.Point(427, 232);
            this.CatRate1.Name = "CatRate1";
            this.CatRate1.Size = new System.Drawing.Size(67, 27);
            this.CatRate1.TabIndex = 11;
            // 
            // CatRate2
            // 
            this.CatRate2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CatRate2.Font = new System.Drawing.Font("Calibri", 12F);
            this.CatRate2.FormattingEnabled = true;
            this.CatRate2.Items.AddRange(new object[] {
            "1.0",
            "2.0",
            "3.0",
            "4.0",
            "5.0"});
            this.CatRate2.Location = new System.Drawing.Point(427, 295);
            this.CatRate2.Name = "CatRate2";
            this.CatRate2.Size = new System.Drawing.Size(67, 27);
            this.CatRate2.TabIndex = 12;
            // 
            // CatRate3
            // 
            this.CatRate3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CatRate3.Font = new System.Drawing.Font("Calibri", 12F);
            this.CatRate3.FormattingEnabled = true;
            this.CatRate3.Items.AddRange(new object[] {
            "1.0",
            "2.0",
            "3.0",
            "4.0",
            "5.0"});
            this.CatRate3.Location = new System.Drawing.Point(427, 352);
            this.CatRate3.Name = "CatRate3";
            this.CatRate3.Size = new System.Drawing.Size(67, 27);
            this.CatRate3.TabIndex = 13;
            // 
            // CatRate4
            // 
            this.CatRate4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CatRate4.Font = new System.Drawing.Font("Calibri", 12F);
            this.CatRate4.FormattingEnabled = true;
            this.CatRate4.Items.AddRange(new object[] {
            "1.0",
            "2.0",
            "3.0",
            "4.0",
            "5.0"});
            this.CatRate4.Location = new System.Drawing.Point(427, 406);
            this.CatRate4.Name = "CatRate4";
            this.CatRate4.Size = new System.Drawing.Size(67, 27);
            this.CatRate4.TabIndex = 14;
            // 
            // CatRate5
            // 
            this.CatRate5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CatRate5.Font = new System.Drawing.Font("Calibri", 12F);
            this.CatRate5.FormattingEnabled = true;
            this.CatRate5.Items.AddRange(new object[] {
            "1.0",
            "2.0",
            "3.0",
            "4.0",
            "5.0"});
            this.CatRate5.Location = new System.Drawing.Point(427, 460);
            this.CatRate5.Name = "CatRate5";
            this.CatRate5.Size = new System.Drawing.Size(67, 27);
            this.CatRate5.TabIndex = 15;
            // 
            // AddButton
            // 
            this.AddButton.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.AddButton.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.AddButton.ForeColor = System.Drawing.Color.White;
            this.AddButton.Location = new System.Drawing.Point(576, 536);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(140, 68);
            this.AddButton.TabIndex = 18;
            this.AddButton.Text = "Add";
            this.AddButton.UseVisualStyleBackColor = false;
            this.AddButton.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // Cat1
            // 
            this.Cat1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cat1.Font = new System.Drawing.Font("Calibri", 12F);
            this.Cat1.FormattingEnabled = true;
            this.Cat1.Location = new System.Drawing.Point(207, 232);
            this.Cat1.Name = "Cat1";
            this.Cat1.Size = new System.Drawing.Size(176, 27);
            this.Cat1.TabIndex = 20;
            // 
            // Cat2
            // 
            this.Cat2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cat2.Font = new System.Drawing.Font("Calibri", 12F);
            this.Cat2.FormattingEnabled = true;
            this.Cat2.Location = new System.Drawing.Point(207, 295);
            this.Cat2.Name = "Cat2";
            this.Cat2.Size = new System.Drawing.Size(176, 27);
            this.Cat2.TabIndex = 21;
            // 
            // Cat3
            // 
            this.Cat3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cat3.Font = new System.Drawing.Font("Calibri", 12F);
            this.Cat3.FormattingEnabled = true;
            this.Cat3.Location = new System.Drawing.Point(207, 352);
            this.Cat3.Name = "Cat3";
            this.Cat3.Size = new System.Drawing.Size(176, 27);
            this.Cat3.TabIndex = 22;
            // 
            // Cat4
            // 
            this.Cat4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cat4.Font = new System.Drawing.Font("Calibri", 12F);
            this.Cat4.FormattingEnabled = true;
            this.Cat4.Location = new System.Drawing.Point(207, 406);
            this.Cat4.Name = "Cat4";
            this.Cat4.Size = new System.Drawing.Size(176, 27);
            this.Cat4.TabIndex = 23;
            // 
            // Cat5
            // 
            this.Cat5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cat5.Font = new System.Drawing.Font("Calibri", 12F);
            this.Cat5.FormattingEnabled = true;
            this.Cat5.Location = new System.Drawing.Point(207, 460);
            this.Cat5.Name = "Cat5";
            this.Cat5.Size = new System.Drawing.Size(176, 27);
            this.Cat5.TabIndex = 24;
            // 
            // Warning
            // 
            this.Warning.AutoSize = true;
            this.Warning.BackColor = System.Drawing.Color.Transparent;
            this.Warning.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.Warning.ForeColor = System.Drawing.Color.Navy;
            this.Warning.Location = new System.Drawing.Point(39, 111);
            this.Warning.Name = "Warning";
            this.Warning.Size = new System.Drawing.Size(625, 33);
            this.Warning.TabIndex = 25;
            this.Warning.Text = "Please make sure to use each sorting category only once";
            // 
            // DateTimeInput
            // 
            this.DateTimeInput.CustomFormat = "dd/MM/yyyy HH:mm:ss";
            this.DateTimeInput.Font = new System.Drawing.Font("Calibri", 12F);
            this.DateTimeInput.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DateTimeInput.Location = new System.Drawing.Point(285, 30);
            this.DateTimeInput.Name = "DateTimeInput";
            this.DateTimeInput.Size = new System.Drawing.Size(185, 27);
            this.DateTimeInput.TabIndex = 27;
            // 
            // Datetimewarning
            // 
            this.Datetimewarning.AutoSize = true;
            this.Datetimewarning.BackColor = System.Drawing.Color.Transparent;
            this.Datetimewarning.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Datetimewarning.ForeColor = System.Drawing.Color.Navy;
            this.Datetimewarning.Location = new System.Drawing.Point(212, 60);
            this.Datetimewarning.Name = "Datetimewarning";
            this.Datetimewarning.Size = new System.Drawing.Size(303, 23);
            this.Datetimewarning.TabIndex = 28;
            this.Datetimewarning.Text = "Sorting test already exist for this time!";
            // 
            // EmptyWarning
            // 
            this.EmptyWarning.AutoSize = true;
            this.EmptyWarning.BackColor = System.Drawing.Color.Transparent;
            this.EmptyWarning.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.EmptyWarning.ForeColor = System.Drawing.Color.Navy;
            this.EmptyWarning.Location = new System.Drawing.Point(305, 510);
            this.EmptyWarning.Name = "EmptyWarning";
            this.EmptyWarning.Size = new System.Drawing.Size(153, 23);
            this.EmptyWarning.TabIndex = 29;
            this.EmptyWarning.Text = "Please fill all fields!";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(628, 7);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 42;
            this.pictureBox2.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.label10.ForeColor = System.Drawing.Color.Navy;
            this.label10.Location = new System.Drawing.Point(252, 206);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 23);
            this.label10.TabIndex = 43;
            this.label10.Text = "Category";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(439, 206);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 23);
            this.label1.TabIndex = 44;
            this.label1.Text = "Rate";
            // 
            // AddST
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.EmptyWarning);
            this.Controls.Add(this.Datetimewarning);
            this.Controls.Add(this.DateTimeInput);
            this.Controls.Add(this.Warning);
            this.Controls.Add(this.Cat5);
            this.Controls.Add(this.Cat4);
            this.Controls.Add(this.Cat3);
            this.Controls.Add(this.Cat2);
            this.Controls.Add(this.Cat1);
            this.Controls.Add(this.AddButton);
            this.Controls.Add(this.CatRate5);
            this.Controls.Add(this.CatRate4);
            this.Controls.Add(this.CatRate3);
            this.Controls.Add(this.CatRate2);
            this.Controls.Add(this.CatRate1);
            this.Controls.Add(this.AverageScore);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.CandidateID);
            this.Name = "AddST";
            this.Text = "Add Sorting Test";
            this.Load += new System.EventHandler(this.AddST_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }



        private System.Windows.Forms.Label CandidateID;
        private System.Windows.Forms.Label Date;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label AverageScore;
        private System.Windows.Forms.ComboBox CatRate1;
        private System.Windows.Forms.ComboBox CatRate2;
        private System.Windows.Forms.ComboBox CatRate3;
        private System.Windows.Forms.ComboBox CatRate4;
        private System.Windows.Forms.ComboBox CatRate5;
        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.ComboBox Cat1;
        private System.Windows.Forms.ComboBox Cat2;
        private System.Windows.Forms.ComboBox Cat3;
        private System.Windows.Forms.ComboBox Cat4;
        private System.Windows.Forms.ComboBox Cat5;
        private System.Windows.Forms.Label Warning;
        private System.Windows.Forms.DateTimePicker DateTimeInput;
        private System.Windows.Forms.Label Datetimewarning;
        private System.Windows.Forms.Label EmptyWarning;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
    }
}