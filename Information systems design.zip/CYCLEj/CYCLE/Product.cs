﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CYCLE
{

   
    public class Product
    {
        public Supplier supplier;
        
        private string P_ID;
        private string ProductName;
        private int CurrentNumOfUnits;
        private double PricePerUnit;
        private ProductCategory ProductCategory;
        


        public Product(Supplier s, string P_ID, string ProductName, int CurrentNumOfUnits, double PricePerUnit, ProductCategory ProductCategory, bool is_new)
        {
            
            this.Supplier = s;
            this.P_ID = P_ID;
            this.ProductName = ProductName;
            this.CurrentNumOfUnits = CurrentNumOfUnits;
            this.PricePerUnit = PricePerUnit;
            this.ProductCategory = ProductCategory;
            if (is_new)
            {
                this.create_Product();
                s.AddProducts(this); 
                Program.Products.Add(this);
            }
        }




        public string get_ID()
        {
            return this.P_ID;
        }


        public string get_Name()
        {
            return this.ProductName;
        }

        public int get_CurrentNumOfUnits()
        {
            return this.CurrentNumOfUnits;
        }

        public double get_PricePerUnit()
        {
            return this.PricePerUnit;
        }

        public ProductCategory get_ProductCategory()
        {
            return this.ProductCategory;
        }

        public void set_ProductName(string st)
        {
            this.ProductName = st;

        }

        public void set_PID(string st)
        {
            this.P_ID = st;

        }

        public void set_Amount(int n)
        {
            this.CurrentNumOfUnits = n;

        }

        public void set_Price(double n)
        {
            this.PricePerUnit = n;

        }

        public void set_ProductCategory(ProductCategory p)
        {
             this.ProductCategory = p;
        }

        public Supplier Supplier 
        {
            get
            {
                return supplier;
            }
            set
            {
                if (this.supplier == null || !this.supplier.Equals(value))
                {
                    if (this.supplier != null) 
                    {
                        Supplier oldSupplier = this.supplier;
                        this.supplier = null;
                        oldSupplier.RemoveProducts(this);
                    }
                    if (value != null)
                    {
                        this.supplier = value;
                        this.supplier.AddProducts(this);
                    }
                }
            }
        }
        

        public void create_Product()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_add_Product @S_ID, @P_ID, @ProductName, @CurrentNumOfUnits, @PricePerUnit, @ProductCategory";
            c.Parameters.AddWithValue("@S_ID", this.supplier.get_ID());
            c.Parameters.AddWithValue("@P_ID", this.P_ID);
            c.Parameters.AddWithValue("@ProductName", this.ProductName);
            c.Parameters.AddWithValue("@CurrentNumOfUnits", this.CurrentNumOfUnits);
            c.Parameters.AddWithValue("@PricePerUnit", this.PricePerUnit);
            c.Parameters.AddWithValue("@ProductCategory", this.ProductCategory.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Update_Product()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_Update_Product @S_ID, @P_ID, @ProductName, @CurrentNumOfUnits, @PricePerUnit, @ProductCategory";
            c.Parameters.AddWithValue("@S_ID", this.supplier.get_ID());
            c.Parameters.AddWithValue("@P_ID", this.P_ID);
            c.Parameters.AddWithValue("@ProductName", this.ProductName);
            c.Parameters.AddWithValue("@CurrentNumOfUnits", this.CurrentNumOfUnits);
            c.Parameters.AddWithValue("@PricePerUnit", this.PricePerUnit);
            c.Parameters.AddWithValue("@ProductCategory", this.ProductCategory.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Delete_Product()
        {
            Program.Products.Remove(this);
            
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_delete_Product @P_ID";
            c.Parameters.AddWithValue("P_ID", this.P_ID);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

    }
    
}


