﻿namespace CYCLE
{
    partial class SortingTestCRUD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ID_Input = new System.Windows.Forms.TextBox();
            this.ST_Add = new System.Windows.Forms.Button();
            this.ST_View = new System.Windows.Forms.Button();
            this.ST_Edit = new System.Windows.Forms.Button();
            this.Warning = new System.Windows.Forms.Label();
            this.Back_Butt = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.SortingTest = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // ID_Input
            // 
            this.ID_Input.Location = new System.Drawing.Point(283, 284);
            this.ID_Input.Multiline = true;
            this.ID_Input.Name = "ID_Input";
            this.ID_Input.Size = new System.Drawing.Size(185, 27);
            this.ID_Input.TabIndex = 0;
            this.ID_Input.TextChanged += new System.EventHandler(this.ID_Input_TextChanged);
            // 
            // ST_Add
            // 
            this.ST_Add.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.ST_Add.Font = new System.Drawing.Font("Calibri", 18F);
            this.ST_Add.ForeColor = System.Drawing.Color.White;
            this.ST_Add.Location = new System.Drawing.Point(496, 327);
            this.ST_Add.Name = "ST_Add";
            this.ST_Add.Size = new System.Drawing.Size(218, 95);
            this.ST_Add.TabIndex = 1;
            this.ST_Add.Text = "Add Sorting Test";
            this.ST_Add.UseVisualStyleBackColor = false;
            this.ST_Add.Click += new System.EventHandler(this.ST_Add_Click);
            // 
            // ST_View
            // 
            this.ST_View.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.ST_View.Font = new System.Drawing.Font("Calibri", 18F);
            this.ST_View.ForeColor = System.Drawing.Color.White;
            this.ST_View.Location = new System.Drawing.Point(267, 327);
            this.ST_View.Name = "ST_View";
            this.ST_View.Size = new System.Drawing.Size(218, 95);
            this.ST_View.TabIndex = 2;
            this.ST_View.Text = "View Sorting Test";
            this.ST_View.UseVisualStyleBackColor = false;
            this.ST_View.Click += new System.EventHandler(this.ST_View_Click);
            // 
            // ST_Edit
            // 
            this.ST_Edit.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.ST_Edit.Font = new System.Drawing.Font("Calibri", 18F);
            this.ST_Edit.ForeColor = System.Drawing.Color.White;
            this.ST_Edit.Location = new System.Drawing.Point(38, 327);
            this.ST_Edit.Name = "ST_Edit";
            this.ST_Edit.Size = new System.Drawing.Size(218, 95);
            this.ST_Edit.TabIndex = 3;
            this.ST_Edit.Text = "Edit Sorting Test";
            this.ST_Edit.UseVisualStyleBackColor = false;
            this.ST_Edit.Click += new System.EventHandler(this.ST_Edit_Click);
            // 
            // Warning
            // 
            this.Warning.AutoSize = true;
            this.Warning.BackColor = System.Drawing.Color.Transparent;
            this.Warning.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Warning.ForeColor = System.Drawing.Color.Navy;
            this.Warning.Location = new System.Drawing.Point(267, 252);
            this.Warning.Name = "Warning";
            this.Warning.Size = new System.Drawing.Size(218, 29);
            this.Warning.TabIndex = 4;
            this.Warning.Text = "Please insert Valid ID";
            // 
            // Back_Butt
            // 
            this.Back_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Back_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Back_Butt.ForeColor = System.Drawing.Color.White;
            this.Back_Butt.Location = new System.Drawing.Point(12, 536);
            this.Back_Butt.Name = "Back_Butt";
            this.Back_Butt.Size = new System.Drawing.Size(140, 68);
            this.Back_Butt.TabIndex = 5;
            this.Back_Butt.Text = "Back";
            this.Back_Butt.UseVisualStyleBackColor = false;
            this.Back_Butt.Click += new System.EventHandler(this.Back_Butt_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 47;
            this.pictureBox2.TabStop = false;
            // 
            // SortingTest
            // 
            this.SortingTest.AutoSize = true;
            this.SortingTest.BackColor = System.Drawing.Color.Transparent;
            this.SortingTest.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SortingTest.ForeColor = System.Drawing.Color.Navy;
            this.SortingTest.Location = new System.Drawing.Point(243, 149);
            this.SortingTest.Name = "SortingTest";
            this.SortingTest.Size = new System.Drawing.Size(260, 59);
            this.SortingTest.TabIndex = 48;
            this.SortingTest.Text = "SortingTests";
            // 
            // SortingTestCRUD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.SortingTest);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Back_Butt);
            this.Controls.Add(this.Warning);
            this.Controls.Add(this.ST_Edit);
            this.Controls.Add(this.ST_View);
            this.Controls.Add(this.ST_Add);
            this.Controls.Add(this.ID_Input);
            this.Name = "SortingTestCRUD";
            this.Text = "SortingTestCRUD";
            this.Load += new System.EventHandler(this.SortingTestCRUD_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ID_Input;
        private System.Windows.Forms.Button ST_Add;
        private System.Windows.Forms.Button ST_View;
        private System.Windows.Forms.Button ST_Edit;
        private System.Windows.Forms.Label Warning;
        private System.Windows.Forms.Button Back_Butt;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label SortingTest;
    }
}