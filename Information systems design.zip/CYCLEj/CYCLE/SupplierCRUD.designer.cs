﻿namespace CYCLE
{
    partial class SupplierCRUD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.To_S_Update = new System.Windows.Forms.Button();
            this.To_S_Add = new System.Windows.Forms.Button();
            this.Back_Butt = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Suppliers = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // To_S_Update
            // 
            this.To_S_Update.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.To_S_Update.Font = new System.Drawing.Font("Calibri", 18F);
            this.To_S_Update.ForeColor = System.Drawing.Color.White;
            this.To_S_Update.Location = new System.Drawing.Point(89, 321);
            this.To_S_Update.Name = "To_S_Update";
            this.To_S_Update.Size = new System.Drawing.Size(218, 95);
            this.To_S_Update.TabIndex = 0;
            this.To_S_Update.Text = "Update/Delete Supplier";
            this.To_S_Update.UseVisualStyleBackColor = false;
            this.To_S_Update.Click += new System.EventHandler(this.To_S_Update_Click);
            // 
            // To_S_Add
            // 
            this.To_S_Add.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.To_S_Add.Font = new System.Drawing.Font("Calibri", 18F);
            this.To_S_Add.ForeColor = System.Drawing.Color.White;
            this.To_S_Add.Location = new System.Drawing.Point(417, 321);
            this.To_S_Add.Name = "To_S_Add";
            this.To_S_Add.Size = new System.Drawing.Size(218, 95);
            this.To_S_Add.TabIndex = 1;
            this.To_S_Add.Text = "Add Supplier";
            this.To_S_Add.UseVisualStyleBackColor = false;
            this.To_S_Add.Click += new System.EventHandler(this.To_S_Add_Click);
            // 
            // Back_Butt
            // 
            this.Back_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Back_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Back_Butt.ForeColor = System.Drawing.Color.White;
            this.Back_Butt.Location = new System.Drawing.Point(12, 531);
            this.Back_Butt.Name = "Back_Butt";
            this.Back_Butt.Size = new System.Drawing.Size(140, 68);
            this.Back_Butt.TabIndex = 2;
            this.Back_Butt.Text = "Back";
            this.Back_Butt.UseVisualStyleBackColor = false;
            this.Back_Butt.Click += new System.EventHandler(this.Back_Butt_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 24;
            this.pictureBox2.TabStop = false;
            // 
            // Suppliers
            // 
            this.Suppliers.AutoSize = true;
            this.Suppliers.BackColor = System.Drawing.Color.Transparent;
            this.Suppliers.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Suppliers.ForeColor = System.Drawing.Color.Navy;
            this.Suppliers.Location = new System.Drawing.Point(278, 145);
            this.Suppliers.Name = "Suppliers";
            this.Suppliers.Size = new System.Drawing.Size(203, 59);
            this.Suppliers.TabIndex = 47;
            this.Suppliers.Text = "Suppliers";
            // 
            // SupplierCRUD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.Suppliers);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Back_Butt);
            this.Controls.Add(this.To_S_Add);
            this.Controls.Add(this.To_S_Update);
            this.Name = "SupplierCRUD";
            this.Text = "SupplierCRUD";
            this.Load += new System.EventHandler(this.SupplierCRUD_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button To_S_Update;
        private System.Windows.Forms.Button To_S_Add;
        private System.Windows.Forms.Button Back_Butt;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Suppliers;
    }
}