﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CYCLE
{
    public partial class AddSupplier : Form
    {
        public AddSupplier()
        {
            InitializeComponent();
            ErrorMSG.Hide();
        }

        private void AddSupplier_Load(object sender, EventArgs e)
        {

        }

        private void S_addNew_Click(object sender, EventArgs e)
        {

        }

        private bool ValidateInputs()
        {
            if (!Int32.TryParse(S_IDInput.Text, out int Value) || !Int32.TryParse(S_PhoneNumInput.Text, out Value) || !Int32.TryParse(S_Bank_Account_infoInput.Text, out Value))
                return false; //Making sure ID, PhoneNum, bank account info are all numbers

            else if (S_IDInput.Text == null || S_FullnameInput.Text == null || S_Contact_Full_Name_Input.Text == null || S_EmailInput.Text == null || S_AddressInput.Text == null || S_PhoneNumInput.Text == null || S_Bank_Account_infoInput.Text == null)
                return false; // Making sure no input is to stay null

            else if (0 >= int.Parse(S_IDInput.Text) || 0 >= int.Parse(S_PhoneNumInput.Text))
                return false;// Making sure ID is a positive number

            else if (Regex.IsMatch(S_EmailInput.Text, @"^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$") == false)
                return false;// Making sure the email is in the right format

            else if (Regex.IsMatch(S_Contact_Full_Name_Input.Text, @"^[a-zA-Z ][a-z ]*$") == false || Regex.IsMatch(S_FullnameInput.Text, @"^[a-zA-Z ][a-z ]*$") == false)
                return false;// Making sure full name containing only letters

            else if (Regex.IsMatch(S_AddressInput.Text, @"^[a-zA-Z0-9 ]*$") == false || Regex.IsMatch(S_Bank_Account_infoInput.Text, @"^[a-zA-Z0-9 ]*$") == false)
                return false;// Making sure address is in the right format

            else if (S_PhoneNumInput.Text.Length != 10)
                return false;// Making sure PhoneNum are the right length

            else
                return true;
        }


        private void S_Back_Click(object sender, EventArgs e)
        {
            SupplierCRUD sc = new SupplierCRUD();
            sc.Show();
            this.Close();
        }

        private void S_AddNew_Click_1(object sender, EventArgs e)
        {
            if (!ValidateInputs())
            {
                ErrorMSG.Show();
                if (ErrorMSG.Font.Size <= 20)
                    ErrorMSG.Font = new Font(ErrorMSG.Font.FontFamily, ErrorMSG.Font.Size + 1);
                else if (ErrorMSG.ForeColor == Color.Red)
                    ErrorMSG.ForeColor = Color.Gold;
                else
                    ErrorMSG.ForeColor = Color.Red;
            }
            else
            {
                bool S_Exist = false;
                ErrorMSG.Hide();
                foreach (Supplier S in Program.Suppliers)
                {
                    if (S.get_ID() == S_IDInput.Text)
                    {
                        S_Exist = true;
                        break;
                    }
                }
                if (!S_Exist)
                {
                    ErrorMSG.Hide();
                    Supplier S = new Supplier(S_IDInput.Text, S_FullnameInput.Text, S_AddressInput.Text, S_Contact_Full_Name_Input.Text, S_PhoneNumInput.Text, S_EmailInput.Text, S_Bank_Account_infoInput.Text, true);
                    SupplierCRUD sc = new SupplierCRUD();
                    sc.Show();
                    this.Close();
                }
                else ErrorMSG.Show();
            }
        }

        private void S_Back_Click_1(object sender, EventArgs e)
        {
            SupplierCRUD sc = new SupplierCRUD();
            sc.Show();
            this.Close();
        }





    }
}

