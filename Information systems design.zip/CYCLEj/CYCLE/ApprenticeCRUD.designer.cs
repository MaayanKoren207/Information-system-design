﻿namespace CYCLE
{
    partial class ApprenticeCRUD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.To_A_Add = new System.Windows.Forms.Button();
            this.To_A_Update = new System.Windows.Forms.Button();
            this.Back_Butt = new System.Windows.Forms.Button();
            this.Apprentice = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // To_A_Add
            // 
            this.To_A_Add.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.To_A_Add.Font = new System.Drawing.Font("Calibri", 18F);
            this.To_A_Add.ForeColor = System.Drawing.Color.White;
            this.To_A_Add.Location = new System.Drawing.Point(427, 319);
            this.To_A_Add.Name = "To_A_Add";
            this.To_A_Add.Size = new System.Drawing.Size(218, 95);
            this.To_A_Add.TabIndex = 0;
            this.To_A_Add.Text = "Add Apprentice";
            this.To_A_Add.UseVisualStyleBackColor = false;
            this.To_A_Add.Click += new System.EventHandler(this.To_A_Add_Click);
            // 
            // To_A_Update
            // 
            this.To_A_Update.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.To_A_Update.Font = new System.Drawing.Font("Calibri", 18F);
            this.To_A_Update.ForeColor = System.Drawing.Color.White;
            this.To_A_Update.Location = new System.Drawing.Point(98, 319);
            this.To_A_Update.Name = "To_A_Update";
            this.To_A_Update.Size = new System.Drawing.Size(218, 95);
            this.To_A_Update.TabIndex = 1;
            this.To_A_Update.Text = "Update/Delete Apprentice";
            this.To_A_Update.UseVisualStyleBackColor = false;
            this.To_A_Update.Click += new System.EventHandler(this.To_A_Update_Click);
            // 
            // Back_Butt
            // 
            this.Back_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Back_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Back_Butt.ForeColor = System.Drawing.Color.White;
            this.Back_Butt.Location = new System.Drawing.Point(12, 531);
            this.Back_Butt.Name = "Back_Butt";
            this.Back_Butt.Size = new System.Drawing.Size(140, 68);
            this.Back_Butt.TabIndex = 2;
            this.Back_Butt.Text = "Back";
            this.Back_Butt.UseVisualStyleBackColor = false;
            this.Back_Butt.Click += new System.EventHandler(this.Back_Butt_Click);
            // 
            // Apprentice
            // 
            this.Apprentice.AutoSize = true;
            this.Apprentice.BackColor = System.Drawing.Color.Transparent;
            this.Apprentice.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Apprentice.ForeColor = System.Drawing.Color.Navy;
            this.Apprentice.Location = new System.Drawing.Point(238, 138);
            this.Apprentice.Name = "Apprentice";
            this.Apprentice.Size = new System.Drawing.Size(239, 59);
            this.Apprentice.TabIndex = 21;
            this.Apprentice.Text = "Apprentice";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 43;
            this.pictureBox2.TabStop = false;
            // 
            // ApprenticeCRUD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Apprentice);
            this.Controls.Add(this.Back_Butt);
            this.Controls.Add(this.To_A_Update);
            this.Controls.Add(this.To_A_Add);
            this.Name = "ApprenticeCRUD";
            this.Text = "ApprenticeCRUD";
            this.Load += new System.EventHandler(this.ApprenticeCRUD_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button To_A_Add;
        private System.Windows.Forms.Button To_A_Update;
        private System.Windows.Forms.Button Back_Butt;
        private System.Windows.Forms.Label Apprentice;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}