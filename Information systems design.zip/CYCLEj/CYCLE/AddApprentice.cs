﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class AddApprentice : Form
    {
        public AddApprentice()
        {
            InitializeComponent();
            List<IsCandidate> ic = new List<IsCandidate>
                {
                new IsCandidate { ic_Text = "כן", ic_Value = 1 },
                new IsCandidate { ic_Text = "לא", ic_Value = 0 }
                };
            Is_C_Input.DataSource = ic;
            Is_C_Input.DisplayMember = "ic_Text";
            Is_C_Input.ValueMember = "ic_Value";
            Is_C_Input.SelectedValue = -1;
            Invalid_App_Lable.Hide();
        }

        private void AddApprentice_Load(object sender, EventArgs e)
        {
        }

        private void A_AddNew_Click(object sender, EventArgs e)
        {
            if (IsValidInput())
            {

                if (Is_C_Input.Equals(-1))
                {
                    Is_C_Input.SelectedValue = 1;
                    A_StatusEnumInput.SelectedValue = ApprenticeStatus.WatingForAnswer;
                }

                Invalid_App_Lable.Hide();
                Apprentice A = new Apprentice(A_IDInput.Text, A_FnameInput.Text, A_LnameInput.Text, int.Parse(A_AgeInput.Text), A_AddressInput.Text, A_EmailInput.Text, A_PhoneNumInput.Text, (ApprenticeStatus)Enum.Parse(typeof(ApprenticeStatus), A_StatusEnumInput.Text), (int)Is_C_Input.SelectedValue, true);
                ApprenticeCRUD ac = new ApprenticeCRUD();
                ac.Show();
                this.Close();
            }
            else
            {
                Invalid_App_Lable.Show();
                if (Invalid_App_Lable.Font.Size <= 20)
                    Invalid_App_Lable.Font = new Font(Invalid_App_Lable.Font.FontFamily, Invalid_App_Lable.Font.Size + 1);
                else if (Invalid_App_Lable.ForeColor == Color.Red)
                    Invalid_App_Lable.ForeColor = Color.Gold;
                else
                    Invalid_App_Lable.ForeColor = Color.Red;
            }
        }


        private bool IsValidInput()
        {
            if (!Int32.TryParse(A_IDInput.Text, out int Value) || !Int32.TryParse(A_AgeInput.Text, out Value) || !Int32.TryParse(A_PhoneNumInput.Text, out Value))
                return false; //Making sure ID, Age, PhoneNum are all numbers

            else if (A_IDInput.Text == null || A_FnameInput.Text == null || A_LnameInput.Text == null || A_AgeInput.Text == null || A_AddressInput.Text == null || A_EmailInput.Text == null || A_PhoneNumInput.Text == null)
                return false; // Making sure no input is to stay null

            else if (100000000 > int.Parse(A_IDInput.Text) || int.Parse(A_IDInput.Text) > 999999999 || 0 > int.Parse(A_AgeInput.Text) || int.Parse(A_AgeInput.Text) > 121)
                return false;// Making sure ID is a number in the right length, and appropriate age

            else if (Regex.IsMatch(A_EmailInput.Text, @"^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$") == false)
                return false;// Making sure the email is in the right format

            else if (Regex.IsMatch(A_FnameInput.Text, @"^[a-zA-Z][a-z]*$") == false || Regex.IsMatch(A_LnameInput.Text, @"^[a-zA-Z][a-z]*$") == false)
                return false;// Making sure full name containing only letters

            else if (Regex.IsMatch(A_AddressInput.Text, @"^[a-zA-Z0-9 ]*$") == false)
                return false;// Making sure address is in the right format

            else if (A_IDInput.Text.Length != 9 || A_PhoneNumInput.Text.Length != 10)
                return false;// Making sure ID and PhoneNum are the right length

            else if (Program.seekAllApprentice(A_IDInput.Text) != null)
                return false; // Making sure Apprentice ID is not already exist

            else
                return true;
        }

        private void A_Back_Click(object sender, EventArgs e)
        {
            ApprenticeCRUD ac = new ApprenticeCRUD();
            ac.Show();
            this.Close();
        }

        private void Is_C_Input_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedValue = Is_C_Input.Text;
            if (selectedValue == "כן")
                A_StatusEnumInput.DataSource = new List<ApprenticeStatus> { ApprenticeStatus.WatingForAnswer, ApprenticeStatus.Rejected };
            else if (selectedValue == "לא")
                A_StatusEnumInput.DataSource = new List<ApprenticeStatus> { ApprenticeStatus.ParticipatesInCurrentClass, ApprenticeStatus.DoesNotParticipateInCurrentClass };
        }

        private void A_FirstName_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void A_FormatText_Click(object sender, EventArgs e)
        {

        }
    }
}
