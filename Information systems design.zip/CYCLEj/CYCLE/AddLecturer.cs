﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class AddLecturer : Form
    {
        public AddLecturer()
        {
            InitializeComponent();
            Input_comboBox_Status.DataSource = Enum.GetValues(typeof(Status));

            Invalid_App_Lable.Hide();
            Input_comboBox_Status.SelectedIndex = -1;
        }

        private void backTo_L_CRUD_Click(object sender, EventArgs e)
        {
            LecturerCRUD lc = new LecturerCRUD();
            lc.Show();
            this.Close();
        }

        private void Add_Lecturer_B_Click(object sender, EventArgs e)
        {
            if (IsValidInput())
            {
                Invalid_App_Lable.Hide();

                if (Input_comboBox_Status.Equals(-1))
                {
                    Input_comboBox_Status.SelectedIndex = 0;  //Active Lecturer by default
                }

                Lecturer l = new Lecturer(Input_L_ID.Text, Input_FirstName.Text, Input_LastName.Text, Input_Email.Text, Input_PhoneNumber.Text, (Status)Enum.Parse(typeof(Status), Input_comboBox_Status.Text), true);

                LecturerCRUD lc = new LecturerCRUD();
                lc.Show();
                this.Close();
            }
            else
            {
                Invalid_App_Lable.Show();
                if (Invalid_App_Lable.Font.Size <= 20)
                    Invalid_App_Lable.Font = new Font(Invalid_App_Lable.Font.FontFamily, Invalid_App_Lable.Font.Size + 1);
                else if (Invalid_App_Lable.ForeColor == Color.Red)
                    Invalid_App_Lable.ForeColor = Color.Gold;
                else
                    Invalid_App_Lable.ForeColor = Color.Red;
            }
        }

        private bool IsValidInput()
        {
            if (!Int32.TryParse(Input_L_ID.Text, out int Value) || !Int32.TryParse(Input_PhoneNumber.Text, out Value))
                return false; //Making sure ID and PhoneNum are all numbers

            else if (Input_L_ID.Text == null || Input_FirstName.Text == null || Input_LastName.Text == null || Input_Email.Text == null || Input_PhoneNumber.Text == null)
                return false; // Making sure no input is to stay null

            else if (100000000 > int.Parse(Input_L_ID.Text) || int.Parse(Input_L_ID.Text) > 999999999)
                return false;// Making sure ID is a number in the right length

            else if (Regex.IsMatch(Input_Email.Text, @"^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$") == false)
                return false;// Making sure the email is in the right format

            else if (Regex.IsMatch(Input_FirstName.Text, @"^[a-zA-Z][a-z]*$") == false || Regex.IsMatch(Input_LastName.Text, @"^[a-zA-Z][a-z]*$") == false)
                return false;// Making sure full name containing only letters

            else if (Input_L_ID.Text.Length != 9 || Input_PhoneNumber.Text.Length != 10)
                return false;// Making sure ID and PhoneNum are the right length

            else if (Program.seekLecturer(Input_L_ID.Text) != null)
                return false; // Making sure Lecturer ID is not already exist

            else
                return true;
        }

        private void AddLecturer_Load(object sender, EventArgs e)
        {

        }

        private void InValidInput_lable_Click(object sender, EventArgs e)
        {

        }
    }
}

