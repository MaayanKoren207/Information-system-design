﻿namespace CYCLE
{
    partial class EditST
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CandidateID = new System.Windows.Forms.Label();
            this.Date = new System.Windows.Forms.Label();
            this.DateDisplay = new System.Windows.Forms.ComboBox();
            this.Cat1 = new System.Windows.Forms.Label();
            this.Cat2 = new System.Windows.Forms.Label();
            this.Cat3 = new System.Windows.Forms.Label();
            this.Cat4 = new System.Windows.Forms.Label();
            this.Cat5 = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.AverageScore = new System.Windows.Forms.Label();
            this.CatRate1 = new System.Windows.Forms.ComboBox();
            this.CatRate2 = new System.Windows.Forms.ComboBox();
            this.CatRate3 = new System.Windows.Forms.ComboBox();
            this.CatRate4 = new System.Windows.Forms.ComboBox();
            this.CatRate5 = new System.Windows.Forms.ComboBox();
            this.UpdateButton = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // CandidateID
            // 
            this.CandidateID.AutoSize = true;
            this.CandidateID.BackColor = System.Drawing.Color.Transparent;
            this.CandidateID.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Underline);
            this.CandidateID.ForeColor = System.Drawing.Color.Indigo;
            this.CandidateID.Location = new System.Drawing.Point(287, 87);
            this.CandidateID.Name = "CandidateID";
            this.CandidateID.Size = new System.Drawing.Size(64, 26);
            this.CandidateID.TabIndex = 0;
            this.CandidateID.Text = "label1";
            // 
            // Date
            // 
            this.Date.AutoSize = true;
            this.Date.BackColor = System.Drawing.Color.Transparent;
            this.Date.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Date.Location = new System.Drawing.Point(228, 40);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(46, 23);
            this.Date.TabIndex = 1;
            this.Date.Text = "Date";
            // 
            // DateDisplay
            // 
            this.DateDisplay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DateDisplay.FormattingEnabled = true;
            this.DateDisplay.Location = new System.Drawing.Point(292, 42);
            this.DateDisplay.Name = "DateDisplay";
            this.DateDisplay.Size = new System.Drawing.Size(121, 21);
            this.DateDisplay.TabIndex = 2;
            this.DateDisplay.SelectedIndexChanged += new System.EventHandler(this.DateDisplay_SelectedIndexChanged);
            // 
            // Cat1
            // 
            this.Cat1.AutoSize = true;
            this.Cat1.BackColor = System.Drawing.Color.Transparent;
            this.Cat1.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Cat1.Location = new System.Drawing.Point(228, 180);
            this.Cat1.Name = "Cat1";
            this.Cat1.Size = new System.Drawing.Size(56, 23);
            this.Cat1.TabIndex = 3;
            this.Cat1.Text = "label1";
            // 
            // Cat2
            // 
            this.Cat2.AutoSize = true;
            this.Cat2.BackColor = System.Drawing.Color.Transparent;
            this.Cat2.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Cat2.Location = new System.Drawing.Point(228, 244);
            this.Cat2.Name = "Cat2";
            this.Cat2.Size = new System.Drawing.Size(56, 23);
            this.Cat2.TabIndex = 4;
            this.Cat2.Text = "label1";
            // 
            // Cat3
            // 
            this.Cat3.AutoSize = true;
            this.Cat3.BackColor = System.Drawing.Color.Transparent;
            this.Cat3.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Cat3.Location = new System.Drawing.Point(228, 306);
            this.Cat3.Name = "Cat3";
            this.Cat3.Size = new System.Drawing.Size(56, 23);
            this.Cat3.TabIndex = 5;
            this.Cat3.Text = "label1";
            // 
            // Cat4
            // 
            this.Cat4.AutoSize = true;
            this.Cat4.BackColor = System.Drawing.Color.Transparent;
            this.Cat4.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Cat4.Location = new System.Drawing.Point(228, 367);
            this.Cat4.Name = "Cat4";
            this.Cat4.Size = new System.Drawing.Size(56, 23);
            this.Cat4.TabIndex = 6;
            this.Cat4.Text = "label1";
            // 
            // Cat5
            // 
            this.Cat5.AutoSize = true;
            this.Cat5.BackColor = System.Drawing.Color.Transparent;
            this.Cat5.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Cat5.Location = new System.Drawing.Point(228, 433);
            this.Cat5.Name = "Cat5";
            this.Cat5.Size = new System.Drawing.Size(56, 23);
            this.Cat5.TabIndex = 7;
            this.Cat5.Text = "label1";
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.BackButton.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.BackButton.ForeColor = System.Drawing.Color.White;
            this.BackButton.Location = new System.Drawing.Point(12, 536);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(146, 63);
            this.BackButton.TabIndex = 9;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // AverageScore
            // 
            this.AverageScore.AutoSize = true;
            this.AverageScore.BackColor = System.Drawing.Color.Transparent;
            this.AverageScore.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Underline);
            this.AverageScore.ForeColor = System.Drawing.Color.Indigo;
            this.AverageScore.Location = new System.Drawing.Point(272, 126);
            this.AverageScore.Name = "AverageScore";
            this.AverageScore.Size = new System.Drawing.Size(64, 26);
            this.AverageScore.TabIndex = 10;
            this.AverageScore.Text = "label1";
            // 
            // CatRate1
            // 
            this.CatRate1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CatRate1.Font = new System.Drawing.Font("Calibri", 12F);
            this.CatRate1.FormattingEnabled = true;
            this.CatRate1.Items.AddRange(new object[] {
            "1.0",
            "2.0",
            "3.0",
            "4.0",
            "5.0"});
            this.CatRate1.Location = new System.Drawing.Point(408, 180);
            this.CatRate1.Name = "CatRate1";
            this.CatRate1.Size = new System.Drawing.Size(67, 27);
            this.CatRate1.TabIndex = 11;
            // 
            // CatRate2
            // 
            this.CatRate2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CatRate2.Font = new System.Drawing.Font("Calibri", 12F);
            this.CatRate2.FormattingEnabled = true;
            this.CatRate2.Items.AddRange(new object[] {
            "1.0",
            "2.0",
            "3.0",
            "4.0",
            "5.0"});
            this.CatRate2.Location = new System.Drawing.Point(408, 240);
            this.CatRate2.Name = "CatRate2";
            this.CatRate2.Size = new System.Drawing.Size(67, 27);
            this.CatRate2.TabIndex = 12;
            // 
            // CatRate3
            // 
            this.CatRate3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CatRate3.Font = new System.Drawing.Font("Calibri", 12F);
            this.CatRate3.FormattingEnabled = true;
            this.CatRate3.Items.AddRange(new object[] {
            "1.0",
            "2.0",
            "3.0",
            "4.0",
            "5.0"});
            this.CatRate3.Location = new System.Drawing.Point(408, 304);
            this.CatRate3.Name = "CatRate3";
            this.CatRate3.Size = new System.Drawing.Size(67, 27);
            this.CatRate3.TabIndex = 13;
            // 
            // CatRate4
            // 
            this.CatRate4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CatRate4.Font = new System.Drawing.Font("Calibri", 12F);
            this.CatRate4.FormattingEnabled = true;
            this.CatRate4.Items.AddRange(new object[] {
            "1.0",
            "2.0",
            "3.0",
            "4.0",
            "5.0"});
            this.CatRate4.Location = new System.Drawing.Point(408, 367);
            this.CatRate4.Name = "CatRate4";
            this.CatRate4.Size = new System.Drawing.Size(67, 27);
            this.CatRate4.TabIndex = 14;
            // 
            // CatRate5
            // 
            this.CatRate5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CatRate5.Font = new System.Drawing.Font("Calibri", 12F);
            this.CatRate5.FormattingEnabled = true;
            this.CatRate5.Items.AddRange(new object[] {
            "1.0",
            "2.0",
            "3.0",
            "4.0",
            "5.0"});
            this.CatRate5.Location = new System.Drawing.Point(408, 429);
            this.CatRate5.Name = "CatRate5";
            this.CatRate5.Size = new System.Drawing.Size(67, 27);
            this.CatRate5.TabIndex = 15;
            // 
            // UpdateButton
            // 
            this.UpdateButton.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.UpdateButton.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.UpdateButton.ForeColor = System.Drawing.Color.White;
            this.UpdateButton.Location = new System.Drawing.Point(576, 536);
            this.UpdateButton.Name = "UpdateButton";
            this.UpdateButton.Size = new System.Drawing.Size(146, 63);
            this.UpdateButton.TabIndex = 18;
            this.UpdateButton.Text = "Update";
            this.UpdateButton.UseVisualStyleBackColor = false;
            this.UpdateButton.Click += new System.EventHandler(this.UpdateButton_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 42;
            this.pictureBox2.TabStop = false;
            // 
            // EditST
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.UpdateButton);
            this.Controls.Add(this.CatRate5);
            this.Controls.Add(this.CatRate4);
            this.Controls.Add(this.CatRate3);
            this.Controls.Add(this.CatRate2);
            this.Controls.Add(this.CatRate1);
            this.Controls.Add(this.AverageScore);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.Cat5);
            this.Controls.Add(this.Cat4);
            this.Controls.Add(this.Cat3);
            this.Controls.Add(this.Cat2);
            this.Controls.Add(this.Cat1);
            this.Controls.Add(this.DateDisplay);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.CandidateID);
            this.Name = "EditST";
            this.Text = "Edit Sorting Test";
            this.Load += new System.EventHandler(this.EditST_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }



        private System.Windows.Forms.Label CandidateID;
        private System.Windows.Forms.Label Date;
        private System.Windows.Forms.ComboBox DateDisplay;
        private System.Windows.Forms.Label Cat1;
        private System.Windows.Forms.Label Cat2;
        private System.Windows.Forms.Label Cat3;
        private System.Windows.Forms.Label Cat4;
        private System.Windows.Forms.Label Cat5;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label AverageScore;
        private System.Windows.Forms.ComboBox CatRate1;
        private System.Windows.Forms.ComboBox CatRate2;
        private System.Windows.Forms.ComboBox CatRate3;
        private System.Windows.Forms.ComboBox CatRate4;
        private System.Windows.Forms.ComboBox CatRate5;
        private System.Windows.Forms.Button UpdateButton;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}
    

