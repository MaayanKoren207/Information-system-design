﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CYCLE
{
    public enum LectureTopic
    {
       
        NLP,
        Marketing,
        [Description("Team Work")] TeamWork,
        [Description("Managing Your Team")] ManagingYourTeam,
        [Description("Analyzing Data")] AnalyzingData
             
    }
}
