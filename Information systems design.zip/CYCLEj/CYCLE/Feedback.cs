﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CYCLE
{
    public class Feedback
    {
        public Lecture lecture;
        public Apprentice apprentice;

        public DateTime FeedbackDate;
        public int Rate;
        public string FeedbackText;


        public Feedback(Lecture l, Apprentice a, DateTime dt, int Rate, string FeedbackText, bool is_new)
        {
            this.Lecture = l;
            this.Apprentice = a;

            this.FeedbackDate = dt;
            this.Rate = Rate;
            this.FeedbackText = FeedbackText;

            if (is_new)
            {
                this.create_Feedback();
                l.AddFeedbacks(this);
                a.AddFeedbacks(this);
                Program.Feedbacks.Add(this);
            }

        }

        public DateTime get_FeedbackDate()
        {
            return this.FeedbackDate;
        }

        public int get_Rate()
        {
            return this.Rate;
        }

        public string get_FeedbackText()
        {
            return this.FeedbackText;
        }

        public void set_FeedbackDate(DateTime dt)
        {
            this.FeedbackDate = dt;
        }

        public void set_Rate(int i)
        {
            this.Rate = i;
        }

        public void set_FeedbackText(string s)
        {
            this.FeedbackText = s;
        }

        public Lecture Lecture
        {
            get
            {
                return lecture;
            }
            set
            {
                if (this.lecture == null || !this.lecture.Equals(value))
                {
                    if (this.lecture != null) 
                    {
                        Lecture oldLecture = this.lecture;
                        this.lecture = null;
                        oldLecture.RemoveFeedbacks(this);
                    }
                    if (value != null)
                    {
                        this.lecture = value;
                        this.lecture.AddFeedbacks(this);
                    }
                }
            }
        }

        public Apprentice Apprentice
        {
            get
            {
                return apprentice;
            }

            set
            {
                if (this.apprentice == null || !this.apprentice.Equals(value))
                {
                    if (this.apprentice != null) 
                    {
                        Apprentice oldApprentice = this.apprentice;
                        this.apprentice = null;
                        oldApprentice.RemoveFeedbacks(this);
                    }
                    if (value != null)
                    {
                        this.apprentice = value;
                        this.apprentice.AddFeedbacks(this);
                    }
                }
            }
        }
        
        public void create_Feedback()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_add_Feedback @FeedbackDate, @StartTime, @Rate, @FeedbackText, @Topic, @A_ID";
            c.Parameters.AddWithValue("@FeedbackDate", this.FeedbackDate);
            c.Parameters.AddWithValue("@StartTime", this.Lecture.get_StartTime());
            c.Parameters.AddWithValue("@Rate", this.Rate);
            c.Parameters.AddWithValue("@FeedbackText", this.FeedbackText);
            c.Parameters.AddWithValue("@Topic", this.Lecture.get_Topic().ToString());
            c.Parameters.AddWithValue("@A_ID", this.Apprentice.getID());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }



        public void Update_Feedback()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_Update_Feedback @FeedbackDate, @StartTime, @Rate, @FeedbackText, @Topic, @A_ID";
            c.Parameters.AddWithValue("@FeedbackDate", this.FeedbackDate);
            c.Parameters.AddWithValue("@StartTime", this.Lecture.get_StartTime());
            c.Parameters.AddWithValue("@Rate", this.Rate);
            c.Parameters.AddWithValue("@FeedbackText", this.FeedbackText);
            c.Parameters.AddWithValue("@Topic", this.Lecture.get_Topic().ToString());
            c.Parameters.AddWithValue("@A_ID", this.Apprentice.getID());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Delete_Feedback()
        {
            Program.Feedbacks.Remove(this);
            this.lecture?.RemoveFeedbacks(this);
            this.apprentice?.RemoveFeedbacks(this);
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_delete_Feedback @StartTime, @Topic, @A_ID";
            c.Parameters.AddWithValue("@StartTime", this.lecture.get_StartTime());
            c.Parameters.AddWithValue("@Topic", this.lecture.get_Topic().ToString());
            c.Parameters.AddWithValue("@A_ID", this.Apprentice.getID());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }


    }
}
