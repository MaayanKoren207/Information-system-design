﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CYCLE
{
    public enum AssigningStatus
    {
        [Description("Waiting For Answer")] WaitingForAnswer,
        Approved,
        Rejected,
        Optional
    }
}
