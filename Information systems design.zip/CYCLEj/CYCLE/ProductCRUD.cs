﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class ProductCRUD : Form
    {
        public ProductCRUD()
        {
            InitializeComponent();
        }

      

        private void ProductCRUD_Load(object sender, EventArgs e)
        {
            
        }

        private void To_P_Update_Click(object sender, EventArgs e)
        {
            UpdateP UDP = new UpdateP();
            UDP.Show();
            this.Hide();

        }

        private void To_P_Add_Click_1(object sender, EventArgs e)
        {
            AddProducts add_P = new AddProducts();
            add_P.Show();
            this.Hide();
        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            HomePage hp = new HomePage();
            hp.Show();
            this.Hide();
        }
    }
}
