﻿namespace CYCLE
{
    partial class UpdateP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.P_SIDud = new System.Windows.Forms.Label();
            this.P_IDud = new System.Windows.Forms.Label();
            this.P_Nameud = new System.Windows.Forms.Label();
            this.P_AmountUD = new System.Windows.Forms.Label();
            this.P_PriceUD = new System.Windows.Forms.Label();
            this.P_CategoryUD = new System.Windows.Forms.Label();
            this.PSIDinputUD = new System.Windows.Forms.TextBox();
            this.PNameInput = new System.Windows.Forms.TextBox();
            this.P_AmountInputID = new System.Windows.Forms.TextBox();
            this.P_priceUDinput = new System.Windows.Forms.TextBox();
            this.PCategoryInputUD = new System.Windows.Forms.ComboBox();
            this.P_BackUD = new System.Windows.Forms.Button();
            this.P_Update = new System.Windows.Forms.Button();
            this.P_Valid = new System.Windows.Forms.Label();
            this.P_OKText = new System.Windows.Forms.Label();
            this.P_ID_Search = new System.Windows.Forms.Button();
            this.P_IDinputUD1 = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Search_P_ID = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // P_SIDud
            // 
            this.P_SIDud.AutoSize = true;
            this.P_SIDud.BackColor = System.Drawing.Color.Transparent;
            this.P_SIDud.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.P_SIDud.Location = new System.Drawing.Point(13, 141);
            this.P_SIDud.Name = "P_SIDud";
            this.P_SIDud.Size = new System.Drawing.Size(105, 26);
            this.P_SIDud.TabIndex = 0;
            this.P_SIDud.Text = "Supplier ID";
            // 
            // P_IDud
            // 
            this.P_IDud.AutoSize = true;
            this.P_IDud.BackColor = System.Drawing.Color.Transparent;
            this.P_IDud.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.P_IDud.Location = new System.Drawing.Point(11, 193);
            this.P_IDud.Name = "P_IDud";
            this.P_IDud.Size = new System.Drawing.Size(102, 26);
            this.P_IDud.TabIndex = 1;
            this.P_IDud.Text = "Product ID";
            // 
            // P_Nameud
            // 
            this.P_Nameud.AutoSize = true;
            this.P_Nameud.BackColor = System.Drawing.Color.Transparent;
            this.P_Nameud.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.P_Nameud.Location = new System.Drawing.Point(10, 301);
            this.P_Nameud.Name = "P_Nameud";
            this.P_Nameud.Size = new System.Drawing.Size(63, 26);
            this.P_Nameud.TabIndex = 2;
            this.P_Nameud.Text = "Name";
            // 
            // P_AmountUD
            // 
            this.P_AmountUD.AutoSize = true;
            this.P_AmountUD.BackColor = System.Drawing.Color.Transparent;
            this.P_AmountUD.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.P_AmountUD.Location = new System.Drawing.Point(348, 299);
            this.P_AmountUD.Name = "P_AmountUD";
            this.P_AmountUD.Size = new System.Drawing.Size(151, 26);
            this.P_AmountUD.TabIndex = 3;
            this.P_AmountUD.Text = "Current Number";
            // 
            // P_PriceUD
            // 
            this.P_PriceUD.AutoSize = true;
            this.P_PriceUD.BackColor = System.Drawing.Color.Transparent;
            this.P_PriceUD.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.P_PriceUD.Location = new System.Drawing.Point(8, 357);
            this.P_PriceUD.Name = "P_PriceUD";
            this.P_PriceUD.Size = new System.Drawing.Size(128, 26);
            this.P_PriceUD.TabIndex = 4;
            this.P_PriceUD.Text = "Price Per Unit";
            // 
            // P_CategoryUD
            // 
            this.P_CategoryUD.AutoSize = true;
            this.P_CategoryUD.BackColor = System.Drawing.Color.Transparent;
            this.P_CategoryUD.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.P_CategoryUD.Location = new System.Drawing.Point(348, 353);
            this.P_CategoryUD.Name = "P_CategoryUD";
            this.P_CategoryUD.Size = new System.Drawing.Size(160, 26);
            this.P_CategoryUD.TabIndex = 5;
            this.P_CategoryUD.Text = "Product Category";
            // 
            // PSIDinputUD
            // 
            this.PSIDinputUD.Location = new System.Drawing.Point(131, 144);
            this.PSIDinputUD.Multiline = true;
            this.PSIDinputUD.Name = "PSIDinputUD";
            this.PSIDinputUD.Size = new System.Drawing.Size(185, 25);
            this.PSIDinputUD.TabIndex = 6;
            // 
            // PNameInput
            // 
            this.PNameInput.Location = new System.Drawing.Point(142, 304);
            this.PNameInput.Multiline = true;
            this.PNameInput.Name = "PNameInput";
            this.PNameInput.Size = new System.Drawing.Size(185, 25);
            this.PNameInput.TabIndex = 8;
            // 
            // P_AmountInputID
            // 
            this.P_AmountInputID.Location = new System.Drawing.Point(523, 304);
            this.P_AmountInputID.Multiline = true;
            this.P_AmountInputID.Name = "P_AmountInputID";
            this.P_AmountInputID.Size = new System.Drawing.Size(185, 25);
            this.P_AmountInputID.TabIndex = 9;
            // 
            // P_priceUDinput
            // 
            this.P_priceUDinput.Location = new System.Drawing.Point(142, 358);
            this.P_priceUDinput.Multiline = true;
            this.P_priceUDinput.Name = "P_priceUDinput";
            this.P_priceUDinput.Size = new System.Drawing.Size(185, 25);
            this.P_priceUDinput.TabIndex = 10;
            // 
            // PCategoryInputUD
            // 
            this.PCategoryInputUD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PCategoryInputUD.Font = new System.Drawing.Font("Calibri", 12F);
            this.PCategoryInputUD.FormattingEnabled = true;
            this.PCategoryInputUD.Location = new System.Drawing.Point(523, 352);
            this.PCategoryInputUD.Name = "PCategoryInputUD";
            this.PCategoryInputUD.Size = new System.Drawing.Size(185, 27);
            this.PCategoryInputUD.TabIndex = 11;
            // 
            // P_BackUD
            // 
            this.P_BackUD.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.P_BackUD.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.P_BackUD.ForeColor = System.Drawing.Color.White;
            this.P_BackUD.Location = new System.Drawing.Point(12, 531);
            this.P_BackUD.Name = "P_BackUD";
            this.P_BackUD.Size = new System.Drawing.Size(140, 68);
            this.P_BackUD.TabIndex = 20;
            this.P_BackUD.Text = "Back";
            this.P_BackUD.UseVisualStyleBackColor = false;
            this.P_BackUD.Click += new System.EventHandler(this.P_BackUD_Click);
            // 
            // P_Update
            // 
            this.P_Update.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.P_Update.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.P_Update.ForeColor = System.Drawing.Color.White;
            this.P_Update.Location = new System.Drawing.Point(572, 531);
            this.P_Update.Name = "P_Update";
            this.P_Update.Size = new System.Drawing.Size(140, 68);
            this.P_Update.TabIndex = 22;
            this.P_Update.Text = "Update Product";
            this.P_Update.UseVisualStyleBackColor = false;
            this.P_Update.Click += new System.EventHandler(this.P_Update_Click);
            // 
            // P_Valid
            // 
            this.P_Valid.AutoSize = true;
            this.P_Valid.BackColor = System.Drawing.Color.Transparent;
            this.P_Valid.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.P_Valid.ForeColor = System.Drawing.Color.Navy;
            this.P_Valid.Location = new System.Drawing.Point(106, 242);
            this.P_Valid.Name = "P_Valid";
            this.P_Valid.Size = new System.Drawing.Size(221, 26);
            this.P_Valid.TabIndex = 41;
            this.P_Valid.Text = "Please Insert valid input!";
            // 
            // P_OKText
            // 
            this.P_OKText.AutoSize = true;
            this.P_OKText.BackColor = System.Drawing.Color.Transparent;
            this.P_OKText.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.P_OKText.ForeColor = System.Drawing.Color.Navy;
            this.P_OKText.Location = new System.Drawing.Point(26, 80);
            this.P_OKText.Name = "P_OKText";
            this.P_OKText.Size = new System.Drawing.Size(358, 33);
            this.P_OKText.TabIndex = 42;
            this.P_OKText.Text = "Please Insert The Following Info";
            // 
            // P_ID_Search
            // 
            this.P_ID_Search.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.P_ID_Search.Font = new System.Drawing.Font("Calibri", 14F);
            this.P_ID_Search.ForeColor = System.Drawing.Color.White;
            this.P_ID_Search.Location = new System.Drawing.Point(343, 142);
            this.P_ID_Search.Name = "P_ID_Search";
            this.P_ID_Search.Size = new System.Drawing.Size(106, 28);
            this.P_ID_Search.TabIndex = 43;
            this.P_ID_Search.Text = "Search ";
            this.P_ID_Search.UseVisualStyleBackColor = false;
            this.P_ID_Search.Click += new System.EventHandler(this.P_ID_Search_Click);
            // 
            // P_IDinputUD1
            // 
            this.P_IDinputUD1.Location = new System.Drawing.Point(131, 196);
            this.P_IDinputUD1.Multiline = true;
            this.P_IDinputUD1.Name = "P_IDinputUD1";
            this.P_IDinputUD1.Size = new System.Drawing.Size(185, 25);
            this.P_IDinputUD1.TabIndex = 44;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 45;
            this.pictureBox2.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.label11.Location = new System.Drawing.Point(356, 325);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 26);
            this.label11.TabIndex = 46;
            this.label11.Text = "of Units";
            // 
            // Search_P_ID
            // 
            this.Search_P_ID.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Search_P_ID.Font = new System.Drawing.Font("Calibri", 14F);
            this.Search_P_ID.ForeColor = System.Drawing.Color.White;
            this.Search_P_ID.Location = new System.Drawing.Point(343, 193);
            this.Search_P_ID.Name = "Search_P_ID";
            this.Search_P_ID.Size = new System.Drawing.Size(106, 28);
            this.Search_P_ID.TabIndex = 47;
            this.Search_P_ID.Text = "Search ";
            this.Search_P_ID.UseVisualStyleBackColor = false;
            this.Search_P_ID.Click += new System.EventHandler(this.Search_P_ID_Click);
            // 
            // UpdateP
            // 
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.Search_P_ID);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.P_IDinputUD1);
            this.Controls.Add(this.P_ID_Search);
            this.Controls.Add(this.P_OKText);
            this.Controls.Add(this.P_Valid);
            this.Controls.Add(this.P_Update);
            this.Controls.Add(this.P_BackUD);
            this.Controls.Add(this.PCategoryInputUD);
            this.Controls.Add(this.P_priceUDinput);
            this.Controls.Add(this.P_AmountInputID);
            this.Controls.Add(this.PNameInput);
            this.Controls.Add(this.PSIDinputUD);
            this.Controls.Add(this.P_CategoryUD);
            this.Controls.Add(this.P_PriceUD);
            this.Controls.Add(this.P_AmountUD);
            this.Controls.Add(this.P_Nameud);
            this.Controls.Add(this.P_IDud);
            this.Controls.Add(this.P_SIDud);
            this.Name = "UpdateP";
            this.Load += new System.EventHandler(this.UpdateDeleteP_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Button U_D_P;
        private System.Windows.Forms.Button P_UD_Back;
        private System.Windows.Forms.Label S_UD_ID;
        private System.Windows.Forms.Label P_UD_ID;
        private System.Windows.Forms.Label P_UD_Name;
        private System.Windows.Forms.Label P_UD_amount;
        private System.Windows.Forms.Label P_UDamount;
        private System.Windows.Forms.Label P_UDcategory;
        private System.Windows.Forms.TextBox P_IDinputUD;
        private System.Windows.Forms.TextBox P_IDinput2;
        private System.Windows.Forms.TextBox P_UDinputName;
        private System.Windows.Forms.TextBox P_UDinputAmount;
        private System.Windows.Forms.TextBox P_UDinputPrice;
        private System.Windows.Forms.ComboBox P_UDCategoryInput;
        private System.Windows.Forms.TextBox P_IDinputUD1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button Search_P_ID;
    }
}