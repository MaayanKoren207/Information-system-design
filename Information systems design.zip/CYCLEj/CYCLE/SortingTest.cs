﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CYCLE
{
    public class SortingTest
    {
        public Apprentice apprentice;
        private DateTime TestDate;
        public System.Collections.Generic.List<CandidateRateByCat> candidateRateByCats;

        public SortingTest(Apprentice a, DateTime TestDate, bool is_new)
        {
            this.TestDate = TestDate;

            this.Apprentice = a;

            if (is_new)
            {
                this.create_SortingTest();
                a.AddSortingTests(this);
                Program.SortingTests.Add(this);
            }
        }

        public DateTime get_TestDate()
        {
            return this.TestDate;
        }

        /// <summary>
        /// Property for Candidate
        /// </summary>
        /// <pdGenerated>Default opposite class property</pdGenerated>
        /// 
        public Apprentice Apprentice
        {
            get
            {
                return apprentice;
            }
            set
            {
                if (this.apprentice == null || !this.apprentice.Equals(value))
                {
                    if (this.apprentice != null) // remove the sorting test from the exist Apprentice's list
                    {
                        Apprentice oldApprentice = this.apprentice;
                        this.apprentice = null;
                        oldApprentice.RemoveSortingTests(this);
                    }
                    if (value != null)
                    {
                        this.apprentice = value;
                        this.apprentice.AddSortingTests(this);
                    }
                }
            }
        }



        public void create_SortingTest()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_add_SortingTest @TestDate, @A_ID";
            c.Parameters.AddWithValue("@TestDate", this.TestDate);
            c.Parameters.AddWithValue("@A_ID", this.Apprentice.getID());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Update_SortingTest()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_Update_SortingTest @TestDate, @A_ID";
            c.Parameters.AddWithValue("@TestDate", this.TestDate);
            c.Parameters.AddWithValue("@A_ID", this.Apprentice.getID());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }


        public void Delete_SortingTest()
        {
            Program.SortingTests.Remove(this);
            this.apprentice?.RemoveSortingTests(this); // ? means if != null
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_delete_SortingTest @TestDate, @A_ID";
            c.Parameters.AddWithValue("@TestDate", this.TestDate);
            c.Parameters.AddWithValue("@A_ID", this.Apprentice.getID());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public System.Collections.Generic.List<CandidateRateByCat> CandidateRateByCats // get and set for the whole list
        {
            get
            {
                if (candidateRateByCats == null)
                    candidateRateByCats = new System.Collections.Generic.List<CandidateRateByCat>();
                return candidateRateByCats;
            }
            set
            {
                RemoveAllCandidateRateByCats();
                if (value != null)
                {
                    foreach (CandidateRateByCat oCandidateRateByCat in value)
                        AddCandidateRateByCats(oCandidateRateByCat);
                }
            }
        }
        public void AddCandidateRateByCats(CandidateRateByCat newCandidateRateByCat)
        {
            if (newCandidateRateByCat == null)
                return;
            if (this.candidateRateByCats == null)
                this.candidateRateByCats = new System.Collections.Generic.List<CandidateRateByCat>();
            if (!this.candidateRateByCats.Contains(newCandidateRateByCat))
            {
                this.candidateRateByCats.Add(newCandidateRateByCat);
                newCandidateRateByCat.SortingTest = this;
            }
        }
        public void RemoveCandidateRateByCats(CandidateRateByCat oldCandidateRateByCat)
        {
            if (oldCandidateRateByCat == null)
                return;
            if (this.candidateRateByCats != null)
                if (this.candidateRateByCats.Contains(oldCandidateRateByCat))
                {
                    this.candidateRateByCats.Remove(oldCandidateRateByCat);
                    oldCandidateRateByCat.SortingTest = null;
                }
        }

        public void RemoveAllCandidateRateByCats()
        {
            if (candidateRateByCats != null)
            {
                foreach (CandidateRateByCat a in candidateRateByCats)
                    a.SortingTest = null;
                candidateRateByCats.Clear();
            }
        }

    }
}