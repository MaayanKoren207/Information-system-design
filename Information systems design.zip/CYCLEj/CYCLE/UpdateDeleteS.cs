﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class UpdateDeleteS : Form
    {
        private Supplier S_Exist;
        public UpdateDeleteS()
        {
            InitializeComponent();
            S_Valid.Hide();
            S_FullNameInput1.Hide();
            S_AddressInput1.Hide();
            S_Contact_Full_NameInput1.Hide();
            S_Contact_Phone_NumberInput1.Hide();
            S_Contact_EmailInput1.Hide();
            S_Bank_Account_infoInput1.Hide();
            S_FullName.Hide();
            S_Address.Hide();
            S_Contact_Full_Name.Hide();
            S_Contact_Phone_Number.Hide();
            S_Contact_Email.Hide();
            S_Bank_Account_info.Hide();
            S_Update.Hide();
          //  S_Delete.Hide();
            label22.Hide();
            label11.Hide();

        }

        private void S_IDInput_TextChanged(object sender, EventArgs e)
        {

        }
        private void S_ID_Click(object sender, EventArgs e)
        {

        }
        private void S_ID_Search_Click(object sender, EventArgs e)
        {
            S_FullNameInput1.Show();
            S_AddressInput1.Show();
            S_Contact_Full_NameInput1.Show();
            S_Contact_Phone_NumberInput1.Show();
            S_Contact_EmailInput1.Show();
            S_Bank_Account_infoInput1.Show();
            S_FullName.Show();
            S_Address.Show();
            S_Contact_Full_Name.Show();
            S_Contact_Phone_Number.Show();
            S_Contact_Email.Show();
            S_Bank_Account_info.Show();
            S_Update.Show();
           // S_Delete.Show();
            label22.Show();
            label11.Show();
            S_Exist = Program.seekSupplier(S_IDInput1.Text);
            if (S_Exist != null)

            {
                S_Valid.Hide();
                S_FullNameInput1.Text = S_Exist.get_Name();
                S_AddressInput1.Text = S_Exist.get_SupplierAddress();
                S_Contact_Full_NameInput1.Text = S_Exist.get_ContactName();
                S_Contact_Phone_NumberInput1.Text = S_Exist.get_ContactPhoneNumber();
                S_Contact_EmailInput1.Text = S_Exist.get_ContactEmail();
                S_Bank_Account_infoInput1.Text = S_Exist.get_BankAccountInfo();
            }
            else
            {
                S_Valid.Show();
                S_FullNameInput1.Hide();
                S_AddressInput1.Hide();
                S_Contact_Full_NameInput1.Hide();
                S_Contact_Phone_NumberInput1.Hide();
                S_Contact_EmailInput1.Hide();
                S_Bank_Account_infoInput1.Hide();
                S_FullName.Hide();
                S_Address.Hide();
                S_Contact_Full_Name.Hide();
                S_Contact_Phone_Number.Hide();
                S_Contact_Email.Hide();
                S_Bank_Account_info.Hide();
                S_Update.Hide();
                //S_Delete.Hide();
                label22.Hide();
                label11.Hide();
            }
        }


        private void S_Update_Click(object sender, EventArgs e)
        {
            if (ValidateInputs())
            {
                S_Valid.Hide();
                S_Exist.set_FullName(S_FullNameInput1.Text);
                S_Exist.set_Address(S_AddressInput1.Text);
                S_Exist.set_ContactFullName(S_Contact_Full_NameInput1.Text);
                S_Exist.set_ContactPhoneNumber(S_Contact_Phone_NumberInput1.Text);
                S_Exist.set_ContactEmail(S_Contact_EmailInput1.Text);
                S_Exist.set_BankAccountInfo(S_Bank_Account_infoInput1.Text);
                S_Exist.Update_Supplier();
            }

            else
            {
                S_Valid.Show();
                if (S_Valid.Font.Size <= 20)
                    S_Valid.Font = new Font(S_Valid.Font.FontFamily, S_Valid.Font.Size + 1);
                else if (S_Valid.ForeColor == Color.Red)
                    S_Valid.ForeColor = Color.Gold;
                else
                    S_Valid.ForeColor = Color.Red;
            }
        }

        private void S_Delete_Click(object sender, EventArgs e)
        {
            S_Exist.Delete_Supplier();
            SupplierCRUD sc = new SupplierCRUD();
            sc.Show();
            this.Close();
        }

        private void S_Back1(object sender, EventArgs e)
        {

        }



        private void UpdateSupplier_Load(object sender, EventArgs e)
        {

        }


        private bool ValidateInputs()
        {
            if (!Int32.TryParse(S_IDInput1.Text, out int Value) || !Int32.TryParse(S_Contact_Phone_NumberInput1.Text, out Value) || !Int32.TryParse(S_Bank_Account_infoInput1.Text, out Value))
                return false; //Making sure ID, PhoneNum are all numbers

            else if (S_IDInput1.Text == null || S_FullNameInput1.Text == null || S_Contact_Full_NameInput1.Text == null || S_Contact_EmailInput1.Text == null || S_AddressInput1.Text == null || S_Contact_Phone_NumberInput1.Text == null || S_Bank_Account_infoInput1.Text == null)
                return false; // Making sure no input is to stay null

            else if (0 >= int.Parse(S_IDInput1.Text) || 0 >= int.Parse(S_Contact_Phone_NumberInput1.Text))
                return false;// Making sure ID is a positive number

            else if (Regex.IsMatch(S_Contact_EmailInput1.Text, @"^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$") == false)
                return false;// Making sure the email is in the right format

            else if (Regex.IsMatch(S_Contact_Full_NameInput1.Text, @"^[a-zA-Z ][a-z ]*$") == false || Regex.IsMatch(S_FullNameInput1.Text, @"^[a-zA-Z ][a-z ]*$") == false)
                return false;// Making sure full name containing only letters

            else if (Regex.IsMatch(S_AddressInput1.Text, @"^[a-zA-Z0-9 ]*$") == false || Regex.IsMatch(S_Bank_Account_infoInput1.Text, @"^[a-zA-Z0-9 ]*$") == false)
                return false;// Making sure address is in the right format

            else if (S_Contact_Phone_NumberInput1.Text.Length != 10)
                return false;// Making sure PhoneNum are the right length

            else
                return true;
        }

        private void S_Bank_Account_info_Click(object sender, EventArgs e)
        {

        }

        private void S_back_update_Click(object sender, EventArgs e)
        {
            SupplierCRUD sc = new SupplierCRUD();
            sc.Show();
            this.Close();
        }
    }


}

