﻿namespace CYCLE
{
    partial class UpdateSession
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.S_FormatText = new System.Windows.Forms.Label();
            this.S_SessionDate = new System.Windows.Forms.Label();
            this.dateTimePickerSessionU = new System.Windows.Forms.DateTimePicker();
            this.S_Duration = new System.Windows.Forms.Label();
            this.S_DurationInput = new System.Windows.Forms.TextBox();
            this.Topic = new System.Windows.Forms.Label();
            this.S_TopicInput = new System.Windows.Forms.TextBox();
            this.S_Number = new System.Windows.Forms.Label();
            this.S_NumberInput = new System.Windows.Forms.TextBox();
            this.S_Location = new System.Windows.Forms.Label();
            this.Status_MeetingInput = new System.Windows.Forms.TextBox();
            this.S_Back = new System.Windows.Forms.Button();
            this.SU_Update = new System.Windows.Forms.Button();
            this.S_delete = new System.Windows.Forms.Button();
            this.S_Valid = new System.Windows.Forms.Label();
            this.S_Session_Search = new System.Windows.Forms.Button();
            this.SU_LocationEnumInput = new System.Windows.Forms.ComboBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // S_FormatText
            // 
            this.S_FormatText.AutoSize = true;
            this.S_FormatText.BackColor = System.Drawing.Color.Transparent;
            this.S_FormatText.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.S_FormatText.ForeColor = System.Drawing.Color.Navy;
            this.S_FormatText.Location = new System.Drawing.Point(24, 66);
            this.S_FormatText.Name = "S_FormatText";
            this.S_FormatText.Size = new System.Drawing.Size(313, 33);
            this.S_FormatText.TabIndex = 20;
            this.S_FormatText.Text = "Please enter session details";
            this.S_FormatText.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.S_FormatText.Click += new System.EventHandler(this.label1_Click);
            // 
            // S_SessionDate
            // 
            this.S_SessionDate.AutoSize = true;
            this.S_SessionDate.BackColor = System.Drawing.Color.Transparent;
            this.S_SessionDate.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.S_SessionDate.Location = new System.Drawing.Point(12, 151);
            this.S_SessionDate.Name = "S_SessionDate";
            this.S_SessionDate.Size = new System.Drawing.Size(120, 26);
            this.S_SessionDate.TabIndex = 45;
            this.S_SessionDate.Text = "Session Date";
            // 
            // dateTimePickerSessionU
            // 
            this.dateTimePickerSessionU.CustomFormat = "dd/MM/yyyy HH:mm:ss";
            this.dateTimePickerSessionU.Font = new System.Drawing.Font("Calibri", 12F);
            this.dateTimePickerSessionU.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerSessionU.Location = new System.Drawing.Point(155, 152);
            this.dateTimePickerSessionU.Name = "dateTimePickerSessionU";
            this.dateTimePickerSessionU.Size = new System.Drawing.Size(187, 27);
            this.dateTimePickerSessionU.TabIndex = 57;
            // 
            // S_Duration
            // 
            this.S_Duration.AutoSize = true;
            this.S_Duration.BackColor = System.Drawing.Color.Transparent;
            this.S_Duration.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.S_Duration.Location = new System.Drawing.Point(15, 279);
            this.S_Duration.Name = "S_Duration";
            this.S_Duration.Size = new System.Drawing.Size(87, 26);
            this.S_Duration.TabIndex = 58;
            this.S_Duration.Text = "Duration";
            // 
            // S_DurationInput
            // 
            this.S_DurationInput.Location = new System.Drawing.Point(114, 285);
            this.S_DurationInput.Multiline = true;
            this.S_DurationInput.Name = "S_DurationInput";
            this.S_DurationInput.Size = new System.Drawing.Size(185, 25);
            this.S_DurationInput.TabIndex = 59;
            this.S_DurationInput.TextChanged += new System.EventHandler(this.E_FnameInput_TextChanged);
            // 
            // Topic
            // 
            this.Topic.AutoSize = true;
            this.Topic.BackColor = System.Drawing.Color.Transparent;
            this.Topic.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Topic.Location = new System.Drawing.Point(15, 340);
            this.Topic.Name = "Topic";
            this.Topic.Size = new System.Drawing.Size(56, 26);
            this.Topic.TabIndex = 60;
            this.Topic.Text = "Topic";
            // 
            // S_TopicInput
            // 
            this.S_TopicInput.Location = new System.Drawing.Point(114, 340);
            this.S_TopicInput.Multiline = true;
            this.S_TopicInput.Name = "S_TopicInput";
            this.S_TopicInput.Size = new System.Drawing.Size(185, 25);
            this.S_TopicInput.TabIndex = 61;
            // 
            // S_Number
            // 
            this.S_Number.AutoSize = true;
            this.S_Number.BackColor = System.Drawing.Color.Transparent;
            this.S_Number.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.S_Number.Location = new System.Drawing.Point(353, 282);
            this.S_Number.Name = "S_Number";
            this.S_Number.Size = new System.Drawing.Size(150, 26);
            this.S_Number.TabIndex = 62;
            this.S_Number.Text = "Session Number";
            this.S_Number.Click += new System.EventHandler(this.S_Numbrt_Click);
            // 
            // S_NumberInput
            // 
            this.S_NumberInput.Location = new System.Drawing.Point(518, 283);
            this.S_NumberInput.Multiline = true;
            this.S_NumberInput.Name = "S_NumberInput";
            this.S_NumberInput.Size = new System.Drawing.Size(185, 25);
            this.S_NumberInput.TabIndex = 63;
            // 
            // S_Location
            // 
            this.S_Location.AutoSize = true;
            this.S_Location.BackColor = System.Drawing.Color.Transparent;
            this.S_Location.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.S_Location.Location = new System.Drawing.Point(353, 339);
            this.S_Location.Name = "S_Location";
            this.S_Location.Size = new System.Drawing.Size(153, 26);
            this.S_Location.TabIndex = 64;
            this.S_Location.Text = "Session Location";
            // 
            // Status_MeetingInput
            // 
            this.Status_MeetingInput.Location = new System.Drawing.Point(551, 410);
            this.Status_MeetingInput.Name = "Status_MeetingInput";
            this.Status_MeetingInput.Size = new System.Drawing.Size(143, 20);
            this.Status_MeetingInput.TabIndex = 67;
            // 
            // S_Back
            // 
            this.S_Back.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.S_Back.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_Back.ForeColor = System.Drawing.Color.White;
            this.S_Back.Location = new System.Drawing.Point(12, 531);
            this.S_Back.Name = "S_Back";
            this.S_Back.Size = new System.Drawing.Size(140, 68);
            this.S_Back.TabIndex = 68;
            this.S_Back.Text = "Back";
            this.S_Back.UseVisualStyleBackColor = false;
            this.S_Back.Click += new System.EventHandler(this.S_Back_Click);
            // 
            // SU_Update
            // 
            this.SU_Update.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.SU_Update.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.SU_Update.ForeColor = System.Drawing.Color.White;
            this.SU_Update.Location = new System.Drawing.Point(582, 531);
            this.SU_Update.Name = "SU_Update";
            this.SU_Update.Size = new System.Drawing.Size(140, 68);
            this.SU_Update.TabIndex = 69;
            this.SU_Update.Text = "Update Session";
            this.SU_Update.UseVisualStyleBackColor = false;
            this.SU_Update.Click += new System.EventHandler(this.SU_Update_Click);
            // 
            // S_delete
            // 
            this.S_delete.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.S_delete.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_delete.ForeColor = System.Drawing.Color.White;
            this.S_delete.Location = new System.Drawing.Point(419, 531);
            this.S_delete.Name = "S_delete";
            this.S_delete.Size = new System.Drawing.Size(140, 68);
            this.S_delete.TabIndex = 70;
            this.S_delete.Text = "Delete Session";
            this.S_delete.UseVisualStyleBackColor = false;
            this.S_delete.Click += new System.EventHandler(this.S_delete_Click);
            // 
            // S_Valid
            // 
            this.S_Valid.AutoSize = true;
            this.S_Valid.BackColor = System.Drawing.Color.Transparent;
            this.S_Valid.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_Valid.ForeColor = System.Drawing.Color.Navy;
            this.S_Valid.Location = new System.Drawing.Point(159, 200);
            this.S_Valid.Name = "S_Valid";
            this.S_Valid.Size = new System.Drawing.Size(221, 26);
            this.S_Valid.TabIndex = 71;
            this.S_Valid.Text = "Please Insert valid input!";
            this.S_Valid.Click += new System.EventHandler(this.S_Valid_Click);
            // 
            // S_Session_Search
            // 
            this.S_Session_Search.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.S_Session_Search.Font = new System.Drawing.Font("Calibri", 14F);
            this.S_Session_Search.ForeColor = System.Drawing.Color.White;
            this.S_Session_Search.Location = new System.Drawing.Point(386, 151);
            this.S_Session_Search.Name = "S_Session_Search";
            this.S_Session_Search.Size = new System.Drawing.Size(84, 29);
            this.S_Session_Search.TabIndex = 72;
            this.S_Session_Search.Text = "Search";
            this.S_Session_Search.UseVisualStyleBackColor = false;
            this.S_Session_Search.Click += new System.EventHandler(this.S_Session_Search_Click);
            // 
            // SU_LocationEnumInput
            // 
            this.SU_LocationEnumInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SU_LocationEnumInput.Font = new System.Drawing.Font("Calibri", 12F);
            this.SU_LocationEnumInput.FormattingEnabled = true;
            this.SU_LocationEnumInput.Location = new System.Drawing.Point(518, 340);
            this.SU_LocationEnumInput.Name = "SU_LocationEnumInput";
            this.SU_LocationEnumInput.Size = new System.Drawing.Size(187, 27);
            this.SU_LocationEnumInput.TabIndex = 73;
            this.SU_LocationEnumInput.SelectedIndexChanged += new System.EventHandler(this.SU_LocationEnumInput_SelectedIndexChanged_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 74;
            this.pictureBox2.TabStop = false;
            // 
            // UpdateSession
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.SU_LocationEnumInput);
            this.Controls.Add(this.S_Session_Search);
            this.Controls.Add(this.S_Valid);
            this.Controls.Add(this.S_delete);
            this.Controls.Add(this.SU_Update);
            this.Controls.Add(this.S_Back);
            this.Controls.Add(this.Status_MeetingInput);
            this.Controls.Add(this.S_Location);
            this.Controls.Add(this.S_NumberInput);
            this.Controls.Add(this.S_Number);
            this.Controls.Add(this.S_TopicInput);
            this.Controls.Add(this.Topic);
            this.Controls.Add(this.S_DurationInput);
            this.Controls.Add(this.S_Duration);
            this.Controls.Add(this.dateTimePickerSessionU);
            this.Controls.Add(this.S_SessionDate);
            this.Controls.Add(this.S_FormatText);
            this.Name = "UpdateSession";
            this.Text = "UpdateSession";
            this.Load += new System.EventHandler(this.UpdateSession_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label S_FormatText;
        private System.Windows.Forms.Label S_SessionDate;
        private System.Windows.Forms.DateTimePicker dateTimePickerSessionU;
        private System.Windows.Forms.Label S_Duration;
        private System.Windows.Forms.TextBox S_DurationInput;
        private System.Windows.Forms.Label Topic;
        private System.Windows.Forms.TextBox S_TopicInput;
        private System.Windows.Forms.Label S_Number;
        private System.Windows.Forms.TextBox S_NumberInput;
        private System.Windows.Forms.Label S_Location;
        private System.Windows.Forms.TextBox Status_MeetingInput;
        private System.Windows.Forms.Button S_Back;
        private System.Windows.Forms.Button SU_Update;
        private System.Windows.Forms.Button S_delete;
        private System.Windows.Forms.Label S_Valid;
        private System.Windows.Forms.Button S_Session_Search;
        private System.Windows.Forms.ComboBox SU_LocationEnumInput;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}