﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{


    public partial class UpdateLecturer : Form
    {
        private Lecturer L_Exist;
        public UpdateLecturer()
        {
            InitializeComponent();
            Status_comboBox_Input.DataSource = Enum.GetValues(typeof(Status));
            Status_comboBox_Input.SelectedIndex = -1;

            //Hide Buttons
            L_Delete.Hide();
            L_Update.Hide();

            FirstName_Input.Hide();
            LastName_Input.Hide();
            Email_Input.Hide();
            PhoneNum_Input.Hide();
            Status_comboBox_Input.Hide();

            FirstName_Lable.Hide();
            LastName_Lable.Hide();
            Email_Lable.Hide();
            PhoneNumber_Lable.Hide();
            Status_Lable.Hide();

            L_Valid_ID.Hide();
            L_Valid.Hide();
            ViewOptAss_Butt.Hide();
        }

        private void L_Search_Click(object sender, EventArgs e)
        {
            L_Exist = Program.seekLecturer(ID_Input.Text);
            if (L_Exist != null)
            {
                //Show Buttons
                L_Delete.Show();
                L_Update.Show();
                ViewOptAss_Butt.Show();

                //Hide Text Warning
                L_Valid_ID.Hide();

                FirstName_Lable.Show();
                LastName_Lable.Show();
                Email_Lable.Show();
                PhoneNumber_Lable.Show();
                Status_Lable.Show();

                FirstName_Input.Show();
                LastName_Input.Show();
                Email_Input.Show();
                PhoneNum_Input.Show();
                Status_comboBox_Input.Show();

                FirstName_Input.Text = L_Exist.get_FirstName();
                LastName_Input.Text = L_Exist.get_LastName();
                Email_Input.Text = L_Exist.get_Email();
                PhoneNum_Input.Text = L_Exist.get_PhoneNumber();
                Status_comboBox_Input.Text = L_Exist.get_Status().ToString();


            }
            else
            {
                L_Valid_ID.Show();
            }
        }

        private void L_Update_Click(object sender, EventArgs e)
        {
            if (IsValidInput())
            {
                L_Valid.Hide();
                L_Exist.set_FirstName(FirstName_Input.Text);
                L_Exist.set_LastName(LastName_Input.Text);
                L_Exist.set_Email(Email_Input.Text);
                L_Exist.set_PhoneNumber(PhoneNum_Input.Text);
                L_Exist.set_Status((Status)Enum.Parse(typeof(Status), Status_comboBox_Input.Text));
                L_Exist.Update_Lecturer();

                LecturerCRUD lc = new LecturerCRUD();
                lc.Show();
                this.Close();
            }
            else
            {
                L_Valid.Show();
                if (L_Valid.Font.Size <= 20)
                    L_Valid.Font = new Font(L_Valid.Font.FontFamily, L_Valid.Font.Size + 1);
                else if (L_Valid.ForeColor == Color.Red)
                    L_Valid.ForeColor = Color.Gold;
                else
                    L_Valid.ForeColor = Color.Red;
            }
        }

        private void L_Delete_Click(object sender, EventArgs e)
        {

            Status_comboBox_Input.SelectedIndex = 1;
            L_Exist.set_Status((Status)Enum.Parse(typeof(Status), Status_comboBox_Input.Text));
            L_Exist.Update_Lecturer();

            //L_Exist.Delete_Lecturer();

            LecturerCRUD lc = new LecturerCRUD();
            lc.Show();
            this.Close();
        }

        private void L_Back_Click(object sender, EventArgs e)
        {
            LecturerCRUD lc = new LecturerCRUD();
            lc.Show();
            this.Close();
        }

        private bool IsValidInput()
        {
            if (!Int32.TryParse(ID_Input.Text, out int Value) || !Int32.TryParse(PhoneNum_Input.Text, out Value))
                return false; //Making sure ID and PhoneNum are all numbers

            else if (ID_Input.Text == null || FirstName_Input.Text == null || LastName_Input.Text == null || Email_Input.Text == null || PhoneNum_Input.Text == null)
                return false; // Making sure no input is to stay null

            else if (100000000 > int.Parse(ID_Input.Text) || int.Parse(ID_Input.Text) > 999999999)
                return false;// Making sure ID is a number in the right length

            else if (Regex.IsMatch(Email_Input.Text, @"^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$") == false)
                return false;// Making sure the email is in the right format

            else if (Regex.IsMatch(FirstName_Input.Text, @"^[a-zA-Z][a-z]*$") == false || Regex.IsMatch(LastName_Input.Text, @"^[a-zA-Z][a-z]*$") == false)
                return false;// Making sure full name containing only letters

            else if (ID_Input.Text.Length != 9 || PhoneNum_Input.Text.Length != 10)
                return false;// Making sure ID and PhoneNum are the right length

            else
                return true;
        }

        private void UpdateLecturer_Load(object sender, EventArgs e)
        {

        }

        private void ViewOptAss_Butt_Click(object sender, EventArgs e)
        {
            ViewAssining la = new ViewAssining(L_Exist.get_ID());
            la.Owner = this;
            la.Show();
            this.Hide();
        }
    }
}