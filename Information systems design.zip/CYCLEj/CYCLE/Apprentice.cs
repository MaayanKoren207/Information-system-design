﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CYCLE
{
    public class Apprentice
    {
        private string A_ID;
        private string FirstName;
        private string LastName;
        private int Age;
        private string ApprenticeAddress;
        private string Email;
        private string PhoneNumber;
        private ApprenticeStatus ApprenticeStatus;
        private int isCandidate;

        public System.Collections.Generic.List<SortingTest> sortingTests;
        public System.Collections.Generic.List<Feedback> feedbacks;



        public Apprentice(string A_ID, string FirstName, string LastName, int Age, string ApprenticeAddress, string Email, string PhoneNumber, ApprenticeStatus ApprenticeStatus, int isCandidate, bool is_new)
        {
            this.A_ID = A_ID;
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Age = Age;
            this.ApprenticeAddress = ApprenticeAddress;
            this.Email = Email;
            this.PhoneNumber = PhoneNumber;
            this.ApprenticeStatus = ApprenticeStatus;
            this.isCandidate = isCandidate;
            if (is_new)
            {
                this.create_Apprentice();
                Program.Apprentices.Add(this);

            }
        }


        public string getID()
        {
            return this.A_ID;
        }

        public string get_FirstName()
        {
            return this.FirstName;
        }

        public void set_FirstName(string st)
        {
            this.FirstName = st;
        }

        public string get_LastName()
        {
            return this.LastName;
        }

        public void set_LastName(string st)
        {
            this.LastName = st;
        }

        public int get_Age()
        {
            return this.Age;
        }

        public void set_Age(int st)
        {
            this.Age = st;
        }
        public string get_ApprenticeAddress()
        {
            return this.ApprenticeAddress;
        }

        public void set_ApprenticeAddress(string st)
        {
            this.ApprenticeAddress = st;
        }

        public string get_Email()
        {
            return this.Email;
        }

        public void set_Email(string st)
        {
            this.Email = st;
        }

        public string get_PhoneNumber()
        {
            return this.PhoneNumber;
        }

        public void set_PhoneNumber(string st)
        {
            this.PhoneNumber = st;
        }

        public ApprenticeStatus get_ApprenticeStatus()
        {
            return this.ApprenticeStatus;
        }



        public void set_ApprenticeStatus(ApprenticeStatus s)
        {
            this.ApprenticeStatus = s;
        }

        public int get_IsCandidate()
        {
            return this.isCandidate;
        }

        public void set_IsCandidate(int ic)
        {
            this.isCandidate = ic;
        }

        public System.Collections.Generic.List<Feedback> Feedbacks // get and set for the whole list
        {
            get
            {
                if (feedbacks == null)
                    feedbacks = new System.Collections.Generic.List<Feedback>();
                return feedbacks;
            }
            set
            {
                RemoveAllFeedbacks();
                if (value != null)
                {
                    foreach (Feedback oFeedback in value)
                        AddFeedbacks(oFeedback);
                }
            }
        }



        public System.Collections.Generic.List<SortingTest> SortingTests // get and set for the whole list
        {
            get
            {
                if (sortingTests == null)
                {
                    sortingTests = new System.Collections.Generic.List<SortingTest>();
                }
                return sortingTests;
            }
            set
            {
                RemoveAllSortingTests();
                if (value != null)
                {
                    foreach (SortingTest oSortingTest in value)
                        AddSortingTests(oSortingTest);
                }
            }
        }


        public void AddSortingTests(SortingTest newSortingTest)
        {
            if (newSortingTest == null)
                return;
            if (this.sortingTests == null)
                this.sortingTests = new System.Collections.Generic.List<SortingTest>();
            if (!this.sortingTests.Contains(newSortingTest))
            {
                this.sortingTests.Add(newSortingTest);
                newSortingTest.Apprentice = this;
            }

        }
        public void RemoveSortingTests(SortingTest oldSortingTest)
        {
            if (oldSortingTest == null)
                return;
            if (this.sortingTests != null)
                if (this.sortingTests.Contains(oldSortingTest))
                {
                    this.sortingTests.Remove(oldSortingTest);
                    oldSortingTest.Apprentice = null;
                }
        }

        public void RemoveAllSortingTests()
        {
            if (sortingTests != null)
            {
                foreach (SortingTest s in sortingTests)
                    s.Apprentice = null;
                sortingTests.Clear();
            }
        }

        public void AddFeedbacks(Feedback newFeedback)
        {
            if (newFeedback == null)
                return;
            if (this.feedbacks == null)
                this.feedbacks = new System.Collections.Generic.List<Feedback>();
            if (!this.feedbacks.Contains(newFeedback))
            {
                this.feedbacks.Add(newFeedback);
                newFeedback.Apprentice = this;
            }
        }
        public void RemoveFeedbacks(Feedback oldFeedback)
        {
            if (oldFeedback == null)
                return;
            if (this.feedbacks != null)
                if (this.feedbacks.Contains(oldFeedback))
                {
                    this.feedbacks.Remove(oldFeedback);
                    oldFeedback.Apprentice = null;
                }
        }

        public void RemoveAllFeedbacks()
        {
            if (feedbacks != null)
            {
                foreach (Feedback f in feedbacks)
                    f.Apprentice = null;
                feedbacks.Clear();
            }
        }



        public void create_Apprentice()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_add_Apprentice @A_ID, @FirstName, @LastName, @Age, @ApprenticeAddress, @Email, @PhoneNumber, @ApprenticeStatus, @isCandidate";
            c.Parameters.AddWithValue("@A_ID", this.A_ID);
            c.Parameters.AddWithValue("@FirstName", this.FirstName);
            c.Parameters.AddWithValue("@LastName", this.LastName);
            c.Parameters.AddWithValue("@Age", this.Age);
            c.Parameters.AddWithValue("@ApprenticeAddress", this.ApprenticeAddress);
            c.Parameters.AddWithValue("@Email", this.Email);
            c.Parameters.AddWithValue("@PhoneNumber", this.PhoneNumber);
            c.Parameters.AddWithValue("@ApprenticeStatus", this.ApprenticeStatus.ToString());
            c.Parameters.AddWithValue("@isCandidate", this.isCandidate);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Update_Apprentice()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_Update_Apprentice   @A_ID, @FirstName, @LastName, @Age, @ApprenticeAddress, @Email, @PhoneNumber, @ApprenticeStatus, @isCandidate";
            c.Parameters.AddWithValue("@A_ID", this.A_ID);
            c.Parameters.AddWithValue("@FirstName", this.FirstName);
            c.Parameters.AddWithValue("@LastName", this.LastName);
            c.Parameters.AddWithValue("@Age", this.Age);
            c.Parameters.AddWithValue("@ApprenticeAddress", this.ApprenticeAddress);
            c.Parameters.AddWithValue("@Email", this.Email);
            c.Parameters.AddWithValue("@PhoneNumber", this.PhoneNumber);
            c.Parameters.AddWithValue("@ApprenticeStatus", this.ApprenticeStatus.ToString());
            c.Parameters.AddWithValue("@isCandidate", this.isCandidate);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }


        public void Delete_Apprentice()
        {
            Program.Apprentices.Remove(this);
            this.RemoveAllSortingTests();
            this.RemoveAllFeedbacks();
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_delete_Apprentice @A_ID";
            c.Parameters.AddWithValue("A_ID", this.A_ID);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

    }
}



