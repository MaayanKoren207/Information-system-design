﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class ViewAssining : Form
    {
        private Lecturer lecturer;

        public ViewAssining()
        {
            InitializeComponent();

            Ass_DataGrid.Hide();
            Invalid_ID_Lable.Hide();

        }

        public ViewAssining(string id)
        {
            InitializeComponent();

            L_ID_Input.Text = id;

            Ass_DataGrid.Hide();
            Invalid_ID_Lable.Hide();

        }

        private void ViewAss_Butt_Click(object sender, EventArgs e)
        {
            if (L_ID_Input != null)
            {
                lecturer = Program.seekLecturer(L_ID_Input.Text);

                if (lecturer != null)
                {
                    Ass_DataGrid.Show();

                    var assignings = lecturer.get_AssigningByStatus(AssigningStatus.Optional);

                    Ass_DataGrid.Name = "Optional Assignings";
                    Ass_DataGrid.ColumnCount = 5;
                    Ass_DataGrid.Columns[0].Name = "Start time";
                    Ass_DataGrid.Columns[1].Name = "Topic";
                    Ass_DataGrid.Columns[2].Name = "Lecturer Id";
                    Ass_DataGrid.Columns[3].Name = "Lecturer name";
                    Ass_DataGrid.Columns[4].Name = "Status";

                    foreach (var a in assignings)
                    {
                        Ass_DataGrid.Rows.Add(
                            a.Lecture.get_StartTime(),
                            a.Lecture.get_Topic(),
                            a.Lecturer.get_ID(),
                            a.Lecturer.get_FirstName(),
                            a.get_Status());
                    }
                }
                else
                {
                    Invalid_ID_Lable.Show();
                }
            }
            else
            {
                Invalid_ID_Lable.Show();
            }
        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            Form ownerForm = this.Owner;
            ownerForm.Show();
            this.Hide();
        }

        private void ViewAssining_Load(object sender, EventArgs e)
        {

        }

        private void Ass_DataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}