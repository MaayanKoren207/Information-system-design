﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CYCLE
{
    public class CandidateRateByCat
    {
        public SortingTest sortingTest;
        public CategoryOfCandidate categoryOfCandidate;
        private double RateInCat;
        private readonly bool shouldShowSuccess;

        public CandidateRateByCat(SortingTest st, CategoryOfCandidate cat, double RateInCat, bool is_new, bool shouldShowSuccess = true)
        {
            this.SortingTest = st;
            this.CategoryOfCandidate = cat;
            this.RateInCat = RateInCat;
            this.shouldShowSuccess = shouldShowSuccess;

            if (is_new)
            {
                this.create_CandidateRateByCat();
                st.AddCandidateRateByCats(this);
                cat.AddCandidateRateByCats(this);
                Program.CandidateRateByCats.Add(this);
            }

        }

        public double get_RateInCat()
        {
            return RateInCat;
        }

        public void set_RateInCat(double value)
        {
            this.RateInCat = value;
        }

        public SortingTest SortingTest
        {
            get
            {
                return sortingTest;
            }
            set
            {
                if (this.sortingTest == null || !this.sortingTest.Equals(value))
                {
                    if (this.sortingTest != null)
                    {
                        SortingTest oldSortingTest = this.sortingTest;
                        this.sortingTest = null;
                        oldSortingTest.RemoveCandidateRateByCats(this);
                    }
                    if (value != null)
                    {
                        this.sortingTest = value;
                        this.sortingTest.AddCandidateRateByCats(this);
                    }
                }
            }
        }

        public CategoryOfCandidate CategoryOfCandidate
        {
            get
            {
                return categoryOfCandidate;
            }

            set
            {
                if (this.categoryOfCandidate == null || !this.categoryOfCandidate.Equals(value))
                {
                    if (this.categoryOfCandidate != null) 
                    {
                        CategoryOfCandidate oldCategoryOfCandidate = this.categoryOfCandidate;
                        this.categoryOfCandidate = null;
                        oldCategoryOfCandidate.RemoveCandidateRateByCats(this);
                    }
                    if (value != null)
                    {
                        this.categoryOfCandidate = value;
                        this.categoryOfCandidate.AddCandidateRateByCats(this);
                    }
                }
            }
        }

        public void create_CandidateRateByCat()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_add_RatingCandidatesByCategories @TestDate, @A_ID, @SortingCategoryName, @Rate";
            c.Parameters.AddWithValue("@TestDate", this.SortingTest.get_TestDate());
            c.Parameters.AddWithValue("@A_ID", this.SortingTest.Apprentice.getID());
            c.Parameters.AddWithValue("@SortingCategoryName", this.CategoryOfCandidate.get_CategoryOfCandidate().ToString());
            c.Parameters.AddWithValue("@Rate", this.RateInCat);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c, this.shouldShowSuccess);
        }

        public void Update_CandidateRateByCat(bool shouldShowSuccess)
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_Update_RatingCandidatesByCategories @TestDate, @A_ID, @SortingCategoryName, @Rate";
            c.Parameters.AddWithValue("@TestDate", this.SortingTest.get_TestDate());
            c.Parameters.AddWithValue("@A_ID", this.SortingTest.Apprentice.getID());
            c.Parameters.AddWithValue("@SortingCategoryName", this.CategoryOfCandidate.get_CategoryOfCandidate().ToString());
            c.Parameters.AddWithValue("@Rate", this.RateInCat);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c, shouldShowSuccess);
        }

        public void Delete_CandidateRateByCat()
        {
            Program.CandidateRateByCats.Remove(this);
            this.sortingTest?.RemoveCandidateRateByCats(this);
            this.categoryOfCandidate?.RemoveCandidateRateByCats(this);
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_delete_Assigning @TestDate, @A_ID, @SortingCategoryName";
            c.Parameters.AddWithValue("@TestDate", this.SortingTest.get_TestDate());
            c.Parameters.AddWithValue("@A_ID", this.SortingTest.Apprentice.getID());
            c.Parameters.AddWithValue("@SortingCategoryName", this.CategoryOfCandidate.get_CategoryOfCandidate().ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c, this.shouldShowSuccess);
        }
    }
}