﻿namespace CYCLE
{
    partial class AddLecture
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StartTime_Lable = new System.Windows.Forms.Label();
            this.Duration_Lable = new System.Windows.Forms.Label();
            this.Topic_Lable = new System.Windows.Forms.Label();
            this.SessionDT_Lable = new System.Windows.Forms.Label();
            this.StartTime_Input = new System.Windows.Forms.DateTimePicker();
            this.Duration_Input = new System.Windows.Forms.TextBox();
            this.Topic_Input = new System.Windows.Forms.ComboBox();
            this.SessionDT_Input = new System.Windows.Forms.DateTimePicker();
            this.Search_SessionDT_Butt = new System.Windows.Forms.Button();
            this.Back_Butt = new System.Windows.Forms.Button();
            this.AddLecture_Butt = new System.Windows.Forms.Button();
            this.Insert_S_DT_Req_Lable = new System.Windows.Forms.Label();
            this.Invalid_SessionDT_Lable = new System.Windows.Forms.Label();
            this.Ins_L_Info_Lable = new System.Windows.Forms.Label();
            this.Invalid_Lecture_Lable = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.TooLong = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // StartTime_Lable
            // 
            this.StartTime_Lable.AutoSize = true;
            this.StartTime_Lable.BackColor = System.Drawing.Color.Transparent;
            this.StartTime_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.StartTime_Lable.Location = new System.Drawing.Point(64, 253);
            this.StartTime_Lable.Name = "StartTime_Lable";
            this.StartTime_Lable.Size = new System.Drawing.Size(100, 26);
            this.StartTime_Lable.TabIndex = 0;
            this.StartTime_Lable.Text = "Start Time";
            // 
            // Duration_Lable
            // 
            this.Duration_Lable.AutoSize = true;
            this.Duration_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Duration_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Duration_Lable.Location = new System.Drawing.Point(86, 296);
            this.Duration_Lable.Name = "Duration_Lable";
            this.Duration_Lable.Size = new System.Drawing.Size(87, 26);
            this.Duration_Lable.TabIndex = 1;
            this.Duration_Lable.Text = "Duration";
            // 
            // Topic_Lable
            // 
            this.Topic_Lable.AutoSize = true;
            this.Topic_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Topic_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Topic_Lable.Location = new System.Drawing.Point(86, 338);
            this.Topic_Lable.Name = "Topic_Lable";
            this.Topic_Lable.Size = new System.Drawing.Size(56, 26);
            this.Topic_Lable.TabIndex = 2;
            this.Topic_Lable.Text = "Topic";
            // 
            // SessionDT_Lable
            // 
            this.SessionDT_Lable.AutoSize = true;
            this.SessionDT_Lable.BackColor = System.Drawing.Color.Transparent;
            this.SessionDT_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.SessionDT_Lable.Location = new System.Drawing.Point(64, 118);
            this.SessionDT_Lable.Name = "SessionDT_Lable";
            this.SessionDT_Lable.Size = new System.Drawing.Size(120, 26);
            this.SessionDT_Lable.TabIndex = 3;
            this.SessionDT_Lable.Text = "Session Date";
            // 
            // StartTime_Input
            // 
            this.StartTime_Input.CustomFormat = "dd/MM/yyyy HH:mm:ss";
            this.StartTime_Input.Font = new System.Drawing.Font("Calibri", 12F);
            this.StartTime_Input.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.StartTime_Input.Location = new System.Drawing.Point(223, 256);
            this.StartTime_Input.Name = "StartTime_Input";
            this.StartTime_Input.Size = new System.Drawing.Size(185, 27);
            this.StartTime_Input.TabIndex = 4;
            // 
            // Duration_Input
            // 
            this.Duration_Input.Font = new System.Drawing.Font("Calibri", 12F);
            this.Duration_Input.Location = new System.Drawing.Point(223, 302);
            this.Duration_Input.Name = "Duration_Input";
            this.Duration_Input.Size = new System.Drawing.Size(185, 27);
            this.Duration_Input.TabIndex = 5;
            // 
            // Topic_Input
            // 
            this.Topic_Input.BackColor = System.Drawing.Color.White;
            this.Topic_Input.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Topic_Input.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Topic_Input.FormattingEnabled = true;
            this.Topic_Input.Location = new System.Drawing.Point(223, 343);
            this.Topic_Input.Name = "Topic_Input";
            this.Topic_Input.Size = new System.Drawing.Size(185, 27);
            this.Topic_Input.TabIndex = 6;
            // 
            // SessionDT_Input
            // 
            this.SessionDT_Input.CustomFormat = "dd/MM/yyyy HH:mm:ss";
            this.SessionDT_Input.Font = new System.Drawing.Font("Calibri", 12F);
            this.SessionDT_Input.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.SessionDT_Input.Location = new System.Drawing.Point(223, 117);
            this.SessionDT_Input.Name = "SessionDT_Input";
            this.SessionDT_Input.Size = new System.Drawing.Size(185, 27);
            this.SessionDT_Input.TabIndex = 7;
            // 
            // Search_SessionDT_Butt
            // 
            this.Search_SessionDT_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Search_SessionDT_Butt.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Search_SessionDT_Butt.ForeColor = System.Drawing.Color.White;
            this.Search_SessionDT_Butt.Location = new System.Drawing.Point(441, 113);
            this.Search_SessionDT_Butt.Name = "Search_SessionDT_Butt";
            this.Search_SessionDT_Butt.Size = new System.Drawing.Size(128, 34);
            this.Search_SessionDT_Butt.TabIndex = 8;
            this.Search_SessionDT_Butt.Text = "Search";
            this.Search_SessionDT_Butt.UseVisualStyleBackColor = false;
            this.Search_SessionDT_Butt.Click += new System.EventHandler(this.Search_SessionDT_Butt_Click);
            // 
            // Back_Butt
            // 
            this.Back_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Back_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Back_Butt.ForeColor = System.Drawing.Color.White;
            this.Back_Butt.Location = new System.Drawing.Point(26, 531);
            this.Back_Butt.Name = "Back_Butt";
            this.Back_Butt.Size = new System.Drawing.Size(140, 68);
            this.Back_Butt.TabIndex = 9;
            this.Back_Butt.Text = "Back";
            this.Back_Butt.UseVisualStyleBackColor = false;
            this.Back_Butt.Click += new System.EventHandler(this.Back_Butt_Click);
            // 
            // AddLecture_Butt
            // 
            this.AddLecture_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.AddLecture_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.AddLecture_Butt.ForeColor = System.Drawing.Color.White;
            this.AddLecture_Butt.Location = new System.Drawing.Point(582, 531);
            this.AddLecture_Butt.Name = "AddLecture_Butt";
            this.AddLecture_Butt.Size = new System.Drawing.Size(140, 68);
            this.AddLecture_Butt.TabIndex = 10;
            this.AddLecture_Butt.Text = "Add Lecture";
            this.AddLecture_Butt.UseVisualStyleBackColor = false;
            this.AddLecture_Butt.Click += new System.EventHandler(this.AddLecture_Butt_Click);
            // 
            // Insert_S_DT_Req_Lable
            // 
            this.Insert_S_DT_Req_Lable.AutoSize = true;
            this.Insert_S_DT_Req_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Insert_S_DT_Req_Lable.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.Insert_S_DT_Req_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Insert_S_DT_Req_Lable.Location = new System.Drawing.Point(134, 41);
            this.Insert_S_DT_Req_Lable.Name = "Insert_S_DT_Req_Lable";
            this.Insert_S_DT_Req_Lable.Size = new System.Drawing.Size(409, 33);
            this.Insert_S_DT_Req_Lable.TabIndex = 11;
            this.Insert_S_DT_Req_Lable.Text = "Please Insert Session Date And Time";
            // 
            // Invalid_SessionDT_Lable
            // 
            this.Invalid_SessionDT_Lable.AutoSize = true;
            this.Invalid_SessionDT_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Invalid_SessionDT_Lable.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Invalid_SessionDT_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Invalid_SessionDT_Lable.Location = new System.Drawing.Point(176, 150);
            this.Invalid_SessionDT_Lable.Name = "Invalid_SessionDT_Lable";
            this.Invalid_SessionDT_Lable.Size = new System.Drawing.Size(328, 23);
            this.Invalid_SessionDT_Lable.TabIndex = 12;
            this.Invalid_SessionDT_Lable.Text = "Please Insert Valid Session Date And Time";
            // 
            // Ins_L_Info_Lable
            // 
            this.Ins_L_Info_Lable.AutoSize = true;
            this.Ins_L_Info_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Ins_L_Info_Lable.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ins_L_Info_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Ins_L_Info_Lable.Location = new System.Drawing.Point(65, 217);
            this.Ins_L_Info_Lable.Name = "Ins_L_Info_Lable";
            this.Ins_L_Info_Lable.Size = new System.Drawing.Size(281, 26);
            this.Ins_L_Info_Lable.TabIndex = 13;
            this.Ins_L_Info_Lable.Text = "Please Insert The Following Info";
            // 
            // Invalid_Lecture_Lable
            // 
            this.Invalid_Lecture_Lable.AutoSize = true;
            this.Invalid_Lecture_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Invalid_Lecture_Lable.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Invalid_Lecture_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Invalid_Lecture_Lable.Location = new System.Drawing.Point(219, 392);
            this.Invalid_Lecture_Lable.Name = "Invalid_Lecture_Lable";
            this.Invalid_Lecture_Lable.Size = new System.Drawing.Size(196, 23);
            this.Invalid_Lecture_Lable.TabIndex = 14;
            this.Invalid_Lecture_Lable.Text = "Please Insert Valid Input";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 41;
            this.pictureBox2.TabStop = false;
            // 
            // TooLong
            // 
            this.TooLong.AutoSize = true;
            this.TooLong.BackColor = System.Drawing.Color.Transparent;
            this.TooLong.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.TooLong.ForeColor = System.Drawing.Color.Navy;
            this.TooLong.Location = new System.Drawing.Point(422, 304);
            this.TooLong.Name = "TooLong";
            this.TooLong.Size = new System.Drawing.Size(268, 23);
            this.TooLong.TabIndex = 42;
            this.TooLong.Text = "Duration Exceeding Session Time!";
            // 
            // AddLecture
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.TooLong);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Invalid_Lecture_Lable);
            this.Controls.Add(this.Ins_L_Info_Lable);
            this.Controls.Add(this.Invalid_SessionDT_Lable);
            this.Controls.Add(this.Insert_S_DT_Req_Lable);
            this.Controls.Add(this.AddLecture_Butt);
            this.Controls.Add(this.Back_Butt);
            this.Controls.Add(this.Search_SessionDT_Butt);
            this.Controls.Add(this.SessionDT_Input);
            this.Controls.Add(this.Topic_Input);
            this.Controls.Add(this.Duration_Input);
            this.Controls.Add(this.StartTime_Input);
            this.Controls.Add(this.SessionDT_Lable);
            this.Controls.Add(this.Topic_Lable);
            this.Controls.Add(this.Duration_Lable);
            this.Controls.Add(this.StartTime_Lable);
            this.Name = "AddLecture";
            this.Text = "AddLecture";
            this.Load += new System.EventHandler(this.AddLecture_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label StartTime_Lable;
        private System.Windows.Forms.Label Duration_Lable;
        private System.Windows.Forms.Label Topic_Lable;
        private System.Windows.Forms.Label SessionDT_Lable;
        private System.Windows.Forms.DateTimePicker StartTime_Input;
        private System.Windows.Forms.TextBox Duration_Input;
        private System.Windows.Forms.ComboBox Topic_Input;
        private System.Windows.Forms.DateTimePicker SessionDT_Input;
        private System.Windows.Forms.Button Search_SessionDT_Butt;
        private System.Windows.Forms.Button Back_Butt;
        private System.Windows.Forms.Button AddLecture_Butt;
        private System.Windows.Forms.Label Insert_S_DT_Req_Lable;
        private System.Windows.Forms.Label Invalid_SessionDT_Lable;
        private System.Windows.Forms.Label Ins_L_Info_Lable;
        private System.Windows.Forms.Label Invalid_Lecture_Lable;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label TooLong;
    }
}