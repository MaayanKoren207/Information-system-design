﻿namespace CYCLE
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.Login_Butt = new System.Windows.Forms.Button();
            this.Welcome_Lable = new System.Windows.Forms.Label();
            this.UserName_Lable = new System.Windows.Forms.Label();
            this.UserName_Input = new System.Windows.Forms.TextBox();
            this.Password_Lable = new System.Windows.Forms.Label();
            this.Password_Input = new System.Windows.Forms.TextBox();
            this.Invalid_Info_Lable = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Login_Butt
            // 
            this.Login_Butt.BackColor = System.Drawing.Color.Navy;
            this.Login_Butt.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login_Butt.ForeColor = System.Drawing.Color.White;
            this.Login_Butt.Location = new System.Drawing.Point(12, 388);
            this.Login_Butt.Name = "Login_Butt";
            this.Login_Butt.Size = new System.Drawing.Size(89, 45);
            this.Login_Butt.TabIndex = 0;
            this.Login_Butt.Text = "Log In";
            this.Login_Butt.UseVisualStyleBackColor = false;
            this.Login_Butt.Click += new System.EventHandler(this.Login_Butt_Click);
            // 
            // Welcome_Lable
            // 
            this.Welcome_Lable.AutoSize = true;
            this.Welcome_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Welcome_Lable.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Welcome_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Welcome_Lable.Location = new System.Drawing.Point(5, 9);
            this.Welcome_Lable.Name = "Welcome_Lable";
            this.Welcome_Lable.Size = new System.Drawing.Size(361, 39);
            this.Welcome_Lable.TabIndex = 1;
            this.Welcome_Lable.Text = "Welcome To Cycle System ";
            // 
            // UserName_Lable
            // 
            this.UserName_Lable.AutoSize = true;
            this.UserName_Lable.BackColor = System.Drawing.Color.Transparent;
            this.UserName_Lable.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.UserName_Lable.Location = new System.Drawing.Point(14, 131);
            this.UserName_Lable.Name = "UserName_Lable";
            this.UserName_Lable.Size = new System.Drawing.Size(106, 26);
            this.UserName_Lable.TabIndex = 2;
            this.UserName_Lable.Text = "User Name";
            // 
            // UserName_Input
            // 
            this.UserName_Input.Location = new System.Drawing.Point(126, 137);
            this.UserName_Input.Name = "UserName_Input";
            this.UserName_Input.Size = new System.Drawing.Size(164, 20);
            this.UserName_Input.TabIndex = 3;
            // 
            // Password_Lable
            // 
            this.Password_Lable.AutoSize = true;
            this.Password_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Password_Lable.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Password_Lable.Location = new System.Drawing.Point(14, 189);
            this.Password_Lable.Name = "Password_Lable";
            this.Password_Lable.Size = new System.Drawing.Size(93, 26);
            this.Password_Lable.TabIndex = 4;
            this.Password_Lable.Text = "Password";
            // 
            // Password_Input
            // 
            this.Password_Input.Location = new System.Drawing.Point(126, 192);
            this.Password_Input.Name = "Password_Input";
            this.Password_Input.Size = new System.Drawing.Size(164, 20);
            this.Password_Input.TabIndex = 5;
            this.Password_Input.TextChanged += new System.EventHandler(this.Password_Input_TextChanged);
            // 
            // Invalid_Info_Lable
            // 
            this.Invalid_Info_Lable.AutoSize = true;
            this.Invalid_Info_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Invalid_Info_Lable.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Invalid_Info_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Invalid_Info_Lable.Location = new System.Drawing.Point(15, 352);
            this.Invalid_Info_Lable.Name = "Invalid_Info_Lable";
            this.Invalid_Info_Lable.Size = new System.Drawing.Size(350, 23);
            this.Invalid_Info_Lable.TabIndex = 6;
            this.Invalid_Info_Lable.Text = "Please Insert Valid UserName And Password";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(657, 445);
            this.Controls.Add(this.Invalid_Info_Lable);
            this.Controls.Add(this.Password_Input);
            this.Controls.Add(this.Password_Lable);
            this.Controls.Add(this.UserName_Input);
            this.Controls.Add(this.UserName_Lable);
            this.Controls.Add(this.Welcome_Lable);
            this.Controls.Add(this.Login_Butt);
            this.DoubleBuffered = true;
            this.Name = "Login";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Login_Butt;
        private System.Windows.Forms.Label Welcome_Lable;
        private System.Windows.Forms.Label UserName_Lable;
        private System.Windows.Forms.TextBox UserName_Input;
        private System.Windows.Forms.Label Password_Lable;
        private System.Windows.Forms.TextBox Password_Input;
        private System.Windows.Forms.Label Invalid_Info_Lable;
    }
}