﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CYCLE
{
    public enum Status
    {
        Active, //participates in current class
        NonActive //doesn't participate in current class
    }
    
}
