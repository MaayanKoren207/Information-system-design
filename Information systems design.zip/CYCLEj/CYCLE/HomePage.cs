﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    
    public partial class HomePage : Form
    {
        public HomePage()
        {
            InitializeComponent();
        }

        public HomePage(Employee employee)
        {
            InitializeComponent();
            FullName.Text = employee.get_FirstName() + " " + employee.get_LastName();

        }


        private void EmployeesCRUD_Butt_Click(object sender, EventArgs e)
        {

        }
        

        private void LecturersCRUD_Butt_Click(object sender, EventArgs e)
        {
            LecturerCRUD lc = new LecturerCRUD();
            lc.Show();
            this.Hide();
        }

        private void Products_CRUD_Butt_Click(object sender, EventArgs e)
        {
            ProductCRUD pc = new ProductCRUD();
            pc.Show();
            this.Hide();
        }

        private void ApprenticesCRUD_Butt_Click(object sender, EventArgs e)
        {
            ApprenticeCRUD apc = new ApprenticeCRUD();
            apc.Show();
            this.Hide();
        }
        
        private void SuppliersCRUD_Butt_Click(object sender, EventArgs e)
        {
            SupplierCRUD sc = new SupplierCRUD();
            sc.Show();
            this.Hide();
        }
        

        private void HomePage_Load(object sender, EventArgs e)
        {

        }

        private void DashBoard_Butt_Click(object sender, EventArgs e)
        {
            Dashboard d = new Dashboard();
            d.Show();
            this.Hide();
        }

        private void EmployeesCRUD_Butt_Click_1(object sender, EventArgs e)
        {
            EmployeeCRUD d = new EmployeeCRUD();
            d.Show();
            this.Hide();
        }

        private void SuppliersCRUD_Butt_Click_1(object sender, EventArgs e)
        {
            SupplierCRUD d = new SupplierCRUD();
            d.Show();
            this.Hide();
        }

        private void Lectures_Butt_Click(object sender, EventArgs e)
        {
            LectureManage lm = new LectureManage();
            lm.Show();
            this.Hide();
        }

        private void Sessions_Butt_Click(object sender, EventArgs e)
        {
            SessionOptions d = new SessionOptions();
            d.Show();
            this.Hide();
        }

        private void LogOut_Butt_Click(object sender, EventArgs e)
        {
            Login d = new Login();
            d.Show();
            this.Hide();
        }

        private void SortingTest_Butt_Click(object sender, EventArgs e)
        {
            SortingTestCRUD d = new SortingTestCRUD();
            d.Show();
            this.Hide();
        }

        private void Assigning_Butt_Click(object sender, EventArgs e)
        {
            AssigningManage ac = new AssigningManage();
            ac.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            AssigningManage ac = new AssigningManage();
            ac.Show();
            this.Hide();

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            LectureManage lm = new LectureManage();
            lm.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            SessionOptions d = new SessionOptions();
            d.Show();
            this.Hide();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            SortingTestCRUD d = new SortingTestCRUD();
            d.Show();
            this.Hide();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Dashboard d = new Dashboard();
            d.Show();
            this.Hide();
        }
    }
}
