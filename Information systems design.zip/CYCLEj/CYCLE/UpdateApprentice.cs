﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class UpdateApprentice : Form
    {
        private Apprentice A_Exist;
        public UpdateApprentice()
        {
            InitializeComponent();
            List<IsCandidate> ic = new List<IsCandidate>
                {
                new IsCandidate { ic_Text = "כן", ic_Value = 1 },
                new IsCandidate { ic_Text = "לא", ic_Value = 0 }
                };
            Is_C_nput.DataSource = ic;
            Is_C_nput.DisplayMember = "ic_Text";
            Is_C_nput.ValueMember = "ic_Value";
            A_OKText.Hide();
            A_Valid.Hide();
            Is_C_nput.SelectedIndex = -1;


            A_FirstName.Hide();
            A_LastName.Hide();
            A_Age.Hide();
            A_Address.Hide();
            A_Email.Hide();
            A_PhoneNum.Hide();
            Is_Candidate.Hide();
            A_Status.Hide();

            A_FnameInput.Hide();
            A_LnameInput.Hide();
            A_AgeInput.Hide();
            A_AddressInput.Hide();
            A_EmailInput.Hide();
            A_PhoneNumInput.Hide();
            Is_C_nput.Hide();
            A_StatusEnumInput.Hide();


        }

        private void A_IDInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void A_ID_Click(object sender, EventArgs e)
        {

        }

        private void A_ID_Search_Click(object sender, EventArgs e)
        {
            A_Exist = Program.seekAllApprentice(A_IDInput.Text);
            if (A_Exist != null)
            {
                A_OKText.Hide();

                A_FirstName.Show();
                A_LastName.Show();
                A_Age.Show();
                A_Address.Show();
                A_Email.Show();
                A_PhoneNum.Show();
                Is_Candidate.Show();
                A_Status.Show();

                A_FnameInput.Show();
                A_LnameInput.Show();
                A_AgeInput.Show();
                A_AddressInput.Show();
                A_EmailInput.Show();
                A_PhoneNumInput.Show();
                Is_C_nput.Show();
                A_StatusEnumInput.Show();

                A_FnameInput.Text = A_Exist.get_FirstName();
                A_LnameInput.Text = A_Exist.get_LastName();
                A_AgeInput.Text = (A_Exist.get_Age()).ToString();
                A_AddressInput.Text = A_Exist.get_ApprenticeAddress();
                A_EmailInput.Text = A_Exist.get_Email();
                A_PhoneNumInput.Text = A_Exist.get_PhoneNumber();
                if (A_Exist.get_IsCandidate() == 0)
                    Is_C_nput.Text = "לא";
                else
                    Is_C_nput.Text = "כן";
                A_StatusEnumInput.Text = A_Exist.get_ApprenticeStatus().ToString();
            }
            else
                A_OKText.Show();
        }

        private void A_Update_Click(object sender, EventArgs e)
        {
            if (IsValidInput())
            {
                A_Valid.Hide();
                A_Exist.set_FirstName(A_FnameInput.Text);
                A_Exist.set_LastName(A_LnameInput.Text);
                A_Exist.set_Age(int.Parse(A_AgeInput.Text));
                A_Exist.set_ApprenticeAddress(A_AddressInput.Text);
                A_Exist.set_Email(A_EmailInput.Text);
                A_Exist.set_PhoneNumber(A_PhoneNumInput.Text);
                A_Exist.set_IsCandidate((int)Is_C_nput.SelectedValue);
                A_Exist.set_ApprenticeStatus((ApprenticeStatus)Enum.Parse(typeof(ApprenticeStatus), A_StatusEnumInput.Text));
                A_Exist.Update_Apprentice();
                A_IDInput.Clear();
                A_FnameInput.Clear();
                A_LnameInput.Clear();
                A_AgeInput.Clear();
                A_AddressInput.Clear();
                A_EmailInput.Clear();
                A_PhoneNumInput.Clear();
                Is_C_nput.SelectedIndex = -1;
                A_StatusEnumInput.SelectedIndex = -1;
            }
            else
            {
                A_Valid.Show();
                if (A_Valid.Font.Size <= 20)
                    A_Valid.Font = new Font(A_Valid.Font.FontFamily, A_Valid.Font.Size + 1);
                else if (A_Valid.ForeColor == Color.Red)
                    A_Valid.ForeColor = Color.Gold;
                else
                    A_Valid.ForeColor = Color.Red;
            }
        }

        private void A_Delete_Click(object sender, EventArgs e)
        {
            A_StatusEnumInput.SelectedIndex = 1;
            A_Exist.set_ApprenticeStatus((ApprenticeStatus)Enum.Parse(typeof(ApprenticeStatus), A_StatusEnumInput.Text));
            A_Exist.Update_Apprentice();

            // A_Exist.Delete_Apprentice();
            ApprenticeCRUD ac = new ApprenticeCRUD();
            ac.Show();
            this.Close();
        }

        private void A_Back_Click(object sender, EventArgs e)
        {
            ApprenticeCRUD ac = new ApprenticeCRUD();
            ac.Show();
            this.Close();
        }

        private void UpdateApprentice_Load(object sender, EventArgs e)
        {

        }
        private bool IsValidInput()
        {
            if (!Int32.TryParse(A_IDInput.Text, out int Value) || !Int32.TryParse(A_AgeInput.Text, out Value) || !Int32.TryParse(A_PhoneNumInput.Text, out Value))
                return false; //Making sure ID, Age, PhoneNum are all numbers

            else if (A_IDInput.Text == null || A_FnameInput.Text == null || A_LnameInput.Text == null || A_AgeInput.Text == null || A_AddressInput.Text == null || A_EmailInput.Text == null || A_PhoneNumInput.Text == null)
                return false; // Making sure no input is to stay null

            else if (100000000 > int.Parse(A_IDInput.Text) || int.Parse(A_IDInput.Text) > 999999999 || 0 > int.Parse(A_AgeInput.Text) || int.Parse(A_AgeInput.Text) > 121)
                return false;// Making sure ID is a number in the right length, and appropriate age

            else if (Regex.IsMatch(A_EmailInput.Text, @"^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$") == false)
                return false;// Making sure the email is in the right format

            else if (Regex.IsMatch(A_FnameInput.Text, @"^[a-zA-Z][a-z]*$") == false || Regex.IsMatch(A_LnameInput.Text, @"^[a-zA-Z][a-z]*$") == false)
                return false;// Making sure full name containing only letters

            else if (Regex.IsMatch(A_AddressInput.Text, @"^[a-zA-Z0-9 ]*$") == false)
                return false;// Making sure address is in the right format

            else if (A_IDInput.Text.Length != 9 || A_PhoneNumInput.Text.Length != 10)
                return false;// Making sure ID and PhoneNum are the right length

            else
                return true;
        }

        private void Is_C_nput_TextChanged(object sender, EventArgs e)
        {
            string selectedValue = Is_C_nput.Text;
            if (selectedValue == "כן")
                A_StatusEnumInput.DataSource = new List<ApprenticeStatus> { ApprenticeStatus.WatingForAnswer, ApprenticeStatus.Rejected };
            else if (selectedValue == "לא")
                A_StatusEnumInput.DataSource = new List<ApprenticeStatus> { ApprenticeStatus.ParticipatesInCurrentClass, ApprenticeStatus.DoesNotParticipateInCurrentClass };
        }
    }
}
