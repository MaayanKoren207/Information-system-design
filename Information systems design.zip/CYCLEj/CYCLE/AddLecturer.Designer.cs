﻿namespace CYCLE
{
    partial class AddLecturer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.L_ID_Lable = new System.Windows.Forms.Label();
            this.Input_L_ID = new System.Windows.Forms.TextBox();
            this.FirstName_lable = new System.Windows.Forms.Label();
            this.LastName_lable = new System.Windows.Forms.Label();
            this.Email_lable = new System.Windows.Forms.Label();
            this.PhoneNumber_lable = new System.Windows.Forms.Label();
            this.Status_lable = new System.Windows.Forms.Label();
            this.Input_FirstName = new System.Windows.Forms.TextBox();
            this.Input_LastName = new System.Windows.Forms.TextBox();
            this.Input_Email = new System.Windows.Forms.TextBox();
            this.Input_PhoneNumber = new System.Windows.Forms.TextBox();
            this.Input_comboBox_Status = new System.Windows.Forms.ComboBox();
            this.backTo_L_CRUD = new System.Windows.Forms.Button();
            this.Add_Lecturer_B = new System.Windows.Forms.Button();
            this.InValidInput_lable = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Invalid_App_Lable = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // L_ID_Lable
            // 
            this.L_ID_Lable.AutoSize = true;
            this.L_ID_Lable.BackColor = System.Drawing.Color.Transparent;
            this.L_ID_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.L_ID_Lable.Location = new System.Drawing.Point(20, 178);
            this.L_ID_Lable.Name = "L_ID_Lable";
            this.L_ID_Lable.Size = new System.Drawing.Size(98, 26);
            this.L_ID_Lable.TabIndex = 0;
            this.L_ID_Lable.Text = "ID Lecture";
            // 
            // Input_L_ID
            // 
            this.Input_L_ID.Location = new System.Drawing.Point(147, 176);
            this.Input_L_ID.Multiline = true;
            this.Input_L_ID.Name = "Input_L_ID";
            this.Input_L_ID.Size = new System.Drawing.Size(185, 27);
            this.Input_L_ID.TabIndex = 1;
            // 
            // FirstName_lable
            // 
            this.FirstName_lable.AutoSize = true;
            this.FirstName_lable.BackColor = System.Drawing.Color.Transparent;
            this.FirstName_lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.FirstName_lable.Location = new System.Drawing.Point(20, 226);
            this.FirstName_lable.Name = "FirstName_lable";
            this.FirstName_lable.Size = new System.Drawing.Size(105, 26);
            this.FirstName_lable.TabIndex = 2;
            this.FirstName_lable.Text = "First Name";
            // 
            // LastName_lable
            // 
            this.LastName_lable.AutoSize = true;
            this.LastName_lable.BackColor = System.Drawing.Color.Transparent;
            this.LastName_lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.LastName_lable.Location = new System.Drawing.Point(23, 274);
            this.LastName_lable.Name = "LastName_lable";
            this.LastName_lable.Size = new System.Drawing.Size(102, 26);
            this.LastName_lable.TabIndex = 3;
            this.LastName_lable.Text = "Last Name";
            // 
            // Email_lable
            // 
            this.Email_lable.AutoSize = true;
            this.Email_lable.BackColor = System.Drawing.Color.Transparent;
            this.Email_lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Email_lable.Location = new System.Drawing.Point(372, 174);
            this.Email_lable.Name = "Email_lable";
            this.Email_lable.Size = new System.Drawing.Size(59, 26);
            this.Email_lable.TabIndex = 4;
            this.Email_lable.Text = "Email";
            // 
            // PhoneNumber_lable
            // 
            this.PhoneNumber_lable.AutoSize = true;
            this.PhoneNumber_lable.BackColor = System.Drawing.Color.Transparent;
            this.PhoneNumber_lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.PhoneNumber_lable.Location = new System.Drawing.Point(372, 222);
            this.PhoneNumber_lable.Name = "PhoneNumber_lable";
            this.PhoneNumber_lable.Size = new System.Drawing.Size(141, 26);
            this.PhoneNumber_lable.TabIndex = 5;
            this.PhoneNumber_lable.Text = "Phone Number";
            // 
            // Status_lable
            // 
            this.Status_lable.AutoSize = true;
            this.Status_lable.BackColor = System.Drawing.Color.Transparent;
            this.Status_lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Status_lable.Location = new System.Drawing.Point(372, 273);
            this.Status_lable.Name = "Status_lable";
            this.Status_lable.Size = new System.Drawing.Size(65, 26);
            this.Status_lable.TabIndex = 6;
            this.Status_lable.Text = "Status";
            // 
            // Input_FirstName
            // 
            this.Input_FirstName.Location = new System.Drawing.Point(147, 225);
            this.Input_FirstName.Multiline = true;
            this.Input_FirstName.Name = "Input_FirstName";
            this.Input_FirstName.Size = new System.Drawing.Size(185, 27);
            this.Input_FirstName.TabIndex = 7;
            // 
            // Input_LastName
            // 
            this.Input_LastName.Location = new System.Drawing.Point(147, 273);
            this.Input_LastName.Multiline = true;
            this.Input_LastName.Name = "Input_LastName";
            this.Input_LastName.Size = new System.Drawing.Size(185, 27);
            this.Input_LastName.TabIndex = 8;
            // 
            // Input_Email
            // 
            this.Input_Email.Location = new System.Drawing.Point(519, 175);
            this.Input_Email.Multiline = true;
            this.Input_Email.Name = "Input_Email";
            this.Input_Email.Size = new System.Drawing.Size(185, 27);
            this.Input_Email.TabIndex = 9;
            // 
            // Input_PhoneNumber
            // 
            this.Input_PhoneNumber.Location = new System.Drawing.Point(519, 224);
            this.Input_PhoneNumber.Multiline = true;
            this.Input_PhoneNumber.Name = "Input_PhoneNumber";
            this.Input_PhoneNumber.Size = new System.Drawing.Size(185, 27);
            this.Input_PhoneNumber.TabIndex = 10;
            // 
            // Input_comboBox_Status
            // 
            this.Input_comboBox_Status.BackColor = System.Drawing.Color.White;
            this.Input_comboBox_Status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Input_comboBox_Status.Font = new System.Drawing.Font("Calibri", 12F);
            this.Input_comboBox_Status.FormattingEnabled = true;
            this.Input_comboBox_Status.Location = new System.Drawing.Point(519, 269);
            this.Input_comboBox_Status.Name = "Input_comboBox_Status";
            this.Input_comboBox_Status.Size = new System.Drawing.Size(185, 27);
            this.Input_comboBox_Status.TabIndex = 11;
            // 
            // backTo_L_CRUD
            // 
            this.backTo_L_CRUD.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.backTo_L_CRUD.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.backTo_L_CRUD.ForeColor = System.Drawing.Color.White;
            this.backTo_L_CRUD.Location = new System.Drawing.Point(12, 537);
            this.backTo_L_CRUD.Name = "backTo_L_CRUD";
            this.backTo_L_CRUD.Size = new System.Drawing.Size(140, 68);
            this.backTo_L_CRUD.TabIndex = 12;
            this.backTo_L_CRUD.Text = "Back";
            this.backTo_L_CRUD.UseVisualStyleBackColor = false;
            this.backTo_L_CRUD.Click += new System.EventHandler(this.backTo_L_CRUD_Click);
            // 
            // Add_Lecturer_B
            // 
            this.Add_Lecturer_B.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Add_Lecturer_B.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Add_Lecturer_B.ForeColor = System.Drawing.Color.White;
            this.Add_Lecturer_B.Location = new System.Drawing.Point(582, 537);
            this.Add_Lecturer_B.Name = "Add_Lecturer_B";
            this.Add_Lecturer_B.Size = new System.Drawing.Size(140, 68);
            this.Add_Lecturer_B.TabIndex = 13;
            this.Add_Lecturer_B.Text = "Add Lecturer";
            this.Add_Lecturer_B.UseVisualStyleBackColor = false;
            this.Add_Lecturer_B.Click += new System.EventHandler(this.Add_Lecturer_B_Click);
            // 
            // InValidInput_lable
            // 
            this.InValidInput_lable.AutoSize = true;
            this.InValidInput_lable.BackColor = System.Drawing.Color.Transparent;
            this.InValidInput_lable.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.InValidInput_lable.ForeColor = System.Drawing.Color.Navy;
            this.InValidInput_lable.Location = new System.Drawing.Point(22, 80);
            this.InValidInput_lable.Name = "InValidInput_lable";
            this.InValidInput_lable.Size = new System.Drawing.Size(526, 33);
            this.InValidInput_lable.TabIndex = 14;
            this.InValidInput_lable.Text = "Please Insert Input Only In The Correct Format!";
            this.InValidInput_lable.Click += new System.EventHandler(this.InValidInput_lable_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 42;
            this.pictureBox2.TabStop = false;
            // 
            // Invalid_App_Lable
            // 
            this.Invalid_App_Lable.AutoSize = true;
            this.Invalid_App_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Invalid_App_Lable.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Invalid_App_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Invalid_App_Lable.Location = new System.Drawing.Point(143, 329);
            this.Invalid_App_Lable.Name = "Invalid_App_Lable";
            this.Invalid_App_Lable.Size = new System.Drawing.Size(379, 23);
            this.Invalid_App_Lable.TabIndex = 43;
            this.Invalid_App_Lable.Text = "Please Make Sure All fields Are Correctly Written";
            // 
            // AddLecturer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.Invalid_App_Lable);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.InValidInput_lable);
            this.Controls.Add(this.Add_Lecturer_B);
            this.Controls.Add(this.backTo_L_CRUD);
            this.Controls.Add(this.Input_comboBox_Status);
            this.Controls.Add(this.Input_PhoneNumber);
            this.Controls.Add(this.Input_Email);
            this.Controls.Add(this.Input_LastName);
            this.Controls.Add(this.Input_FirstName);
            this.Controls.Add(this.Status_lable);
            this.Controls.Add(this.PhoneNumber_lable);
            this.Controls.Add(this.Email_lable);
            this.Controls.Add(this.LastName_lable);
            this.Controls.Add(this.FirstName_lable);
            this.Controls.Add(this.Input_L_ID);
            this.Controls.Add(this.L_ID_Lable);
            this.Location = new System.Drawing.Point(134, 41);
            this.Name = "AddLecturer";
            this.Text = "AddLecturer";
            this.Load += new System.EventHandler(this.AddLecturer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label L_ID_Lable;
        private System.Windows.Forms.TextBox Input_L_ID;
        private System.Windows.Forms.Label FirstName_lable;
        private System.Windows.Forms.Label LastName_lable;
        private System.Windows.Forms.Label Email_lable;
        private System.Windows.Forms.Label PhoneNumber_lable;
        private System.Windows.Forms.Label Status_lable;
        private System.Windows.Forms.TextBox Input_FirstName;
        private System.Windows.Forms.TextBox Input_LastName;
        private System.Windows.Forms.TextBox Input_Email;
        private System.Windows.Forms.TextBox Input_PhoneNumber;
        private System.Windows.Forms.ComboBox Input_comboBox_Status;
        private System.Windows.Forms.Button backTo_L_CRUD;
        private System.Windows.Forms.Button Add_Lecturer_B;
        private System.Windows.Forms.Label InValidInput_lable;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Invalid_App_Lable;
    }
}