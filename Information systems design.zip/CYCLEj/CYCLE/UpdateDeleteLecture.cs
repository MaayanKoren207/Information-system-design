﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class UpdateDeleteLecture : Form
    {
        private Lecture Lecture_Exist;
        public UpdateDeleteLecture()
        {
            InitializeComponent();
            Topic_Input.DataSource = Enum.GetValues(typeof(LectureTopic));
            Topic_Input.SelectedIndex = -1;


            Duration_Lable.Hide();
            SessionDate_Lable.Hide();
            Duration_Input.Hide();
            SessionDate_Input.Hide();
            GetAverageRate_Butt.Hide();
            AverageRate_Label.Hide();

            Invalid_Lecture_Lable.Hide();
            ViewFeedbacksList_Butt.Hide();
        }

        private void UpdateDeleteLecture_Load(object sender, EventArgs e)
        {

        }

        private void Search_Butt_Click(object sender, EventArgs e)
        {
            if(Topic_Input.SelectedIndex.Equals(-1))
            {
                Topic_Input.SelectedIndex = 0; //default: NLP
                
            }

            Lecture_Exist = Program.seekLecture((DateTime.Parse(StartTime_Input.Text)), (LectureTopic)Enum.Parse(typeof(LectureTopic), Topic_Input.Text));

            if (Lecture_Exist != null)
            {
                Invalid_Lecture_Lable.Hide();

                Duration_Lable.Show();
                Duration_Input.Show();
                Duration_Input.Text = (Lecture_Exist.get_Duration()).ToString();

                SessionDate_Lable.Show();
                SessionDate_Input.Show();
                SessionDate_Input.Text = (Lecture_Exist.Session.get_SessionDate()).ToString();
                SessionDate_Input.Value = StartTime_Input.Value;

                 ViewFeedbacksList_Butt.Show();
                GetAverageRate_Butt.Show();

            }
            else
            {
                Invalid_Lecture_Lable.Show();
            }

        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            LectureManage ac = new LectureManage();
            ac.Show();
            this.Close();
        }

        private void Delete_Butt_Click(object sender, EventArgs e)
        {

        }

        private void ViewFeedbacksList_Butt_Click(object sender, EventArgs e)
        {
            
        }

        private void GetAverageRate_Butt_Click(object sender, EventArgs e)
        {
        }

        private void GetAverageRate_Butt_Click_1(object sender, EventArgs e)
        {
            double avRate = Lecture_Exist.get_AverageRate();
            AverageRate_Label.Text = avRate.ToString();
            AverageRate_Label.Show();
        }

        private void ViewFeedbacksList_Butt_Click_1(object sender, EventArgs e)
        {
            ViewLectureFeedbacks v = new ViewLectureFeedbacks(Lecture_Exist);
            v.Show();
            this.Hide();
        }
    }
}
