﻿namespace CYCLE
{
    partial class UpdateApprentice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.A_Update = new System.Windows.Forms.Button();
            this.A_PhoneNumInput = new System.Windows.Forms.TextBox();
            this.A_EmailInput = new System.Windows.Forms.TextBox();
            this.A_AddressInput = new System.Windows.Forms.TextBox();
            this.A_AgeInput = new System.Windows.Forms.TextBox();
            this.A_LnameInput = new System.Windows.Forms.TextBox();
            this.A_FnameInput = new System.Windows.Forms.TextBox();
            this.A_IDInput = new System.Windows.Forms.TextBox();
            this.A_Status = new System.Windows.Forms.Label();
            this.A_PhoneNum = new System.Windows.Forms.Label();
            this.A_Email = new System.Windows.Forms.Label();
            this.A_Address = new System.Windows.Forms.Label();
            this.A_Age = new System.Windows.Forms.Label();
            this.A_LastName = new System.Windows.Forms.Label();
            this.A_FirstName = new System.Windows.Forms.Label();
            this.A_ID = new System.Windows.Forms.Label();
            this.A_StatusEnumInput = new System.Windows.Forms.ComboBox();
            this.A_ID_Search = new System.Windows.Forms.Button();
            this.A_Delete = new System.Windows.Forms.Button();
            this.A_Back = new System.Windows.Forms.Button();
            this.A_OKText = new System.Windows.Forms.Label();
            this.A_Valid = new System.Windows.Forms.Label();
            this.Is_Candidate = new System.Windows.Forms.Label();
            this.Is_C_nput = new System.Windows.Forms.ComboBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // A_Update
            // 
            this.A_Update.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.A_Update.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_Update.ForeColor = System.Drawing.Color.White;
            this.A_Update.Location = new System.Drawing.Point(582, 531);
            this.A_Update.Name = "A_Update";
            this.A_Update.Size = new System.Drawing.Size(140, 68);
            this.A_Update.TabIndex = 33;
            this.A_Update.Text = "Update Apprentice";
            this.A_Update.UseVisualStyleBackColor = false;
            this.A_Update.Click += new System.EventHandler(this.A_Update_Click);
            // 
            // A_PhoneNumInput
            // 
            this.A_PhoneNumInput.Location = new System.Drawing.Point(522, 275);
            this.A_PhoneNumInput.Multiline = true;
            this.A_PhoneNumInput.Name = "A_PhoneNumInput";
            this.A_PhoneNumInput.Size = new System.Drawing.Size(185, 25);
            this.A_PhoneNumInput.TabIndex = 8;
            // 
            // A_EmailInput
            // 
            this.A_EmailInput.Location = new System.Drawing.Point(522, 230);
            this.A_EmailInput.Multiline = true;
            this.A_EmailInput.Name = "A_EmailInput";
            this.A_EmailInput.Size = new System.Drawing.Size(185, 25);
            this.A_EmailInput.TabIndex = 7;
            // 
            // A_AddressInput
            // 
            this.A_AddressInput.Location = new System.Drawing.Point(155, 382);
            this.A_AddressInput.Multiline = true;
            this.A_AddressInput.Name = "A_AddressInput";
            this.A_AddressInput.Size = new System.Drawing.Size(185, 25);
            this.A_AddressInput.TabIndex = 6;
            // 
            // A_AgeInput
            // 
            this.A_AgeInput.Location = new System.Drawing.Point(155, 330);
            this.A_AgeInput.Multiline = true;
            this.A_AgeInput.Name = "A_AgeInput";
            this.A_AgeInput.Size = new System.Drawing.Size(185, 25);
            this.A_AgeInput.TabIndex = 5;
            // 
            // A_LnameInput
            // 
            this.A_LnameInput.Location = new System.Drawing.Point(155, 276);
            this.A_LnameInput.Multiline = true;
            this.A_LnameInput.Name = "A_LnameInput";
            this.A_LnameInput.Size = new System.Drawing.Size(185, 25);
            this.A_LnameInput.TabIndex = 4;
            // 
            // A_FnameInput
            // 
            this.A_FnameInput.Location = new System.Drawing.Point(155, 227);
            this.A_FnameInput.Multiline = true;
            this.A_FnameInput.Name = "A_FnameInput";
            this.A_FnameInput.Size = new System.Drawing.Size(185, 25);
            this.A_FnameInput.TabIndex = 3;
            // 
            // A_IDInput
            // 
            this.A_IDInput.Location = new System.Drawing.Point(166, 114);
            this.A_IDInput.Multiline = true;
            this.A_IDInput.Name = "A_IDInput";
            this.A_IDInput.Size = new System.Drawing.Size(185, 25);
            this.A_IDInput.TabIndex = 1;
            this.A_IDInput.TextChanged += new System.EventHandler(this.A_IDInput_TextChanged);
            // 
            // A_Status
            // 
            this.A_Status.AutoSize = true;
            this.A_Status.BackColor = System.Drawing.Color.Transparent;
            this.A_Status.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_Status.Location = new System.Drawing.Point(361, 376);
            this.A_Status.Name = "A_Status";
            this.A_Status.Size = new System.Drawing.Size(65, 26);
            this.A_Status.TabIndex = 25;
            this.A_Status.Text = "Status";
            // 
            // A_PhoneNum
            // 
            this.A_PhoneNum.AutoSize = true;
            this.A_PhoneNum.BackColor = System.Drawing.Color.Transparent;
            this.A_PhoneNum.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_PhoneNum.Location = new System.Drawing.Point(359, 276);
            this.A_PhoneNum.Name = "A_PhoneNum";
            this.A_PhoneNum.Size = new System.Drawing.Size(141, 26);
            this.A_PhoneNum.TabIndex = 24;
            this.A_PhoneNum.Text = "Phone Number";
            // 
            // A_Email
            // 
            this.A_Email.AutoSize = true;
            this.A_Email.BackColor = System.Drawing.Color.Transparent;
            this.A_Email.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_Email.Location = new System.Drawing.Point(359, 224);
            this.A_Email.Name = "A_Email";
            this.A_Email.Size = new System.Drawing.Size(157, 26);
            this.A_Email.TabIndex = 23;
            this.A_Email.Text = "Email Apprentice";
            // 
            // A_Address
            // 
            this.A_Address.AutoSize = true;
            this.A_Address.BackColor = System.Drawing.Color.Transparent;
            this.A_Address.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_Address.Location = new System.Drawing.Point(11, 385);
            this.A_Address.Name = "A_Address";
            this.A_Address.Size = new System.Drawing.Size(79, 26);
            this.A_Address.TabIndex = 22;
            this.A_Address.Text = "Address";
            // 
            // A_Age
            // 
            this.A_Age.AutoSize = true;
            this.A_Age.BackColor = System.Drawing.Color.Transparent;
            this.A_Age.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_Age.Location = new System.Drawing.Point(7, 328);
            this.A_Age.Name = "A_Age";
            this.A_Age.Size = new System.Drawing.Size(142, 26);
            this.A_Age.TabIndex = 21;
            this.A_Age.Text = "Apprentice Age";
            // 
            // A_LastName
            // 
            this.A_LastName.AutoSize = true;
            this.A_LastName.BackColor = System.Drawing.Color.Transparent;
            this.A_LastName.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_LastName.Location = new System.Drawing.Point(7, 277);
            this.A_LastName.Name = "A_LastName";
            this.A_LastName.Size = new System.Drawing.Size(102, 26);
            this.A_LastName.TabIndex = 20;
            this.A_LastName.Text = "Last Name";
            // 
            // A_FirstName
            // 
            this.A_FirstName.AutoSize = true;
            this.A_FirstName.BackColor = System.Drawing.Color.Transparent;
            this.A_FirstName.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_FirstName.Location = new System.Drawing.Point(9, 225);
            this.A_FirstName.Name = "A_FirstName";
            this.A_FirstName.Size = new System.Drawing.Size(105, 26);
            this.A_FirstName.TabIndex = 19;
            this.A_FirstName.Text = "First Name";
            // 
            // A_ID
            // 
            this.A_ID.AutoSize = true;
            this.A_ID.BackColor = System.Drawing.Color.Transparent;
            this.A_ID.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_ID.Location = new System.Drawing.Point(13, 109);
            this.A_ID.Name = "A_ID";
            this.A_ID.Size = new System.Drawing.Size(128, 26);
            this.A_ID.TabIndex = 18;
            this.A_ID.Text = "Apprentice ID";
            this.A_ID.Click += new System.EventHandler(this.A_ID_Click);
            // 
            // A_StatusEnumInput
            // 
            this.A_StatusEnumInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.A_StatusEnumInput.Font = new System.Drawing.Font("Calibri", 12F);
            this.A_StatusEnumInput.FormattingEnabled = true;
            this.A_StatusEnumInput.Location = new System.Drawing.Point(523, 375);
            this.A_StatusEnumInput.Name = "A_StatusEnumInput";
            this.A_StatusEnumInput.Size = new System.Drawing.Size(185, 27);
            this.A_StatusEnumInput.TabIndex = 9;
            // 
            // A_ID_Search
            // 
            this.A_ID_Search.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.A_ID_Search.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A_ID_Search.ForeColor = System.Drawing.Color.White;
            this.A_ID_Search.Location = new System.Drawing.Point(394, 111);
            this.A_ID_Search.Name = "A_ID_Search";
            this.A_ID_Search.Size = new System.Drawing.Size(106, 28);
            this.A_ID_Search.TabIndex = 2;
            this.A_ID_Search.Text = "Search";
            this.A_ID_Search.UseVisualStyleBackColor = false;
            this.A_ID_Search.Click += new System.EventHandler(this.A_ID_Search_Click);
            // 
            // A_Delete
            // 
            this.A_Delete.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.A_Delete.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_Delete.ForeColor = System.Drawing.Color.White;
            this.A_Delete.Location = new System.Drawing.Point(420, 531);
            this.A_Delete.Name = "A_Delete";
            this.A_Delete.Size = new System.Drawing.Size(140, 68);
            this.A_Delete.TabIndex = 35;
            this.A_Delete.Text = "Delete Apprentice";
            this.A_Delete.UseVisualStyleBackColor = false;
            this.A_Delete.Click += new System.EventHandler(this.A_Delete_Click);
            // 
            // A_Back
            // 
            this.A_Back.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.A_Back.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_Back.ForeColor = System.Drawing.Color.White;
            this.A_Back.Location = new System.Drawing.Point(15, 531);
            this.A_Back.Name = "A_Back";
            this.A_Back.Size = new System.Drawing.Size(140, 68);
            this.A_Back.TabIndex = 36;
            this.A_Back.Text = "Back";
            this.A_Back.UseVisualStyleBackColor = false;
            this.A_Back.Click += new System.EventHandler(this.A_Back_Click);
            // 
            // A_OKText
            // 
            this.A_OKText.AutoSize = true;
            this.A_OKText.BackColor = System.Drawing.Color.Transparent;
            this.A_OKText.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.A_OKText.ForeColor = System.Drawing.Color.Navy;
            this.A_OKText.Location = new System.Drawing.Point(12, 44);
            this.A_OKText.Name = "A_OKText";
            this.A_OKText.Size = new System.Drawing.Size(384, 33);
            this.A_OKText.TabIndex = 38;
            this.A_OKText.Text = "Please Input A Valid Apprentice ID";
            // 
            // A_Valid
            // 
            this.A_Valid.AutoSize = true;
            this.A_Valid.BackColor = System.Drawing.Color.Transparent;
            this.A_Valid.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_Valid.ForeColor = System.Drawing.Color.Navy;
            this.A_Valid.Location = new System.Drawing.Point(130, 159);
            this.A_Valid.Name = "A_Valid";
            this.A_Valid.Size = new System.Drawing.Size(221, 26);
            this.A_Valid.TabIndex = 39;
            this.A_Valid.Text = "Please Insert valid input!";
            // 
            // Is_Candidate
            // 
            this.Is_Candidate.AutoSize = true;
            this.Is_Candidate.BackColor = System.Drawing.Color.Transparent;
            this.Is_Candidate.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Is_Candidate.Location = new System.Drawing.Point(361, 323);
            this.Is_Candidate.Name = "Is_Candidate";
            this.Is_Candidate.Size = new System.Drawing.Size(116, 26);
            this.Is_Candidate.TabIndex = 40;
            this.Is_Candidate.Text = "Is Candidate";
            // 
            // Is_C_nput
            // 
            this.Is_C_nput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Is_C_nput.Font = new System.Drawing.Font("Calibri", 12F);
            this.Is_C_nput.FormattingEnabled = true;
            this.Is_C_nput.Location = new System.Drawing.Point(523, 321);
            this.Is_C_nput.Name = "Is_C_nput";
            this.Is_C_nput.Size = new System.Drawing.Size(185, 27);
            this.Is_C_nput.TabIndex = 41;
            this.Is_C_nput.TextChanged += new System.EventHandler(this.Is_C_nput_TextChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 42;
            this.pictureBox2.TabStop = false;
            // 
            // UpdateApprentice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Is_C_nput);
            this.Controls.Add(this.Is_Candidate);
            this.Controls.Add(this.A_Valid);
            this.Controls.Add(this.A_OKText);
            this.Controls.Add(this.A_Back);
            this.Controls.Add(this.A_Delete);
            this.Controls.Add(this.A_ID_Search);
            this.Controls.Add(this.A_Update);
            this.Controls.Add(this.A_PhoneNumInput);
            this.Controls.Add(this.A_EmailInput);
            this.Controls.Add(this.A_AddressInput);
            this.Controls.Add(this.A_AgeInput);
            this.Controls.Add(this.A_LnameInput);
            this.Controls.Add(this.A_FnameInput);
            this.Controls.Add(this.A_IDInput);
            this.Controls.Add(this.A_Status);
            this.Controls.Add(this.A_PhoneNum);
            this.Controls.Add(this.A_Email);
            this.Controls.Add(this.A_Address);
            this.Controls.Add(this.A_Age);
            this.Controls.Add(this.A_LastName);
            this.Controls.Add(this.A_FirstName);
            this.Controls.Add(this.A_ID);
            this.Controls.Add(this.A_StatusEnumInput);
            this.Name = "UpdateApprentice";
            this.Text = "UpdateApprentice";
            this.Load += new System.EventHandler(this.UpdateApprentice_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button A_Update;
        private System.Windows.Forms.TextBox A_PhoneNumInput;
        private System.Windows.Forms.TextBox A_EmailInput;
        private System.Windows.Forms.TextBox A_AddressInput;
        private System.Windows.Forms.TextBox A_AgeInput;
        private System.Windows.Forms.TextBox A_LnameInput;
        private System.Windows.Forms.TextBox A_FnameInput;
        private System.Windows.Forms.TextBox A_IDInput;
        private System.Windows.Forms.Label A_Status;
        private System.Windows.Forms.Label A_PhoneNum;
        private System.Windows.Forms.Label A_Email;
        private System.Windows.Forms.Label A_Address;
        private System.Windows.Forms.Label A_Age;
        private System.Windows.Forms.Label A_LastName;
        private System.Windows.Forms.Label A_FirstName;
        private System.Windows.Forms.Label A_ID;
        private System.Windows.Forms.ComboBox A_StatusEnumInput;
        private System.Windows.Forms.Button A_ID_Search;
        private System.Windows.Forms.Button A_Delete;
        private System.Windows.Forms.Button A_Back;
        private System.Windows.Forms.Label A_OKText;
        private System.Windows.Forms.Label A_Valid;
        private System.Windows.Forms.Label Is_Candidate;
        private System.Windows.Forms.ComboBox Is_C_nput;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}