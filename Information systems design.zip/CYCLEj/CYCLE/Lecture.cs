﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CYCLE
{
    public class Lecture
    {
        private DateTime StartTime;
        private int Duration;
        private LectureTopic LectureTopic;
        public Session session;

        public System.Collections.Generic.List<Assigning> assignings;
        public System.Collections.Generic.List<Feedback> feedbacks;


        public Lecture(DateTime StartTime, int Duration, LectureTopic LectureTopic, Session s, bool is_new)
        {
            this.StartTime = StartTime;
            this.Duration = Duration;
            this.LectureTopic = LectureTopic;
            this.Session = s;
            if (is_new)
            {
                this.create_Lecture();
                s.AddLectures(this);
                Program.Lectures.Add(this);
            }
        }

        public DateTime get_StartTime()
        {
            return this.StartTime;
        }

        public LectureTopic get_Topic()
        {
            return this.LectureTopic;
        }

        public int get_Duration()
        {
            return this.Duration;
        }

        public double get_AverageRate()
        {
            double AvRate = 0;

            if (this.feedbacks != null)
            {
                int numOfFeedbacks = this.feedbacks.Count;
                double sumRate = 0;

                foreach (Feedback f in feedbacks)
                {
                    int Rate = f.get_Rate();
                    sumRate = sumRate + Rate;
                }
                AvRate = (sumRate) / (numOfFeedbacks);
            }
            return AvRate;
        }


        public Session Session
        {
            get
            {
                return session;
            }
            set
            {
                if (this.session == null || !this.session.Equals(value))
                {
                    if (this.session != null) // remove the lecture from the exist Session's list
                    {
                        Session oldSession = this.session;
                        this.session = null;
                        oldSession.RemoveLectures(this);
                    }
                    if (value != null)
                    {
                        this.session = value;
                        this.session.AddLectures(this);
                    }
                }
            }
        }

        public System.Collections.Generic.List<Feedback> Feedbacks // get and set for the whole list
        {
            get
            {
                if (feedbacks == null)
                    feedbacks = new System.Collections.Generic.List<Feedback>();
                return feedbacks;
            }
            set
            {
                RemoveAllFeedbacks();
                if (value != null)
                {
                    foreach (Feedback oFeedback in value)
                        AddFeedbacks(oFeedback);
                }
            }
        }

        public System.Collections.Generic.List<Assigning> Assignings // get and set for the whole list
        {
            get
            {
                if (assignings == null)
                    assignings = new System.Collections.Generic.List<Assigning>();
                return assignings;
            }
            set
            {
                RemoveAllAssignings();
                if (value != null)
                {
                    foreach (Assigning oAssigning in value)
                        AddAssignings(oAssigning);
                }
            }
        }

        public List<Assigning> get_AssigningByStatus(AssigningStatus status)
        {
            List<Assigning> list = new List<Assigning>();

            foreach (Assigning a in Assignings)
            {
                if (a.get_Status() == status)
                {
                    list.Add(a);
                }
            }
            return list;
        }


        public void AddAssignings(Assigning newAssigning)
        {
            if (newAssigning == null)
                return;
            if (this.assignings == null)
                this.assignings = new System.Collections.Generic.List<Assigning>();
            if (!this.assignings.Contains(newAssigning))
            {
                this.assignings.Add(newAssigning);
                newAssigning.Lecture = this;
            }
        }
        public void RemoveAssignings(Assigning oldAssigning)
        {
            if (oldAssigning == null)
                return;
            if (this.assignings != null)
                if (this.assignings.Contains(oldAssigning))
                {
                    this.assignings.Remove(oldAssigning);
                    oldAssigning.Lecture = null;
                }
        }

        public void RemoveAllAssignings()
        {
            if (assignings != null)
            {
                foreach (Assigning a in assignings)
                    a.Lecture = null;
                assignings.Clear();
            }
        }


        public void AddFeedbacks(Feedback newFeedback)
        {
            if (newFeedback == null)
                return;
            if (this.feedbacks == null)
                this.feedbacks = new System.Collections.Generic.List<Feedback>();
            if (!this.feedbacks.Contains(newFeedback))
            {
                this.feedbacks.Add(newFeedback);
                newFeedback.Lecture = this;
            }
        }
        public void RemoveFeedbacks(Feedback oldFeedback)
        {
            if (oldFeedback == null)
                return;
            if (this.feedbacks != null)
                if (this.feedbacks.Contains(oldFeedback))
                {
                    this.feedbacks.Remove(oldFeedback);
                    oldFeedback.Lecture = null;
                }
        }

        public void RemoveAllFeedbacks()
        {
            if (feedbacks != null)
            {
                foreach (Feedback f in feedbacks)
                    f.Lecture = null;
                feedbacks.Clear();
            }
        }

        public void create_Lecture()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_add_Lecture @StartTime, @Duration, @Topic, @SessionDate";
            c.Parameters.AddWithValue("@StartTime", this.StartTime);
            c.Parameters.AddWithValue("@Duration", this.Duration);
            c.Parameters.AddWithValue("@Topic", this.LectureTopic.ToString());
            c.Parameters.AddWithValue("@SessionDate", this.session.get_SessionDate());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Update_Lecture()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_Update_Lecture @StartTime, @Duration, @Topic, @SessionDate";
            c.Parameters.AddWithValue("@StartTime", this.StartTime);
            c.Parameters.AddWithValue("@Duration", this.Duration);
            c.Parameters.AddWithValue("@Topic", this.LectureTopic.ToString());
            c.Parameters.AddWithValue("@SessionDate", this.session.get_SessionDate());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Delete_Lecture()
        {
            Program.Lectures.Remove(this);
            this.session?.RemoveLectures(this); // ? means if != null
            this.RemoveAllAssignings();
            this.RemoveAllFeedbacks();
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_delete_Lecture @StartTime, @Topic";
            c.Parameters.AddWithValue("@StartTime", this.StartTime);
            c.Parameters.AddWithValue("@Topic", this.LectureTopic.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

    }

}

