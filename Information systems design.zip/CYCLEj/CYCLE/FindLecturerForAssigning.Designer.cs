﻿namespace CYCLE
{
    partial class FindLecturerForAssigning
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Ins_LectureInfo_Lable = new System.Windows.Forms.Label();
            this.StartTime_Lable = new System.Windows.Forms.Label();
            this.Topic_Lable = new System.Windows.Forms.Label();
            this.StartTime_Input = new System.Windows.Forms.DateTimePicker();
            this.Invalid_Lecture_Info_Lable = new System.Windows.Forms.Label();
            this.Find_Butt = new System.Windows.Forms.Button();
            this.Topic_Input = new System.Windows.Forms.ComboBox();
            this.DataGridView_Lecturers = new System.Windows.Forms.DataGridView();
            this.Back_Butt = new System.Windows.Forms.Button();
            this.NewAssigning_Butt = new System.Windows.Forms.Button();
            this.SendRequest_Butt = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView_Lecturers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Ins_LectureInfo_Lable
            // 
            this.Ins_LectureInfo_Lable.AutoSize = true;
            this.Ins_LectureInfo_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Ins_LectureInfo_Lable.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.Ins_LectureInfo_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Ins_LectureInfo_Lable.Location = new System.Drawing.Point(187, 28);
            this.Ins_LectureInfo_Lable.Name = "Ins_LectureInfo_Lable";
            this.Ins_LectureInfo_Lable.Size = new System.Drawing.Size(358, 33);
            this.Ins_LectureInfo_Lable.TabIndex = 0;
            this.Ins_LectureInfo_Lable.Text = "Please Insert The Following Info";
            // 
            // StartTime_Lable
            // 
            this.StartTime_Lable.AutoSize = true;
            this.StartTime_Lable.BackColor = System.Drawing.Color.Transparent;
            this.StartTime_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.StartTime_Lable.Location = new System.Drawing.Point(130, 83);
            this.StartTime_Lable.Name = "StartTime_Lable";
            this.StartTime_Lable.Size = new System.Drawing.Size(100, 26);
            this.StartTime_Lable.TabIndex = 1;
            this.StartTime_Lable.Text = "Start Time";
            // 
            // Topic_Lable
            // 
            this.Topic_Lable.AutoSize = true;
            this.Topic_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Topic_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Topic_Lable.Location = new System.Drawing.Point(130, 127);
            this.Topic_Lable.Name = "Topic_Lable";
            this.Topic_Lable.Size = new System.Drawing.Size(56, 26);
            this.Topic_Lable.TabIndex = 2;
            this.Topic_Lable.Text = "Topic";
            // 
            // StartTime_Input
            // 
            this.StartTime_Input.CalendarFont = new System.Drawing.Font("Calibri", 12F);
            this.StartTime_Input.CustomFormat = "dd/MM/yyyy HH:mm:ss";
            this.StartTime_Input.Font = new System.Drawing.Font("Calibri", 12F);
            this.StartTime_Input.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.StartTime_Input.Location = new System.Drawing.Point(236, 83);
            this.StartTime_Input.Name = "StartTime_Input";
            this.StartTime_Input.Size = new System.Drawing.Size(185, 27);
            this.StartTime_Input.TabIndex = 3;
            // 
            // Invalid_Lecture_Info_Lable
            // 
            this.Invalid_Lecture_Info_Lable.AutoSize = true;
            this.Invalid_Lecture_Info_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Invalid_Lecture_Info_Lable.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Invalid_Lecture_Info_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Invalid_Lecture_Info_Lable.Location = new System.Drawing.Point(215, 173);
            this.Invalid_Lecture_Info_Lable.Name = "Invalid_Lecture_Info_Lable";
            this.Invalid_Lecture_Info_Lable.Size = new System.Drawing.Size(274, 23);
            this.Invalid_Lecture_Info_Lable.TabIndex = 5;
            this.Invalid_Lecture_Info_Lable.Text = "Please Insert Valid Info for Lecture";
            // 
            // Find_Butt
            // 
            this.Find_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Find_Butt.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Find_Butt.ForeColor = System.Drawing.Color.White;
            this.Find_Butt.Location = new System.Drawing.Point(439, 83);
            this.Find_Butt.Name = "Find_Butt";
            this.Find_Butt.Size = new System.Drawing.Size(131, 57);
            this.Find_Butt.TabIndex = 6;
            this.Find_Butt.Text = "Find Available Lecturers";
            this.Find_Butt.UseVisualStyleBackColor = false;
            this.Find_Butt.Click += new System.EventHandler(this.Find_Butt_Click);
            // 
            // Topic_Input
            // 
            this.Topic_Input.BackColor = System.Drawing.Color.White;
            this.Topic_Input.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Topic_Input.Font = new System.Drawing.Font("Calibri", 12F);
            this.Topic_Input.FormattingEnabled = true;
            this.Topic_Input.Location = new System.Drawing.Point(236, 126);
            this.Topic_Input.Name = "Topic_Input";
            this.Topic_Input.Size = new System.Drawing.Size(185, 27);
            this.Topic_Input.TabIndex = 7;
            // 
            // DataGridView_Lecturers
            // 
            this.DataGridView_Lecturers.BackgroundColor = System.Drawing.Color.White;
            this.DataGridView_Lecturers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView_Lecturers.Location = new System.Drawing.Point(78, 225);
            this.DataGridView_Lecturers.Name = "DataGridView_Lecturers";
            this.DataGridView_Lecturers.Size = new System.Drawing.Size(591, 214);
            this.DataGridView_Lecturers.TabIndex = 8;
            // 
            // Back_Butt
            // 
            this.Back_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Back_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Back_Butt.ForeColor = System.Drawing.Color.White;
            this.Back_Butt.Location = new System.Drawing.Point(22, 531);
            this.Back_Butt.Name = "Back_Butt";
            this.Back_Butt.Size = new System.Drawing.Size(140, 68);
            this.Back_Butt.TabIndex = 9;
            this.Back_Butt.Text = "Back";
            this.Back_Butt.UseVisualStyleBackColor = false;
            this.Back_Butt.Click += new System.EventHandler(this.Back_Butt_Click);
            // 
            // NewAssigning_Butt
            // 
            this.NewAssigning_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.NewAssigning_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.NewAssigning_Butt.ForeColor = System.Drawing.Color.White;
            this.NewAssigning_Butt.Location = new System.Drawing.Point(576, 531);
            this.NewAssigning_Butt.Name = "NewAssigning_Butt";
            this.NewAssigning_Butt.Size = new System.Drawing.Size(140, 68);
            this.NewAssigning_Butt.TabIndex = 10;
            this.NewAssigning_Butt.Text = "New Assigning";
            this.NewAssigning_Butt.UseVisualStyleBackColor = false;
            this.NewAssigning_Butt.Click += new System.EventHandler(this.NewAssigning_Butt_Click);
            // 
            // SendRequest_Butt
            // 
            this.SendRequest_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.SendRequest_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.SendRequest_Butt.ForeColor = System.Drawing.Color.White;
            this.SendRequest_Butt.Location = new System.Drawing.Point(303, 531);
            this.SendRequest_Butt.Name = "SendRequest_Butt";
            this.SendRequest_Butt.Size = new System.Drawing.Size(140, 68);
            this.SendRequest_Butt.TabIndex = 11;
            this.SendRequest_Butt.Text = "Send Request";
            this.SendRequest_Butt.UseVisualStyleBackColor = false;
            this.SendRequest_Butt.Click += new System.EventHandler(this.SendRequest_Butt_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 8);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            // 
            // FindLecturerForAssigning
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.SendRequest_Butt);
            this.Controls.Add(this.NewAssigning_Butt);
            this.Controls.Add(this.Back_Butt);
            this.Controls.Add(this.DataGridView_Lecturers);
            this.Controls.Add(this.Topic_Input);
            this.Controls.Add(this.Find_Butt);
            this.Controls.Add(this.Invalid_Lecture_Info_Lable);
            this.Controls.Add(this.StartTime_Input);
            this.Controls.Add(this.Topic_Lable);
            this.Controls.Add(this.StartTime_Lable);
            this.Controls.Add(this.Ins_LectureInfo_Lable);
            this.Name = "FindLecturerForAssigning";
            this.Text = "FindLecturerForAssigning";
            this.Load += new System.EventHandler(this.FindLecturerForAssigning_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView_Lecturers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Ins_LectureInfo_Lable;
        private System.Windows.Forms.Label StartTime_Lable;
        private System.Windows.Forms.Label Topic_Lable;
        private System.Windows.Forms.DateTimePicker StartTime_Input;
        private System.Windows.Forms.Label Invalid_Lecture_Info_Lable;
        private System.Windows.Forms.Button Find_Butt;
        private System.Windows.Forms.ComboBox Topic_Input;
        private System.Windows.Forms.DataGridView DataGridView_Lecturers;
        private System.Windows.Forms.Button Back_Butt;
        private System.Windows.Forms.Button NewAssigning_Butt;
        private System.Windows.Forms.Button SendRequest_Butt;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}