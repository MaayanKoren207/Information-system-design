﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class AddSession : Form
    {
        Session newSession;
        public AddSession()
        {
            InitializeComponent();

            Random rnd = new Random();
            int random = rnd.Next(1, 10000);
            SessionNumberInput.Text = random.ToString();


            SA_LocationEnumInput.DataSource = Enum.GetValues(typeof(Location));
            SA_LocationEnumInput.SelectedIndex = 0;
            Invalid_App_Lable.Hide();


           // SA_Number.Hide(); // session number lable
           // SessionNumberInput.Hide(); // session number Input
        }


        private void S_AddNew_Click(object sender, EventArgs e)
        {
            if (IsValidInput())
            {
                Invalid_App_Lable.Hide(); //S_MeetingInput

                SA_Number.Show(); // session number lable
                SessionNumberInput.Show(); // session number Input

               Session s = new Session(DateTime.Parse(dateTimePickerSessionA.Text), int.Parse(SA_DurationInput.Text), SA_TopicInput.Text, int.Parse(SessionNumberInput.Text), (Location)Enum.Parse(typeof(Location), SA_LocationEnumInput.Text), 1, true);

               newSession = Program.seekSession(DateTime.Parse(dateTimePickerSessionA.Text));
               SendMailToList(newSession);
            }
            else
            {
                Invalid_App_Lable.Show();
                if (Invalid_App_Lable.Font.Size <= 20)
                    Invalid_App_Lable.Font = new Font(Invalid_App_Lable.Font.FontFamily, Invalid_App_Lable.Font.Size + 1);
                else if (Invalid_App_Lable.ForeColor == Color.Red)
                    Invalid_App_Lable.ForeColor = Color.Gold;
                else
                    Invalid_App_Lable.ForeColor = Color.Red;
            }
            
        }

        private int RandomSessionNum()
        {
            Random rnd = new Random();
            int random = rnd.Next(1,1000);

            foreach (Session s in Program.Sessions)
            {
                if (s.get_SessionNumber() == random)
                {
                    RandomSessionNum();
                }
            }
            return random;
        }

        private void AddSession_Load(object sender, EventArgs e)
        {

        }

        private void SA_DurationInput_TextChanged(object sender, EventArgs e)
        {

        }


        private bool IsValidInput()
        {

            if (!Int32.TryParse(SessionNumberInput.Text, out int Value) || !Int32.TryParse(SA_DurationInput.Text, out Value))
                return false; //Making sure sessionNumber and durration is numbers

            else if (SA_DurationInput.Text == null  || SA_TopicInput.Text ==null)
                return false; // Making sure no input is to stay null
                    
            else
                return true;
        }

        private void SendMailToList( Session newSession)
        {
            if (newSession != null)
            {
                string SessionDT = newSession.get_SessionDate().ToString();
                string SessionTopic = newSession.get_Topic();
                string SessionDuration = newSession.get_Duration().ToString();
                string SessionLoc = newSession.get_SessionLocation().ToString();

                string EmailSub = "Cycle Announcement About Upcoming Session";
                string[] EmailCont = new string[20];


                EmailCont[0] = "Hello, ";
                EmailCont[1] = "We would like to inform you that a new session was scheduled to " + SessionDT + ".";
                EmailCont[2] = "The session will accure at " + SessionLoc + ".";
                EmailCont[3] = "See you there,";
                EmailCont[4] = "Cycle Team";


                SendEmailToList sendMail = new SendEmailToList(EmailSub, EmailCont);
                sendMail.Owner = this;
                sendMail.Show();
                this.Hide();
            }
        }

        private void Back_Click(object sender, EventArgs e)
        {
            SessionOptions ac = new SessionOptions();
            ac.Show();
            this.Close();

        }


    }
}
