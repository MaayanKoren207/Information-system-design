﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class FindLecturerForAssigning : Form
    {
        private Lecture lecture;
        private Lecturer lecturer;

        public FindLecturerForAssigning()
        {
            InitializeComponent();
            Topic_Input.DataSource = Enum.GetValues(typeof(LectureTopic));
            Topic_Input.SelectedIndex = -1;

            Invalid_Lecture_Info_Lable.Hide();
            DataGridView_Lecturers.Hide();
            NewAssigning_Butt.Hide();
            SendRequest_Butt.Hide();
        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            AssigningManage mf = new AssigningManage();
            mf.Show();
            this.Close();
        }

        private void FindLecturerForAssigning_Load(object sender, EventArgs e)
        {

        }

        private void NewAssigning_Butt_Click(object sender, EventArgs e)
        {
            FindLecturerForAssigning f = new FindLecturerForAssigning();
            f.Show();
            this.Hide();
        }

        private void Find_Butt_Click(object sender, EventArgs e)
        {
            if (Topic_Input.SelectedIndex.Equals(-1))
            {
                Topic_Input.SelectedIndex = 0; // NLP is default
            }

            lecture = Program.seekLecture((DateTime.Parse(StartTime_Input.Text)), (LectureTopic)Enum.Parse(typeof(LectureTopic), Topic_Input.Text));

            if (lecture != null)
            {
                DataGridView_Lecturers.Show();
                Find_Butt.Hide();
                NewAssigning_Butt.Show();
                SendRequest_Butt.Show();

                var assignings = lecture.get_AssigningByStatus(AssigningStatus.Optional);

                DataGridView_Lecturers.Name = "Available Lecturers";
                DataGridView_Lecturers.ColumnCount = 5;

                DataGridView_Lecturers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                DataGridView_Lecturers.MultiSelect = false;

                DataGridView_Lecturers.Columns[0].Name = "Lecturer Id";
                DataGridView_Lecturers.Columns[1].Name = "Lecturer first name";
                DataGridView_Lecturers.Columns[2].Name = "Lecturer last name";
                DataGridView_Lecturers.Columns[3].Name = "Lecturer Email";
                DataGridView_Lecturers.Columns[4].Name = "Status";

                foreach (var a in assignings)
                {
                    DataGridView_Lecturers.Rows.Add(
                        a.Lecturer.get_ID(),
                        a.Lecturer.get_FirstName(),
                        a.Lecturer.get_LastName(),
                        a.lecturer.get_Email(),
                        a.get_Status());
                }
            }
            else
            {
                Invalid_Lecture_Info_Lable.Show();
            }
        }

        private void SendRequest_Butt_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = null;
            DataGridViewCell selectedCell = null;
            string L_ID;

            Int32 selectedRowCount = DataGridView_Lecturers.Rows.GetRowCount(DataGridViewElementStates.Selected);

            if (selectedRowCount == 1)
            {
                selectedRow = DataGridView_Lecturers.SelectedRows[0];
                selectedCell = selectedRow.Cells[0];
                L_ID = selectedCell.Value.ToString();

                lecturer = Program.seekLecturer(L_ID);

                sendMail();
            }
        }

        private void sendMail()
        {
            string L_Email = lecturer.get_Email();

            string EmailSub = "Cycle Request for Lecture";

            string[] EmailCont = new string[20];

            EmailCont[0] = "Hello " + lecturer.get_FirstName() + ",";
            EmailCont[1] = "Are you available to Lecture about " + lecture.get_Topic().ToString() + " on the follwing date: " + lecture.get_StartTime().ToString() + "?";
            EmailCont[2] = "Thank you,";
            EmailCont[3] = "Cycle Team";

            SendMail sm = new SendMail(L_Email, EmailSub, EmailCont);
            sm.Show();
            this.Hide();

        }

    }
}