﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class UpdateEmployee : Form
    {
        private Employee E_Exist;

        public UpdateEmployee()
        {
            InitializeComponent();
            EU_StatusEnumInput.DataSource = Enum.GetValues(typeof(Status));
            EU_EmployeeTypeInput.DataSource = Enum.GetValues(typeof(EmployeeType));
            EU_StatusEnumInput.SelectedIndex = -1;
            EU_EmployeeTypeInput.SelectedIndex = -1;
            E_Valid.Hide();
            E_OKText.Hide();

            E_FirstName.Hide();
            E_FnameInput.Hide();
            E_LastName.Hide();
            E_LnameInput.Hide();
            EU_PhoneNum.Hide();
            EU_PhoneNumInput.Hide();
            EU_EmployeeType.Hide();
            EU_EmployeeTypeInput.Hide();
            EU_Email.Hide();
            EU_EmpolyeeInput.Hide();
            EU_StartingDate.Hide();
            dateTimePickerEmployeeU.Hide();
            EU_Status.Hide();
            EU_StatusEnumInput.Hide();

            E_Delete.Hide();
            EU_Update.Hide();

        }

        private void E_IDInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void E_ID_Click(object sender, EventArgs e)
        {

        }

        private void E_ID_Search_Click(object sender, EventArgs e)
        {
            E_Exist = Program.seekEmployee(E_IDInput.Text);
            if (E_Exist != null)
            {
                E_OKText.Hide();

                E_FirstName.Show();
                E_FnameInput.Show();
                E_LastName.Show();
                E_LnameInput.Show();
                EU_PhoneNum.Show();
                EU_PhoneNumInput.Show();
                EU_EmployeeType.Show();
                EU_EmployeeTypeInput.Show();
                EU_Email.Show();
                EU_EmpolyeeInput.Show();
                EU_StartingDate.Show();
                dateTimePickerEmployeeU.Show();
                EU_Status.Show();
                EU_StatusEnumInput.Show();

                E_Delete.Show();
                EU_Update.Show();

                E_FnameInput.Text = E_Exist.get_FirstName();
                E_LnameInput.Text = E_Exist.get_LastName();
                EU_PhoneNumInput.Text = E_Exist.get_PhoneNumber();
                EU_EmployeeTypeInput.Text = E_Exist.get_EmployeeType().ToString();
                EU_EmpolyeeInput.Text = E_Exist.get_Email();
                dateTimePickerEmployeeU.Text = E_Exist.get_StartingDate().ToString();
                EU_StatusEnumInput.Text = E_Exist.get_status().ToString();

            }
            else
            {
                E_OKText.Show();
            }
        }


        private void E_Delete_Click(object sender, EventArgs e)
        {
            EU_StatusEnumInput.SelectedIndex = 1;
            E_Exist.set_status((Status)Enum.Parse(typeof(Status), EU_StatusEnumInput.Text));
            E_Exist.Update_Employee();


            // E_Exist.Delete_Employee();
            EmployeeCRUD ac = new EmployeeCRUD();
            ac.Show();
            this.Close();
        }

        private void E_Back_Click(object sender, EventArgs e)
        {
            EmployeeCRUD ac = new EmployeeCRUD();
            ac.Show();
            this.Close();
        }

        private void EU_Update_Click(object sender, EventArgs e)
        {
            if (IsValidInput())
            {
                E_Valid.Hide();
                E_Exist.set_FirstName(E_FnameInput.Text);
                E_Exist.set_LastName(E_LnameInput.Text);
                E_Exist.set_PhoneNumber(EU_PhoneNumInput.Text);
                E_Exist.set_employeeType((EmployeeType)Enum.Parse(typeof(EmployeeType), EU_EmployeeTypeInput.Text));
                E_Exist.set_Email(EU_EmpolyeeInput.Text);
                E_Exist.set_StartingDate(DateTime.Parse(dateTimePickerEmployeeU.Text.ToString()));
                E_Exist.set_status((Status)Enum.Parse(typeof(Status), EU_StatusEnumInput.Text));
                E_Exist.Update_Employee();
            }
            else
            {
                E_Valid.Show();
                if (E_Valid.Font.Size <= 20)
                    E_Valid.Font = new Font(E_Valid.Font.FontFamily, E_Valid.Font.Size + 1);
                else if (E_Valid.ForeColor == Color.Red)
                    E_Valid.ForeColor = Color.Gold;
                else
                    E_Valid.ForeColor = Color.Red;
            }

        }

        private bool IsValidInput()
        {
            if (!Int32.TryParse(E_IDInput.Text, out int Value) || !Int32.TryParse(EU_PhoneNumInput.Text, out Value))
                return false; //Making sure ID, PhoneNum are all numbers

            else if (E_IDInput.Text == null || E_FnameInput.Text == null || E_LnameInput.Text == null || EU_EmpolyeeInput.Text == null || EU_PhoneNumInput.Text == null || DateTime.Parse(dateTimePickerEmployeeU.Text) == null)
                return false; // Making sure no input is to stay null

            else if (100000000 > int.Parse(E_IDInput.Text) || int.Parse(E_IDInput.Text) > 999999999)
                return false;// Making sure ID is a number in the right length

            else if (Regex.IsMatch(EU_EmpolyeeInput.Text, @"^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$") == false)
                return false;// Making sure the email is in the right format

            else if (Regex.IsMatch(E_FnameInput.Text, @"^[a-zA-Z][a-z]*$") == false || Regex.IsMatch(E_LnameInput.Text, @"^[a-zA-Z][a-z]*$") == false)
                return false;// Making sure full name containing only letters

            else if (E_IDInput.Text.Length != 9 || EU_PhoneNumInput.Text.Length != 10)
                return false;// Making sure ID and PhoneNum are the right length

            else
                return true;
        }

        private void UpdateEmployee_Load(object sender, EventArgs e)
        {

        }

        private void EU_Email_Click(object sender, EventArgs e)
        {

        }

        private void EU_EmpolyeeInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void EU_PhoneNum_Click(object sender, EventArgs e)
        {

        }

        private void EU_StartingDate_Click(object sender, EventArgs e)
        {

        }


        private void E_ID_Click_1(object sender, EventArgs e)
        {

        }
    }


}


