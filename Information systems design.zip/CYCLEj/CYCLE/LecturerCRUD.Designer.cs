﻿namespace CYCLE
{
    partial class LecturerCRUD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.To_Add_Lecturer = new System.Windows.Forms.Button();
            this.To_UpOrDel_Lecturer = new System.Windows.Forms.Button();
            this.Back_Butt = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Lectures = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // To_Add_Lecturer
            // 
            this.To_Add_Lecturer.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.To_Add_Lecturer.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.To_Add_Lecturer.ForeColor = System.Drawing.Color.White;
            this.To_Add_Lecturer.Location = new System.Drawing.Point(419, 321);
            this.To_Add_Lecturer.Name = "To_Add_Lecturer";
            this.To_Add_Lecturer.Size = new System.Drawing.Size(218, 95);
            this.To_Add_Lecturer.TabIndex = 0;
            this.To_Add_Lecturer.Text = "Add Lecturer";
            this.To_Add_Lecturer.UseVisualStyleBackColor = false;
            this.To_Add_Lecturer.Click += new System.EventHandler(this.To_Add_Lecturer_Click);
            // 
            // To_UpOrDel_Lecturer
            // 
            this.To_UpOrDel_Lecturer.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.To_UpOrDel_Lecturer.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.To_UpOrDel_Lecturer.ForeColor = System.Drawing.Color.White;
            this.To_UpOrDel_Lecturer.Location = new System.Drawing.Point(89, 321);
            this.To_UpOrDel_Lecturer.Name = "To_UpOrDel_Lecturer";
            this.To_UpOrDel_Lecturer.Size = new System.Drawing.Size(218, 95);
            this.To_UpOrDel_Lecturer.TabIndex = 1;
            this.To_UpOrDel_Lecturer.Text = "Update Or Delete Lecturer";
            this.To_UpOrDel_Lecturer.UseVisualStyleBackColor = false;
            this.To_UpOrDel_Lecturer.Click += new System.EventHandler(this.To_UpOrDel_Lecturer_Click);
            // 
            // Back_Butt
            // 
            this.Back_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Back_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Back_Butt.ForeColor = System.Drawing.Color.White;
            this.Back_Butt.Location = new System.Drawing.Point(12, 531);
            this.Back_Butt.Name = "Back_Butt";
            this.Back_Butt.Size = new System.Drawing.Size(140, 68);
            this.Back_Butt.TabIndex = 2;
            this.Back_Butt.Text = "Back";
            this.Back_Butt.UseVisualStyleBackColor = false;
            this.Back_Butt.Click += new System.EventHandler(this.Back_Butt_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 23;
            this.pictureBox2.TabStop = false;
            // 
            // Lectures
            // 
            this.Lectures.AutoSize = true;
            this.Lectures.BackColor = System.Drawing.Color.Transparent;
            this.Lectures.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lectures.ForeColor = System.Drawing.Color.Navy;
            this.Lectures.Location = new System.Drawing.Point(262, 147);
            this.Lectures.Name = "Lectures";
            this.Lectures.Size = new System.Drawing.Size(189, 59);
            this.Lectures.TabIndex = 46;
            this.Lectures.Text = "Lectures";
            // 
            // LecturerCRUD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.Lectures);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Back_Butt);
            this.Controls.Add(this.To_UpOrDel_Lecturer);
            this.Controls.Add(this.To_Add_Lecturer);
            this.Name = "LecturerCRUD";
            this.Text = "LecturerCRUD";
            this.Load += new System.EventHandler(this.LecturerCRUD_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button To_Add_Lecturer;
        private System.Windows.Forms.Button To_UpOrDel_Lecturer;
        private System.Windows.Forms.Button Back_Butt;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Lectures;
    }
}