﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class AppHomePage : Form
    {
        //View_App_Info_Butt //Add_Feedback_Butt //LogOut_Butt
        //FullName_Text


        private Apprentice apprentice;

        public AppHomePage()
        {
            InitializeComponent();
        }

        public AppHomePage(Apprentice a)
        {
            InitializeComponent();

            ID_Lable.Hide();
            FirstName_Lable.Hide();
            LastName_Lable.Hide();
            Age_Lable.Hide();
            Address_Lable.Hide();
            Email_Lable.Hide();
            PhoneNumber_Lable.Hide();

            ID_Text.Hide();
            FirstName_Text.Hide();
            LastName_Text.Hide();
            Age_Text.Hide();
            Address_Text.Hide();
            Email_Text.Hide();
            PhoneNumber_Text.Hide();


            this.apprentice = a;

            FullName_Text.Text = apprentice.get_FirstName() + " " + apprentice.get_LastName();


        }

        private void AppHomePage_Load(object sender, EventArgs e)
        {

        }

        private void LogOut_Butt_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            l.Show();
            this.Hide();
        }

        private void Add_Feedback_Butt_Click(object sender, EventArgs e)
        {
            AddFeedback l = new AddFeedback(apprentice);
            l.Show();
            this.Hide();
        }

        private void Address_Lable_Click(object sender, EventArgs e)
        {

        }

        private void View_App_Info_Butt_Click(object sender, EventArgs e)
        {

            ID_Text.Text = apprentice.getID();
            FirstName_Text.Text = apprentice.get_FirstName();
            LastName_Text.Text = apprentice.get_LastName();
            Age_Text.Text = apprentice.get_Age().ToString();
            Address_Text.Text = apprentice.get_ApprenticeAddress();
            Email_Text.Text = apprentice.get_Email();
            PhoneNumber_Text.Text = apprentice.get_PhoneNumber();

            ID_Lable.Show();
            FirstName_Lable.Show();
            LastName_Lable.Show();
            Age_Lable.Show();
            Address_Lable.Show();
            Email_Lable.Show();
            PhoneNumber_Lable.Show();

            ID_Text.Show();
            FirstName_Text.Show();
            LastName_Text.Show();
            Age_Text.Show();
            Address_Text.Show();
            Email_Text.Show();
            PhoneNumber_Text.Show();


        }

        private void FullName_Text_Click(object sender, EventArgs e)
        {

        }

        private void Welcome_Label_Click(object sender, EventArgs e)
        {

        }

        private void What_Lable_Click(object sender, EventArgs e)
        {

        }
    }
}
