﻿namespace CYCLE
{
    partial class UpdateDeleteS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.S_ID = new System.Windows.Forms.Label();
            this.S_IDInput1 = new System.Windows.Forms.TextBox();
            this.S_FullNameInput1 = new System.Windows.Forms.TextBox();
            this.S_FullName = new System.Windows.Forms.Label();
            this.S_Address = new System.Windows.Forms.Label();
            this.S_Contact_Full_Name = new System.Windows.Forms.Label();
            this.S_Contact_Phone_Number = new System.Windows.Forms.Label();
            this.S_Contact_Email = new System.Windows.Forms.Label();
            this.S_Bank_Account_info = new System.Windows.Forms.Label();
            this.S_AddressInput1 = new System.Windows.Forms.TextBox();
            this.S_Contact_Full_NameInput1 = new System.Windows.Forms.TextBox();
            this.S_Contact_Phone_NumberInput1 = new System.Windows.Forms.TextBox();
            this.S_Contact_EmailInput1 = new System.Windows.Forms.TextBox();
            this.S_Bank_Account_infoInput1 = new System.Windows.Forms.TextBox();
            this.S_ID_Search = new System.Windows.Forms.Button();
            this.A_FormatText = new System.Windows.Forms.Label();
            this.S_Valid = new System.Windows.Forms.Label();
            this.S_OKText = new System.Windows.Forms.Label();
            this.S_Update = new System.Windows.Forms.Button();
            this.S_back_update = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // S_ID
            // 
            this.S_ID.AutoSize = true;
            this.S_ID.BackColor = System.Drawing.Color.Transparent;
            this.S_ID.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_ID.Location = new System.Drawing.Point(12, 125);
            this.S_ID.Name = "S_ID";
            this.S_ID.Size = new System.Drawing.Size(105, 26);
            this.S_ID.TabIndex = 2;
            this.S_ID.Text = "ID Supplier";
            // 
            // S_IDInput1
            // 
            this.S_IDInput1.Location = new System.Drawing.Point(130, 126);
            this.S_IDInput1.Multiline = true;
            this.S_IDInput1.Name = "S_IDInput1";
            this.S_IDInput1.Size = new System.Drawing.Size(185, 25);
            this.S_IDInput1.TabIndex = 10;
            // 
            // S_FullNameInput1
            // 
            this.S_FullNameInput1.Location = new System.Drawing.Point(130, 232);
            this.S_FullNameInput1.Multiline = true;
            this.S_FullNameInput1.Name = "S_FullNameInput1";
            this.S_FullNameInput1.Size = new System.Drawing.Size(185, 25);
            this.S_FullNameInput1.TabIndex = 11;
            // 
            // S_FullName
            // 
            this.S_FullName.AutoSize = true;
            this.S_FullName.BackColor = System.Drawing.Color.Transparent;
            this.S_FullName.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_FullName.Location = new System.Drawing.Point(12, 230);
            this.S_FullName.Name = "S_FullName";
            this.S_FullName.Size = new System.Drawing.Size(99, 26);
            this.S_FullName.TabIndex = 12;
            this.S_FullName.Text = "Full Name";
            // 
            // S_Address
            // 
            this.S_Address.AutoSize = true;
            this.S_Address.BackColor = System.Drawing.Color.Transparent;
            this.S_Address.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_Address.Location = new System.Drawing.Point(13, 290);
            this.S_Address.Name = "S_Address";
            this.S_Address.Size = new System.Drawing.Size(79, 26);
            this.S_Address.TabIndex = 13;
            this.S_Address.Text = "Address";
            // 
            // S_Contact_Full_Name
            // 
            this.S_Contact_Full_Name.AutoSize = true;
            this.S_Contact_Full_Name.BackColor = System.Drawing.Color.Transparent;
            this.S_Contact_Full_Name.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_Contact_Full_Name.Location = new System.Drawing.Point(7, 348);
            this.S_Contact_Full_Name.Name = "S_Contact_Full_Name";
            this.S_Contact_Full_Name.Size = new System.Drawing.Size(114, 26);
            this.S_Contact_Full_Name.TabIndex = 14;
            this.S_Contact_Full_Name.Text = "Contact Full";
            // 
            // S_Contact_Phone_Number
            // 
            this.S_Contact_Phone_Number.AutoSize = true;
            this.S_Contact_Phone_Number.BackColor = System.Drawing.Color.Transparent;
            this.S_Contact_Phone_Number.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_Contact_Phone_Number.Location = new System.Drawing.Point(359, 231);
            this.S_Contact_Phone_Number.Name = "S_Contact_Phone_Number";
            this.S_Contact_Phone_Number.Size = new System.Drawing.Size(137, 26);
            this.S_Contact_Phone_Number.TabIndex = 15;
            this.S_Contact_Phone_Number.Text = "Contact Phone";
            // 
            // S_Contact_Email
            // 
            this.S_Contact_Email.AutoSize = true;
            this.S_Contact_Email.BackColor = System.Drawing.Color.Transparent;
            this.S_Contact_Email.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_Contact_Email.Location = new System.Drawing.Point(359, 292);
            this.S_Contact_Email.Name = "S_Contact_Email";
            this.S_Contact_Email.Size = new System.Drawing.Size(130, 26);
            this.S_Contact_Email.TabIndex = 16;
            this.S_Contact_Email.Text = "Contact Email";
            // 
            // S_Bank_Account_info
            // 
            this.S_Bank_Account_info.AutoSize = true;
            this.S_Bank_Account_info.BackColor = System.Drawing.Color.Transparent;
            this.S_Bank_Account_info.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_Bank_Account_info.Location = new System.Drawing.Point(359, 349);
            this.S_Bank_Account_info.Name = "S_Bank_Account_info";
            this.S_Bank_Account_info.Size = new System.Drawing.Size(129, 26);
            this.S_Bank_Account_info.TabIndex = 17;
            this.S_Bank_Account_info.Text = "Bank Account";
            this.S_Bank_Account_info.Click += new System.EventHandler(this.S_Bank_Account_info_Click);
            // 
            // S_AddressInput1
            // 
            this.S_AddressInput1.Location = new System.Drawing.Point(130, 293);
            this.S_AddressInput1.Multiline = true;
            this.S_AddressInput1.Name = "S_AddressInput1";
            this.S_AddressInput1.Size = new System.Drawing.Size(185, 25);
            this.S_AddressInput1.TabIndex = 18;
            // 
            // S_Contact_Full_NameInput1
            // 
            this.S_Contact_Full_NameInput1.Location = new System.Drawing.Point(130, 354);
            this.S_Contact_Full_NameInput1.Multiline = true;
            this.S_Contact_Full_NameInput1.Name = "S_Contact_Full_NameInput1";
            this.S_Contact_Full_NameInput1.Size = new System.Drawing.Size(185, 25);
            this.S_Contact_Full_NameInput1.TabIndex = 19;
            // 
            // S_Contact_Phone_NumberInput1
            // 
            this.S_Contact_Phone_NumberInput1.Location = new System.Drawing.Point(515, 232);
            this.S_Contact_Phone_NumberInput1.Multiline = true;
            this.S_Contact_Phone_NumberInput1.Name = "S_Contact_Phone_NumberInput1";
            this.S_Contact_Phone_NumberInput1.Size = new System.Drawing.Size(185, 25);
            this.S_Contact_Phone_NumberInput1.TabIndex = 20;
            // 
            // S_Contact_EmailInput1
            // 
            this.S_Contact_EmailInput1.Location = new System.Drawing.Point(515, 291);
            this.S_Contact_EmailInput1.Multiline = true;
            this.S_Contact_EmailInput1.Name = "S_Contact_EmailInput1";
            this.S_Contact_EmailInput1.Size = new System.Drawing.Size(185, 25);
            this.S_Contact_EmailInput1.TabIndex = 21;
            // 
            // S_Bank_Account_infoInput1
            // 
            this.S_Bank_Account_infoInput1.Location = new System.Drawing.Point(515, 352);
            this.S_Bank_Account_infoInput1.Multiline = true;
            this.S_Bank_Account_infoInput1.Name = "S_Bank_Account_infoInput1";
            this.S_Bank_Account_infoInput1.Size = new System.Drawing.Size(185, 25);
            this.S_Bank_Account_infoInput1.TabIndex = 22;
            // 
            // S_ID_Search
            // 
            this.S_ID_Search.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.S_ID_Search.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.S_ID_Search.ForeColor = System.Drawing.Color.White;
            this.S_ID_Search.Location = new System.Drawing.Point(344, 126);
            this.S_ID_Search.Name = "S_ID_Search";
            this.S_ID_Search.Size = new System.Drawing.Size(106, 28);
            this.S_ID_Search.TabIndex = 23;
            this.S_ID_Search.Text = "Search ";
            this.S_ID_Search.UseVisualStyleBackColor = false;
            this.S_ID_Search.Click += new System.EventHandler(this.S_ID_Search_Click);
            // 
            // A_FormatText
            // 
            this.A_FormatText.AutoSize = true;
            this.A_FormatText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.A_FormatText.ForeColor = System.Drawing.Color.Red;
            this.A_FormatText.Location = new System.Drawing.Point(73, 65);
            this.A_FormatText.Name = "A_FormatText";
            this.A_FormatText.Size = new System.Drawing.Size(0, 17);
            this.A_FormatText.TabIndex = 24;
            // 
            // S_Valid
            // 
            this.S_Valid.AutoSize = true;
            this.S_Valid.BackColor = System.Drawing.Color.Transparent;
            this.S_Valid.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_Valid.ForeColor = System.Drawing.Color.Navy;
            this.S_Valid.Location = new System.Drawing.Point(92, 159);
            this.S_Valid.Name = "S_Valid";
            this.S_Valid.Size = new System.Drawing.Size(221, 26);
            this.S_Valid.TabIndex = 40;
            this.S_Valid.Text = "Please Insert valid input!";
            // 
            // S_OKText
            // 
            this.S_OKText.AutoSize = true;
            this.S_OKText.BackColor = System.Drawing.Color.Transparent;
            this.S_OKText.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.S_OKText.ForeColor = System.Drawing.Color.Navy;
            this.S_OKText.Location = new System.Drawing.Point(12, 52);
            this.S_OKText.Name = "S_OKText";
            this.S_OKText.Size = new System.Drawing.Size(259, 33);
            this.S_OKText.TabIndex = 41;
            this.S_OKText.Text = "Please Input A Valid ID";
            // 
            // S_Update
            // 
            this.S_Update.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.S_Update.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_Update.ForeColor = System.Drawing.Color.White;
            this.S_Update.Location = new System.Drawing.Point(582, 531);
            this.S_Update.Name = "S_Update";
            this.S_Update.Size = new System.Drawing.Size(140, 68);
            this.S_Update.TabIndex = 43;
            this.S_Update.Text = "Update Supplier";
            this.S_Update.UseVisualStyleBackColor = false;
            this.S_Update.Click += new System.EventHandler(this.S_Update_Click);
            // 
            // S_back_update
            // 
            this.S_back_update.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.S_back_update.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_back_update.ForeColor = System.Drawing.Color.White;
            this.S_back_update.Location = new System.Drawing.Point(17, 531);
            this.S_back_update.Name = "S_back_update";
            this.S_back_update.Size = new System.Drawing.Size(140, 68);
            this.S_back_update.TabIndex = 44;
            this.S_back_update.Text = "Back";
            this.S_back_update.UseVisualStyleBackColor = false;
            this.S_back_update.Click += new System.EventHandler(this.S_back_update_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 45;
            this.pictureBox2.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.label11.Location = new System.Drawing.Point(12, 374);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 26);
            this.label11.TabIndex = 46;
            this.label11.Text = " Name";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.label22.Location = new System.Drawing.Point(359, 254);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(82, 26);
            this.label22.TabIndex = 47;
            this.label22.Text = "Number";
            // 
            // UpdateDeleteS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.S_back_update);
            this.Controls.Add(this.S_Update);
            this.Controls.Add(this.S_OKText);
            this.Controls.Add(this.S_Valid);
            this.Controls.Add(this.A_FormatText);
            this.Controls.Add(this.S_ID_Search);
            this.Controls.Add(this.S_Bank_Account_infoInput1);
            this.Controls.Add(this.S_Contact_EmailInput1);
            this.Controls.Add(this.S_Contact_Phone_NumberInput1);
            this.Controls.Add(this.S_Contact_Full_NameInput1);
            this.Controls.Add(this.S_AddressInput1);
            this.Controls.Add(this.S_Bank_Account_info);
            this.Controls.Add(this.S_Contact_Email);
            this.Controls.Add(this.S_Contact_Phone_Number);
            this.Controls.Add(this.S_Contact_Full_Name);
            this.Controls.Add(this.S_Address);
            this.Controls.Add(this.S_FullName);
            this.Controls.Add(this.S_FullNameInput1);
            this.Controls.Add(this.S_IDInput1);
            this.Controls.Add(this.S_ID);
            this.Name = "UpdateDeleteS";
            this.Text = "UpdateSupplier";
            this.Load += new System.EventHandler(this.UpdateSupplier_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label S_ID;
        private System.Windows.Forms.TextBox S_IDInput1;
        private System.Windows.Forms.TextBox S_FullNameInput1;
        private System.Windows.Forms.Label S_FullName;
        private System.Windows.Forms.Label S_Address;
        private System.Windows.Forms.Label S_Contact_Full_Name;
        private System.Windows.Forms.Label S_Contact_Phone_Number;
        private System.Windows.Forms.Label S_Contact_Email;
        private System.Windows.Forms.Label S_Bank_Account_info;
        private System.Windows.Forms.TextBox S_AddressInput1;
        private System.Windows.Forms.TextBox S_Contact_Full_NameInput1;
        private System.Windows.Forms.TextBox S_Contact_Phone_NumberInput1;
        private System.Windows.Forms.TextBox S_Contact_EmailInput1;
        private System.Windows.Forms.TextBox S_Bank_Account_infoInput1;
        private System.Windows.Forms.Button S_ID_Search;
        private System.Windows.Forms.Label A_FormatText;
        private System.Windows.Forms.Label S_Valid;
        private System.Windows.Forms.Label S_OKText;
        private System.Windows.Forms.Button S_Update;
        private System.Windows.Forms.Button S_back_update;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label22;
    }
}