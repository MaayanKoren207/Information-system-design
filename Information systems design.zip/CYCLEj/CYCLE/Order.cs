﻿
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CYCLE
{

    public class Order
    {

        private string O_ID;
        public DateTime orderDate;
        public DateTime ArrivalDate;
        public bool orderStatus;
        public Supplier supplier;
        public decimal Total { get; set; }

        public Order(Supplier s, string O_ID, DateTime orderDate, DateTime ArrivalDate, bool orderStatus, bool is_new)
        {
            this.Supplier = s;
            this.O_ID = O_ID;
            this.orderDate = orderDate;
            this.ArrivalDate = ArrivalDate;
            this.orderStatus = orderStatus;
            
            if (is_new)
            {
                this.create_Order(this);
                s.AddOrders(this);
                Program.Orders.Add(this);
            }
        }


        public string getID()
        {
            return this.O_ID;
        }


        public DateTime get_orderDate()
        {
            return this.orderDate;
        }

        public DateTime get_ArrivalDate()
        {
            return this.ArrivalDate;
        }

        public bool get_orderStatus()
        {
            return this.orderStatus;
        }

        public void set_orderID(string st)
        {
            this.O_ID = st;

        }

        public void set_orderDate(DateTime d)
        {
            this.orderDate = d;
        }

        public void set_ArrivalDate(DateTime d)
        {
            this.ArrivalDate = d;
        }

        public void set_orderStatus(bool b)
        {
            this.orderStatus = b;
        }

        public Supplier Supplier
        {
            get
            {
                return supplier;
            }
            set
            {
                if (this.supplier == null || !this.supplier.Equals(value))
                {
                    if (this.supplier != null) // remove the order from the exist suppliers's list
                    {
                        Supplier oldSupplier = this.supplier;
                        this.supplier = null;
                        oldSupplier.RemoveOrders(this);
                    }
                    if (value != null)
                    {
                        this.supplier = value;
                        this.supplier.AddOrders(this);
                    }
                }
            }
        }

        public void create_Order(Order NewOrder)
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_add_Order @O_ID, @orderDate, @ArrivalDate, @orderStatus, @S_ID ";
            c.Parameters.AddWithValue("@O_ID", this.O_ID);
            c.Parameters.AddWithValue("@orderDate", this.orderDate);
            c.Parameters.AddWithValue("@ArrivalDate", this.ArrivalDate);
            c.Parameters.AddWithValue("@orderstatus", Convert.ToInt32(this.orderStatus));
            c.Parameters.AddWithValue("@S_ID", this.supplier.get_ID());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Update_Order()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_Update_Order @O_ID, @orderDate, @ArrivalDate, @orderStatus, @S_ID ";
            c.Parameters.AddWithValue("@O_ID", this.O_ID);
            c.Parameters.AddWithValue("@orderDate", this.orderDate);
            c.Parameters.AddWithValue("@ArrivalDate", this.ArrivalDate);
            c.Parameters.AddWithValue("@orderstatus", Convert.ToInt32(this.orderStatus));
            c.Parameters.AddWithValue("@S_ID", this.supplier.get_ID());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void DeleteOrder()
        {
            Program.Orders.Remove(this);
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_delete_Order @O_ID";
            c.Parameters.AddWithValue("O_ID", this.O_ID);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }



    }

}
