﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CYCLE
{
    public class Lecturer
    {
        private string L_ID;
        private string FirstName;
        private string LastName;
        private string Email;
        private string PhoneNumber;
        private Status Status;
        public System.Collections.Generic.List<Assigning> assignings;


        public Lecturer(string L_ID, string FirstName, string LastName, string Email, string PhoneNumber, Status Status, bool is_new)
        {
            this.L_ID = L_ID;
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Email = Email;
            this.PhoneNumber = PhoneNumber;
            this.Status = Status;

            if (is_new)
            {
                this.create_Lecturer();
                Program.Lecturers.Add(this);
            }

        }

        public string get_ID()
        {
            return this.L_ID;
        }

        public string get_FirstName()
        {
            return this.FirstName;
        }

        public void set_FirstName(string st)
        {
            this.FirstName = st;
        }

        public string get_LastName()
        {
            return this.LastName;
        }

        public void set_LastName(string st)
        {
            this.LastName = st;
        }

        public string get_Email()
        {
            return this.Email;
        }

        public void set_Email(string st)
        {
            this.Email = st;
        }

        public string get_PhoneNumber()
        {
            return this.PhoneNumber;
        }

        public void set_PhoneNumber(string st)
        {
            this.PhoneNumber = st;
        }

        public Status get_Status()
        {
            return this.Status;
        }

        public void set_Status(Status s)
        {
            this.Status = s;
        }


        public System.Collections.Generic.List<Assigning> Assignings // get and set for the whole list
        {
            get
            {
                if (assignings == null)
                    assignings = new System.Collections.Generic.List<Assigning>();
                return assignings;
            }
            set
            {
                RemoveAllAssignings();
                if (value != null)
                {
                    foreach (Assigning oAssigning in value)
                        AddAssignings(oAssigning);
                }
            }
        }

        public List<Assigning> get_AssigningByStatus(AssigningStatus status)
        {
            List<Assigning> list = new List<Assigning>();

            foreach (Assigning a in Assignings)
            {
                if (a.get_Status() == status)
                {
                    list.Add(a);
                }
            }
            return list;
        }


        public void AddAssignings(Assigning newAssigning)
        {
            if (newAssigning == null)
                return;
            if (this.assignings == null)
                this.assignings = new System.Collections.Generic.List<Assigning>();
            if (!this.assignings.Contains(newAssigning))
            {
                this.assignings.Add(newAssigning);
                newAssigning.Lecturer = this;
            }
        }

        public void RemoveAssignings(Assigning oldAssigning)
        {
            if (oldAssigning == null)
                return;
            if (this.assignings != null)
                if (this.assignings.Contains(oldAssigning))
                {
                    this.assignings.Remove(oldAssigning);
                    oldAssigning.Lecturer = null;
                }
        }

        public void RemoveAllAssignings()
        {
            if (assignings != null)
            {
                foreach (Assigning a in assignings)
                    a.Lecturer = null;
                assignings.Clear();
            }
        }


        /// <summary>
        /// //////////////////////////////////////////////////////////////
        /// </summary>
        public void create_Lecturer()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_add_Lecturer @L_ID, @FirstName, @LastName, @Email, @PhoneNumber, @LecturerStatus";
            c.Parameters.AddWithValue("@L_ID", this.L_ID);
            c.Parameters.AddWithValue("@FirstName", this.FirstName);
            c.Parameters.AddWithValue("@LastName", this.LastName);
            c.Parameters.AddWithValue("@Email", this.Email);
            c.Parameters.AddWithValue("@PhoneNumber", this.PhoneNumber);
            c.Parameters.AddWithValue("@LecturerStatus", this.Status.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Update_Lecturer()
        {
            SqlCommand c = new SqlCommand(); 
            c.CommandText = "EXECUTE dbo.SP_Update_Lecturer @L_ID, @FirstName, @LastName, @Email, @PhoneNumber, @LecturerStatus";
            c.Parameters.AddWithValue("@L_ID", this.L_ID);
            c.Parameters.AddWithValue("@FirstName", this.FirstName);
            c.Parameters.AddWithValue("@LastName", this.LastName);
            c.Parameters.AddWithValue("@Email", this.Email);
            c.Parameters.AddWithValue("@PhoneNumber", this.PhoneNumber);
            c.Parameters.AddWithValue("@LecturerStatus", this.Status.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Delete_Lecturer()
        {
            Program.Lecturers.Remove(this);
            this.RemoveAllAssignings();
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_delete_Lecturer @L_ID";
            c.Parameters.AddWithValue("L_ID", this.L_ID);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

    }
}
