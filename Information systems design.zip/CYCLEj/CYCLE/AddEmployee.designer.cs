﻿namespace CYCLE
{
    partial class AddEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.E_FormatText = new System.Windows.Forms.Label();
            this.E_ID = new System.Windows.Forms.Label();
            this.E_IDInput = new System.Windows.Forms.TextBox();
            this.E_FirstName = new System.Windows.Forms.Label();
            this.E_FnameInput = new System.Windows.Forms.TextBox();
            this.E_LastName = new System.Windows.Forms.Label();
            this.E_LnameInput = new System.Windows.Forms.TextBox();
            this.E_EmployeeType = new System.Windows.Forms.Label();
            this.E_Email = new System.Windows.Forms.Label();
            this.E_EmpolyeeInput = new System.Windows.Forms.TextBox();
            this.E_PhoneNum = new System.Windows.Forms.Label();
            this.E_PhoneNumInput = new System.Windows.Forms.TextBox();
            this.E_StartingDate = new System.Windows.Forms.Label();
            this.E_Status = new System.Windows.Forms.Label();
            this.E_StatusEnumInput = new System.Windows.Forms.ComboBox();
            this.E_AddNew = new System.Windows.Forms.Button();
            this.E_EmployeeTypeInput = new System.Windows.Forms.ComboBox();
            this.dateTimePickerEmployee = new System.Windows.Forms.DateTimePicker();
            this.E_back1 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.EA_OKText = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // E_FormatText
            // 
            this.E_FormatText.AutoSize = true;
            this.E_FormatText.BackColor = System.Drawing.Color.Transparent;
            this.E_FormatText.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_FormatText.ForeColor = System.Drawing.Color.Navy;
            this.E_FormatText.Location = new System.Drawing.Point(183, 407);
            this.E_FormatText.Name = "E_FormatText";
            this.E_FormatText.Size = new System.Drawing.Size(412, 26);
            this.E_FormatText.TabIndex = 18;
            this.E_FormatText.Text = "Please Insert Input Only In The Correct Format!";
            // 
            // E_ID
            // 
            this.E_ID.AutoSize = true;
            this.E_ID.BackColor = System.Drawing.Color.Transparent;
            this.E_ID.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_ID.Location = new System.Drawing.Point(11, 170);
            this.E_ID.Name = "E_ID";
            this.E_ID.Size = new System.Drawing.Size(119, 26);
            this.E_ID.TabIndex = 19;
            this.E_ID.Text = "Employee ID";
            // 
            // E_IDInput
            // 
            this.E_IDInput.Location = new System.Drawing.Point(158, 173);
            this.E_IDInput.Multiline = true;
            this.E_IDInput.Name = "E_IDInput";
            this.E_IDInput.Size = new System.Drawing.Size(185, 25);
            this.E_IDInput.TabIndex = 20;
            // 
            // E_FirstName
            // 
            this.E_FirstName.AutoSize = true;
            this.E_FirstName.BackColor = System.Drawing.Color.Transparent;
            this.E_FirstName.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_FirstName.Location = new System.Drawing.Point(12, 226);
            this.E_FirstName.Name = "E_FirstName";
            this.E_FirstName.Size = new System.Drawing.Size(105, 26);
            this.E_FirstName.TabIndex = 21;
            this.E_FirstName.Text = "First Name";
            // 
            // E_FnameInput
            // 
            this.E_FnameInput.Location = new System.Drawing.Point(158, 232);
            this.E_FnameInput.Multiline = true;
            this.E_FnameInput.Name = "E_FnameInput";
            this.E_FnameInput.Size = new System.Drawing.Size(185, 25);
            this.E_FnameInput.TabIndex = 22;
            // 
            // E_LastName
            // 
            this.E_LastName.AutoSize = true;
            this.E_LastName.BackColor = System.Drawing.Color.Transparent;
            this.E_LastName.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_LastName.Location = new System.Drawing.Point(12, 289);
            this.E_LastName.Name = "E_LastName";
            this.E_LastName.Size = new System.Drawing.Size(102, 26);
            this.E_LastName.TabIndex = 23;
            this.E_LastName.Text = "Last Name";
            // 
            // E_LnameInput
            // 
            this.E_LnameInput.Location = new System.Drawing.Point(158, 289);
            this.E_LnameInput.Multiline = true;
            this.E_LnameInput.Name = "E_LnameInput";
            this.E_LnameInput.Size = new System.Drawing.Size(185, 25);
            this.E_LnameInput.TabIndex = 24;
            this.E_LnameInput.TextChanged += new System.EventHandler(this.E_LnameInput_TextChanged);
            // 
            // E_EmployeeType
            // 
            this.E_EmployeeType.AutoSize = true;
            this.E_EmployeeType.BackColor = System.Drawing.Color.Transparent;
            this.E_EmployeeType.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_EmployeeType.Location = new System.Drawing.Point(372, 173);
            this.E_EmployeeType.Name = "E_EmployeeType";
            this.E_EmployeeType.Size = new System.Drawing.Size(141, 26);
            this.E_EmployeeType.TabIndex = 25;
            this.E_EmployeeType.Text = "Empolyee Type";
            // 
            // E_Email
            // 
            this.E_Email.AutoSize = true;
            this.E_Email.BackColor = System.Drawing.Color.Transparent;
            this.E_Email.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_Email.Location = new System.Drawing.Point(372, 226);
            this.E_Email.Name = "E_Email";
            this.E_Email.Size = new System.Drawing.Size(59, 26);
            this.E_Email.TabIndex = 26;
            this.E_Email.Text = "Email";
            // 
            // E_EmpolyeeInput
            // 
            this.E_EmpolyeeInput.Location = new System.Drawing.Point(524, 227);
            this.E_EmpolyeeInput.Multiline = true;
            this.E_EmpolyeeInput.Name = "E_EmpolyeeInput";
            this.E_EmpolyeeInput.Size = new System.Drawing.Size(185, 25);
            this.E_EmpolyeeInput.TabIndex = 27;
            // 
            // E_PhoneNum
            // 
            this.E_PhoneNum.AutoSize = true;
            this.E_PhoneNum.BackColor = System.Drawing.Color.Transparent;
            this.E_PhoneNum.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_PhoneNum.Location = new System.Drawing.Point(11, 347);
            this.E_PhoneNum.Name = "E_PhoneNum";
            this.E_PhoneNum.Size = new System.Drawing.Size(141, 26);
            this.E_PhoneNum.TabIndex = 29;
            this.E_PhoneNum.Text = "Phone Number";
            // 
            // E_PhoneNumInput
            // 
            this.E_PhoneNumInput.Location = new System.Drawing.Point(158, 347);
            this.E_PhoneNumInput.Multiline = true;
            this.E_PhoneNumInput.Name = "E_PhoneNumInput";
            this.E_PhoneNumInput.Size = new System.Drawing.Size(185, 25);
            this.E_PhoneNumInput.TabIndex = 30;
            this.E_PhoneNumInput.TextChanged += new System.EventHandler(this.E_PhoneNumInput_TextChanged);
            // 
            // E_StartingDate
            // 
            this.E_StartingDate.AutoSize = true;
            this.E_StartingDate.BackColor = System.Drawing.Color.Transparent;
            this.E_StartingDate.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_StartingDate.Location = new System.Drawing.Point(372, 283);
            this.E_StartingDate.Name = "E_StartingDate";
            this.E_StartingDate.Size = new System.Drawing.Size(124, 26);
            this.E_StartingDate.TabIndex = 31;
            this.E_StartingDate.Text = "Starting Date";
            // 
            // E_Status
            // 
            this.E_Status.AutoSize = true;
            this.E_Status.BackColor = System.Drawing.Color.Transparent;
            this.E_Status.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_Status.Location = new System.Drawing.Point(377, 344);
            this.E_Status.Name = "E_Status";
            this.E_Status.Size = new System.Drawing.Size(65, 26);
            this.E_Status.TabIndex = 33;
            this.E_Status.Text = "Status";
            // 
            // E_StatusEnumInput
            // 
            this.E_StatusEnumInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.E_StatusEnumInput.Font = new System.Drawing.Font("Calibri", 12F);
            this.E_StatusEnumInput.FormattingEnabled = true;
            this.E_StatusEnumInput.Location = new System.Drawing.Point(524, 344);
            this.E_StatusEnumInput.Name = "E_StatusEnumInput";
            this.E_StatusEnumInput.Size = new System.Drawing.Size(185, 27);
            this.E_StatusEnumInput.TabIndex = 34;
            // 
            // E_AddNew
            // 
            this.E_AddNew.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.E_AddNew.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_AddNew.ForeColor = System.Drawing.Color.White;
            this.E_AddNew.Location = new System.Drawing.Point(582, 540);
            this.E_AddNew.Name = "E_AddNew";
            this.E_AddNew.Size = new System.Drawing.Size(140, 68);
            this.E_AddNew.TabIndex = 35;
            this.E_AddNew.Text = "Add Employee";
            this.E_AddNew.UseVisualStyleBackColor = false;
            this.E_AddNew.Click += new System.EventHandler(this.E_AddNew_Click);
            // 
            // E_EmployeeTypeInput
            // 
            this.E_EmployeeTypeInput.BackColor = System.Drawing.Color.White;
            this.E_EmployeeTypeInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.E_EmployeeTypeInput.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.E_EmployeeTypeInput.Font = new System.Drawing.Font("Calibri", 12F);
            this.E_EmployeeTypeInput.FormattingEnabled = true;
            this.E_EmployeeTypeInput.Location = new System.Drawing.Point(524, 171);
            this.E_EmployeeTypeInput.Name = "E_EmployeeTypeInput";
            this.E_EmployeeTypeInput.Size = new System.Drawing.Size(185, 27);
            this.E_EmployeeTypeInput.TabIndex = 37;
            // 
            // dateTimePickerEmployee
            // 
            this.dateTimePickerEmployee.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerEmployee.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerEmployee.Location = new System.Drawing.Point(524, 282);
            this.dateTimePickerEmployee.Name = "dateTimePickerEmployee";
            this.dateTimePickerEmployee.Size = new System.Drawing.Size(185, 27);
            this.dateTimePickerEmployee.TabIndex = 38;
            // 
            // E_back1
            // 
            this.E_back1.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.E_back1.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.E_back1.ForeColor = System.Drawing.Color.White;
            this.E_back1.Location = new System.Drawing.Point(12, 540);
            this.E_back1.Name = "E_back1";
            this.E_back1.Size = new System.Drawing.Size(140, 68);
            this.E_back1.TabIndex = 39;
            this.E_back1.Text = "Back";
            this.E_back1.UseVisualStyleBackColor = false;
            this.E_back1.Click += new System.EventHandler(this.E_back1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 40;
            this.pictureBox2.TabStop = false;
            // 
            // EA_OKText
            // 
            this.EA_OKText.AutoSize = true;
            this.EA_OKText.BackColor = System.Drawing.Color.Transparent;
            this.EA_OKText.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.EA_OKText.ForeColor = System.Drawing.Color.Navy;
            this.EA_OKText.Location = new System.Drawing.Point(10, 98);
            this.EA_OKText.Name = "EA_OKText";
            this.EA_OKText.Size = new System.Drawing.Size(372, 33);
            this.EA_OKText.TabIndex = 42;
            this.EA_OKText.Text = "Please Input A Valid Employee ID";
            // 
            // AddEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.EA_OKText);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.E_back1);
            this.Controls.Add(this.dateTimePickerEmployee);
            this.Controls.Add(this.E_EmployeeTypeInput);
            this.Controls.Add(this.E_AddNew);
            this.Controls.Add(this.E_StatusEnumInput);
            this.Controls.Add(this.E_Status);
            this.Controls.Add(this.E_StartingDate);
            this.Controls.Add(this.E_PhoneNumInput);
            this.Controls.Add(this.E_PhoneNum);
            this.Controls.Add(this.E_EmpolyeeInput);
            this.Controls.Add(this.E_Email);
            this.Controls.Add(this.E_EmployeeType);
            this.Controls.Add(this.E_LnameInput);
            this.Controls.Add(this.E_LastName);
            this.Controls.Add(this.E_FnameInput);
            this.Controls.Add(this.E_FirstName);
            this.Controls.Add(this.E_IDInput);
            this.Controls.Add(this.E_ID);
            this.Controls.Add(this.E_FormatText);
            this.Name = "AddEmployee";
            this.Text = "AddEmployee";
            this.Load += new System.EventHandler(this.AddEmployee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label E_FormatText;
        private System.Windows.Forms.Label E_ID;
        private System.Windows.Forms.TextBox E_IDInput;
        private System.Windows.Forms.Label E_FirstName;
        private System.Windows.Forms.TextBox E_FnameInput;
        private System.Windows.Forms.Label E_LastName;
        private System.Windows.Forms.TextBox E_LnameInput;
        private System.Windows.Forms.Label E_EmployeeType;
        private System.Windows.Forms.Label E_Email;
        private System.Windows.Forms.TextBox E_EmpolyeeInput;
        private System.Windows.Forms.Label E_PhoneNum;
        private System.Windows.Forms.TextBox E_PhoneNumInput;
        private System.Windows.Forms.Label E_StartingDate;
        private System.Windows.Forms.Label E_Status;
        private System.Windows.Forms.ComboBox E_StatusEnumInput;
        private System.Windows.Forms.Button E_AddNew;
        private System.Windows.Forms.ComboBox E_EmployeeTypeInput;
        private System.Windows.Forms.DateTimePicker dateTimePickerEmployee;
        private System.Windows.Forms.Button E_back1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label EA_OKText;
    }
}