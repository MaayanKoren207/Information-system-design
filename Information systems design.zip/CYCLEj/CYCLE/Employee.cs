﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CYCLE
{
    public class Employee
    {

        private string E_ID;
        private string FirstName;
        private string LastName;
        private string PhoneNumber;
        private EmployeeType EmployeeType;
        private string Email;
        private DateTime StartingDate;
        private Status status;


        public Employee(string E_ID, string firstName, string lastName, string PhoneNumber, EmployeeType employeeType, string Email, DateTime StartingDate, Status status, bool is_new)
        {
            this.E_ID = E_ID;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.PhoneNumber = PhoneNumber;
            this.EmployeeType = employeeType;
            this.Email = Email;
            this.StartingDate = StartingDate;
            this.status = status;
            if (is_new)
            {
                this.create_Employee();
                Program.Employees.Add(this);

            }
        }

        public string getID()
        {
            return this.E_ID;
        }


        public string get_FirstName()
        {
            return this.FirstName;
        }

        public string get_LastName()
        {
            return this.LastName;
        }

        public EmployeeType get_EmployeeType()
        {
            return this.EmployeeType;
        }


        public string get_Email()
        {
            return this.Email;
        }

        public string get_PhoneNumber()
        {
            return this.PhoneNumber;
        }

        public DateTime get_StartingDate()
        {
            return this.StartingDate;
        }



        public Status get_status()
        {
            return this.status;
        }


        public void set_employeeType(EmployeeType T)
        {
            this.EmployeeType = T;
        }


        public void set_status(Status s)
        {
            this.status = s;
        }

        public void set_FirstName(string st)
        {
            this.FirstName = st;
        }

        public void set_LastName(string st)
        {
            this.LastName = st;
        }

        public void set_Email(string st)
        {
            this.Email = st;
        }

        public void set_PhoneNumber(string st)
        {
            this.PhoneNumber = st;
        }

        public void set_StartingDate(DateTime st)
        {
            this.StartingDate = st;
        }



        public void create_Employee()
        {

            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_add_Employee @E_ID, @FirstName, @LastName, @PhoneNumber, @EmployeeType, @Email, @StartingDate, @EmployeeStatus";
            c.Parameters.AddWithValue("@E_ID", this.E_ID);
            c.Parameters.AddWithValue("@FirstName", this.FirstName);
            c.Parameters.AddWithValue("@LastName", this.LastName);
            c.Parameters.AddWithValue("@PhoneNumber", this.PhoneNumber);
            c.Parameters.AddWithValue("@EmployeeType", this.EmployeeType.ToString());
            c.Parameters.AddWithValue("@Email", this.Email);
            c.Parameters.AddWithValue("@StartingDate", this.StartingDate);
            c.Parameters.AddWithValue("@EmployeeStatus", this.status.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Update_Employee()
        {
            SqlCommand c = new SqlCommand();// עם שינויים שמירה אחרונה
            c.CommandText = "EXECUTE dbo.SP_Update_Employee @E_ID, @FirstName, @LastName, @PhoneNumber, @EmployeeType, @Email, @StartingDate, @EmployeeStatus";
            c.Parameters.AddWithValue("@E_ID", this.E_ID);
            c.Parameters.AddWithValue("@FirstName", this.FirstName);
            c.Parameters.AddWithValue("@LastName", this.LastName);
            c.Parameters.AddWithValue("@PhoneNumber", this.PhoneNumber);
            c.Parameters.AddWithValue("@EmployeeType", this.EmployeeType.ToString());
            c.Parameters.AddWithValue("@Email", this.Email);
            c.Parameters.AddWithValue("@StartingDate", this.StartingDate);
            c.Parameters.AddWithValue("@EmployeeStatus", this.status.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Delete_Employee()
        {
         //   Program.Employees.Remove(this);
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_delete_Employees @E_ID";
            c.Parameters.AddWithValue("E_ID", this.E_ID);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

















    }
}
