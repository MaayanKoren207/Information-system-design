﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CYCLE
{
    public class Assigning
    {
        public Lecture lecture;
        public Lecturer lecturer;
        private AssigningStatus AssigningStatus;


        public Assigning(Lecture l, Lecturer lr, AssigningStatus AssigningStatus, bool is_new)
        {
            this.Lecture = l;
            this.Lecturer = lr;
            this.AssigningStatus = AssigningStatus;

            if (is_new)
            {
                this.create_Assigning();
                l.AddAssignings(this);
                lr.AddAssignings(this);
                Program.Assignings.Add(this);
            }

        }

        public AssigningStatus get_Status()
        {
            return this.AssigningStatus;
        }

        public void set_Status(AssigningStatus s)
        {
            this.AssigningStatus = s;
        }



        public Lecture Lecture
        {
            get
            {
                return lecture;
            }
            set
            {
                if (this.lecture == null || !this.lecture.Equals(value))
                {
                    if (this.lecture != null) // remove the Assignement from the exist lecturer's list
                    {
                        Lecture oldLecture = this.lecture;
                        this.lecture = null;
                        oldLecture.RemoveAssignings(this);
                    }
                    if (value != null)
                    {
                        this.lecture = value;
                        this.lecture.AddAssignings(this);
                    }
                }
            }
        }

        public Lecturer Lecturer
        {
            get
            {
                return lecturer;
            }
            
            set
            {
                if (this.lecturer == null || !this.lecturer.Equals(value))
                {
                    if (this.lecturer != null) // remove the Assignement from the exist lecturer's list
                    {
                        Lecturer oldLecturer = this.lecturer;
                        this.lecturer = null;
                        oldLecturer.RemoveAssignings(this);
                    }
                    if (value != null)
                    {
                        this.lecturer = value;
                        this.lecturer.AddAssignings(this);
                    }
                }
            }
        }

        public void create_Assigning()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_add_Assigning @StartTime, @Topic, @L_ID, @AssigningStatus";
            c.Parameters.AddWithValue("@StartTime", this.lecture.get_StartTime());
            c.Parameters.AddWithValue("@Topic", this.lecture.get_Topic().ToString());
            c.Parameters.AddWithValue("@L_ID", this.lecturer.get_ID());
            c.Parameters.AddWithValue("@AssigningStatus", this.AssigningStatus.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        
        public void Update_Assigning()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_Update_Assigning @StartTime, @Topic, @L_ID, @AssigningStatus";
            c.Parameters.AddWithValue("@StartTime", this.lecture.get_StartTime());
            c.Parameters.AddWithValue("@Topic", this.lecture.get_Topic().ToString());
            c.Parameters.AddWithValue("@L_ID", this.lecturer.get_ID());
            c.Parameters.AddWithValue("@AssigningStatus", this.AssigningStatus.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Delete_Assigning()
        {
            Program.Assignings.Remove(this);
            this.lecture?.RemoveAssignings(this);
            this.lecturer?.RemoveAssignings(this);
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_delete_Assigning @StartTime, @Topic, @L_ID";
            c.Parameters.AddWithValue("@StartTime", this.lecture.get_StartTime());
            c.Parameters.AddWithValue("@Topic", this.lecture.get_Topic().ToString());
            c.Parameters.AddWithValue("@L_ID", this.lecturer.get_ID());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

    }
}     

