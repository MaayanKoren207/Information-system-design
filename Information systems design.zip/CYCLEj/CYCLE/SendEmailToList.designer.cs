﻿namespace CYCLE
{
    partial class SendEmailToList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Send = new System.Windows.Forms.Button();
            this.Send_To = new System.Windows.Forms.TextBox();
            this.Send_To_Text = new System.Windows.Forms.Label();
            this.Subject = new System.Windows.Forms.Label();
            this.content = new System.Windows.Forms.Label();
            this.Subject_Input = new System.Windows.Forms.TextBox();
            this.ContentInput = new System.Windows.Forms.TextBox();
            this.Back_Butt = new System.Windows.Forms.Button();
            this.mail_Text = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Send
            // 
            this.Send.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Send.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Send.ForeColor = System.Drawing.Color.White;
            this.Send.Location = new System.Drawing.Point(547, 526);
            this.Send.Name = "Send";
            this.Send.Size = new System.Drawing.Size(175, 67);
            this.Send.TabIndex = 0;
            this.Send.Text = "Send Mail";
            this.Send.UseVisualStyleBackColor = false;
            this.Send.Click += new System.EventHandler(this.Send_Click);
            // 
            // Send_To
            // 
            this.Send_To.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Send_To.Location = new System.Drawing.Point(231, 151);
            this.Send_To.Multiline = true;
            this.Send_To.Name = "Send_To";
            this.Send_To.Size = new System.Drawing.Size(308, 29);
            this.Send_To.TabIndex = 1;
            // 
            // Send_To_Text
            // 
            this.Send_To_Text.AutoSize = true;
            this.Send_To_Text.BackColor = System.Drawing.Color.Transparent;
            this.Send_To_Text.Font = new System.Drawing.Font("Calibri", 21.75F);
            this.Send_To_Text.Location = new System.Drawing.Point(118, 150);
            this.Send_To_Text.Name = "Send_To_Text";
            this.Send_To_Text.Size = new System.Drawing.Size(41, 36);
            this.Send_To_Text.TabIndex = 2;
            this.Send_To_Text.Text = "To";
            // 
            // Subject
            // 
            this.Subject.AutoSize = true;
            this.Subject.BackColor = System.Drawing.Color.Transparent;
            this.Subject.Font = new System.Drawing.Font("Calibri", 21.75F);
            this.Subject.Location = new System.Drawing.Point(114, 206);
            this.Subject.Name = "Subject";
            this.Subject.Size = new System.Drawing.Size(101, 36);
            this.Subject.TabIndex = 3;
            this.Subject.Text = "Subject";
            // 
            // content
            // 
            this.content.AutoSize = true;
            this.content.BackColor = System.Drawing.Color.Transparent;
            this.content.Font = new System.Drawing.Font("Calibri", 21.75F);
            this.content.Location = new System.Drawing.Point(109, 266);
            this.content.Name = "content";
            this.content.Size = new System.Drawing.Size(106, 36);
            this.content.TabIndex = 4;
            this.content.Text = "content";
            // 
            // Subject_Input
            // 
            this.Subject_Input.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Subject_Input.Location = new System.Drawing.Point(231, 214);
            this.Subject_Input.Multiline = true;
            this.Subject_Input.Name = "Subject_Input";
            this.Subject_Input.Size = new System.Drawing.Size(308, 29);
            this.Subject_Input.TabIndex = 5;
            // 
            // ContentInput
            // 
            this.ContentInput.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.ContentInput.Location = new System.Drawing.Point(231, 279);
            this.ContentInput.Multiline = true;
            this.ContentInput.Name = "ContentInput";
            this.ContentInput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ContentInput.Size = new System.Drawing.Size(308, 226);
            this.ContentInput.TabIndex = 6;
            // 
            // Back_Butt
            // 
            this.Back_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Back_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Back_Butt.ForeColor = System.Drawing.Color.White;
            this.Back_Butt.Location = new System.Drawing.Point(12, 526);
            this.Back_Butt.Name = "Back_Butt";
            this.Back_Butt.Size = new System.Drawing.Size(183, 73);
            this.Back_Butt.TabIndex = 7;
            this.Back_Butt.Text = "Back";
            this.Back_Butt.UseVisualStyleBackColor = false;
            this.Back_Butt.Click += new System.EventHandler(this.Back_Butt_Click);
            // 
            // mail_Text
            // 
            this.mail_Text.AutoSize = true;
            this.mail_Text.BackColor = System.Drawing.Color.Transparent;
            this.mail_Text.Font = new System.Drawing.Font("Calibri", 26.25F);
            this.mail_Text.ForeColor = System.Drawing.Color.Navy;
            this.mail_Text.Location = new System.Drawing.Point(179, 71);
            this.mail_Text.Name = "mail_Text";
            this.mail_Text.Size = new System.Drawing.Size(372, 42);
            this.mail_Text.TabIndex = 8;
            this.mail_Text.Text = "Write your message here";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 14);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 74;
            this.pictureBox2.TabStop = false;
            // 
            // SendEmailToList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.mail_Text);
            this.Controls.Add(this.Back_Butt);
            this.Controls.Add(this.ContentInput);
            this.Controls.Add(this.Subject_Input);
            this.Controls.Add(this.content);
            this.Controls.Add(this.Subject);
            this.Controls.Add(this.Send_To_Text);
            this.Controls.Add(this.Send_To);
            this.Controls.Add(this.Send);
            this.Name = "SendEmailToList";
            this.Text = "SendEmailToList";
            this.Load += new System.EventHandler(this.SendEmailToList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Send;
        private System.Windows.Forms.TextBox Send_To;
        private System.Windows.Forms.Label Send_To_Text;
        private System.Windows.Forms.Label Subject;
        private System.Windows.Forms.Label content;
        private System.Windows.Forms.TextBox Subject_Input;
        private System.Windows.Forms.TextBox ContentInput;
        private System.Windows.Forms.Button Back_Butt;
        private System.Windows.Forms.Label mail_Text;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}