﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class Dashboard : Form
    {
        private string startDate;
        private string endDate;

        SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_29;Integrated Security=True");

   

        public Dashboard()
        {
            conn.Open();
            InitializeComponent();
            chart2.Hide();
            chart1.Hide();
            chart3.Hide();
            GroupBySuppliers.Hide();
            label1.Hide();
            SortBySuppliersAnswer.Hide();
            SortByStatusAnswer.Hide();
            HideChart_Butt.Hide();
           HideChart1_Butt.Hide();
           Hide_Chart3_Butt.Hide();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
           
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void Produce_Click(object sender, EventArgs e)
        {
            // Update the chart when the Produce button is clicked

            UpdateChart();
        }

        private void UpdateChart()
        {

            
            // Get the start and end dates from the DateTime pickers
            startDate = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            endDate = dateTimePicker2.Value.ToString("yyyy-MM-dd");

            // Create a new data table to store the chart data
            DataTable chartData = new DataTable();

            // Add columns to the data table for the X and Y values
            chartData.Columns.Add("Year", typeof(string));
            chartData.Columns.Add("Total", typeof(string));

            // Build the SELECT query
            string query = "SELECT YEAR(OrderDate) AS YEAR, SUM(Total) AS ORDERS_COST " +
               "FROM [bgu-users\\kmaay].[TOTAL_ORDERS_PRICES] " +
               "WHERE OrderDate BETWEEN @startDate AND @endDate " +
               "GROUP BY YEAR(OrderDate)";

       
          

            // Execute the SELECT query and add rows to the data table for each order
            using (SqlCommand cmd1 = new SqlCommand(query, conn))
            {
                cmd1.Parameters.AddWithValue("@startDate", this.startDate);
                cmd1.Parameters.AddWithValue("@endDate", this.endDate);

                using (SqlDataReader reader1 = cmd1.ExecuteReader())
                {
                    while (reader1.Read())
                    {
                        string month = reader1.GetValue(0).ToString();
                        string Total = reader1.GetValue(1).ToString();

                        chartData.Rows.Add(new object[] { month, Total });
                    }

                }

            }

            // Bind the data table to the chart control and set the X and Y value members
            chart2.DataSource = chartData;
            chart2.Series[0].XValueMember = "Year";
            chart2.Series[0].YValueMembers = "Total";
            chart2.DataBind();
            chart2.Show();
            HideChart_Butt.Show();
        }

        private void HideChart_Butt_Click(object sender, EventArgs e)
        {
            chart2.Hide();
            HideChart_Butt.Hide();
        }


   
        private void ProductsDashboard_Click(object sender, EventArgs e)
        {
            UpdateChart1();
            UpdateChart3();
        }

        private void UpdateChart1()
        {
            GroupBySuppliers.Show();
            label1.Show();
            SortBySuppliersAnswer.Show();
            SortByStatusAnswer.Show();
            
            // Get the start and end dates from the DateTime pickers
            startDate = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            endDate = dateTimePicker2.Value.ToString("yyyy-MM-dd");

            // Create a new data table to store the chart data
            DataTable chartData2 = new DataTable();

            // Add columns to the data table for the X and Y values
            chartData2.Columns.Add("Supplier", typeof(string));
            chartData2.Columns.Add("Total", typeof(string));

            if (SortBySuppliersAnswer.Checked)
            {

                // Build the SELECT query
                string query2 = "SELECT S_ID AS SUPPLIER, SUM(Total) AS Total " +
               "FROM [bgu-users\\kmaay].[SortBySupplier] " +
               "WHERE OrderDate BETWEEN @startDate AND @endDate " +
               "GROUP BY S_ID";

                using (SqlCommand cmd2 = new SqlCommand(query2, conn))
                {
                    cmd2.Parameters.AddWithValue("@startDate", this.startDate);
                    cmd2.Parameters.AddWithValue("@endDate", this.endDate);

                    using (SqlDataReader reader2 = cmd2.ExecuteReader())
                    {
                        while (reader2.Read())
                        {
                            string supplier = reader2.GetValue(0).ToString();
                            string Total = reader2.GetValue(1).ToString();

                            chartData2.Rows.Add(new object[] { supplier, Total });
                            chart1.Show();
                        }

                    }

                }

                // Bind the data table to the chart control and set the X and Y value members
                chart1.DataSource = chartData2;
                chart1.Series[0].XValueMember = "Supplier";
                chart1.Series[0].YValueMembers = "Total";
                chart1.DataBind();
                HideChart1_Butt.Show();
            }
        }

        private void UpdateChart3()
        {
            GroupBySuppliers.Show();
            label1.Show();
            SortBySuppliersAnswer.Show();
            SortByStatusAnswer.Show();
            
            // Get the start and end dates from the DateTime pickers
            startDate = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            endDate = dateTimePicker2.Value.ToString("yyyy-MM-dd");

            // Create a new data table to store the chart data
            DataTable chartData3 = new DataTable();

            // Add columns to the data table for the X and Y values
            chartData3.Columns.Add("ProductCategory", typeof(string));
            chartData3.Columns.Add("Total", typeof(string));
            if (SortByStatusAnswer.Checked)
            {

                // Build the SELECT query
                string query3 = "SELECT ProductCategory AS ProductCategory, SUM(Total) AS Total " +
               "FROM [bgu-users\\kmaay].[SortByCategory] " +
               "WHERE OrderDate BETWEEN @startDate AND @endDate " +
               "GROUP BY ProductCategory";

                using (SqlCommand cmd3 = new SqlCommand(query3, conn))
                {
                    cmd3.Parameters.AddWithValue("@startDate", this.startDate);
                    cmd3.Parameters.AddWithValue("@endDate", this.endDate);

                    using (SqlDataReader reader3 = cmd3.ExecuteReader())
                    {
                        while (reader3.Read())
                        {
                            string productCategory = reader3.GetValue(0).ToString();
                            string Total = reader3.GetValue(1).ToString();


                            chartData3.Rows.Add(new object[] { productCategory, Total });
                        }

                    }

                }

                // Bind the data table to the chart control and set the X and Y value members
                chart3.DataSource = chartData3;
                chart3.Series[0].XValueMember = "ProductCategory";
                chart3.Series[0].YValueMembers = "Total";
                chart3.DataBind();
                chart3.Show();
                Hide_Chart3_Butt.Show();
            }
        }

        private void HideChart1_Butt_Click_1(object sender, EventArgs e)
        {
            chart1.Hide();
            HideChart1_Butt.Hide();
        }

        private void Hide_Chart3_Butt_Click(object sender, EventArgs e)
        {
            chart3.Hide();
            Hide_Chart3_Butt.Hide();
        }

        private void DashboardTitle_Click(object sender, EventArgs e)
        {

        }

        private void StartDate_Click(object sender, EventArgs e)
        {

        }

        private void FinishDate_Click(object sender, EventArgs e)
        {

        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            HomePage update_A = new HomePage();
            update_A.Show();
            this.Hide();
        }
    }
}

  

 


    