﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;



namespace CYCLE
{
    public class Session
    {
        private DateTime SessionDate;
        private int Duration;
        private string Topic;
        private int SessionNumber;
        private Location SessionLocation;
        private int IsCancelled;
        public System.Collections.Generic.List<Lecture> lectures;


        public Session(DateTime SessionDate, int Duration, string Topic, int SessionNumber, Location SessionLocation, int IsCancelled, bool is_new)
        {
            this.SessionDate = SessionDate;
            this.Duration = Duration;
            this.Topic = Topic;
            this.SessionNumber = SessionNumber;
            this.SessionLocation = SessionLocation;
            this.IsCancelled = IsCancelled;

            if (is_new)
            {
                this.create_Session();
                Program.Sessions.Add(this);
            }
        }

        public DateTime get_SessionDate()
        {
            return this.SessionDate;
        }

        public int get_Duration()
        {
            return this.Duration;
        }

        public void set_Duration(int i)
        {
            this.Duration = i;
        }

        public string get_Topic()
        {
            return this.Topic;
        }

        public void set_Topic(string s)
        {
            this.Topic = s;
        }

        public int get_SessionNumber()
        {
            return this.SessionNumber;
        }

        public void set_SessionNumber(int i)
        {
            this.SessionNumber = i;
        }

        public Location get_SessionLocation()
        {
            return this.SessionLocation;
        }

        public void set_SessionLocation(Location loc)
        {
            this.SessionLocation = loc;
        }

        public int get_IsCancelled()
        {
            return this.IsCancelled;
        }

        public void set_IsCancelled(int i)
        {
            this.IsCancelled = i;
        }


        public System.Collections.Generic.List<Lecture> Lectures // get and set for the whole list
        {
            get
            {
                if (lectures == null)
                    lectures = new System.Collections.Generic.List<Lecture>();
                return lectures;
            }
            set
            {
                RemoveAllLectures();
                if (value != null)
                {
                    foreach (Lecture oLecture in value)
                        AddLectures(oLecture);
                }
            }
        }
        
        public void AddLectures(Lecture newLecture)
        {
            if (newLecture == null)
                return;
            if (this.lectures == null)
                this.lectures = new System.Collections.Generic.List<Lecture>();
            if (!this.lectures.Contains(newLecture))
            {
                this.lectures.Add(newLecture);
                newLecture.Session = this;
            }
        }
        
        public void RemoveLectures(Lecture oldLecture)
        {
            if (oldLecture == null)
                return;
            if (this.lectures != null)
                if (this.lectures.Contains(oldLecture))
                {
                    this.lectures.Remove(oldLecture);
                    oldLecture.Session = null;
                }
        }

        public void RemoveAllLectures()
        {
            if (lectures != null)
            {
                foreach (Lecture l in lectures)
                    l.Session = null;
                lectures.Clear();
            }
        }
        

        public void create_Session()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_add_Session @SessionDate, @Duration, @Topic, @SessionNumber, @SessionLocation, @isCancelled";
            c.Parameters.AddWithValue("@SessionDate", this.SessionDate);
            c.Parameters.AddWithValue("@Duration", this.Duration);
            c.Parameters.AddWithValue("@Topic", this.Topic);
            c.Parameters.AddWithValue("@SessionNumber", this.SessionNumber);
            c.Parameters.AddWithValue("@SessionLocation", this.SessionLocation.ToString());
            c.Parameters.AddWithValue("@isCancelled", this.IsCancelled.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Update_Session()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_Update_Session @SessionDate, @Duration, @Topic, @SessionNumber, @SessionLocation, @isCancelled";
            c.Parameters.AddWithValue("@SessionDate", this.SessionDate);
            c.Parameters.AddWithValue("@Duration", this.Duration);
            c.Parameters.AddWithValue("@Topic", this.Topic);
            c.Parameters.AddWithValue("@SessionNumber", this.SessionNumber);
            c.Parameters.AddWithValue("@SessionLocation", this.SessionLocation.ToString());
            c.Parameters.AddWithValue("@isCancelled", this.IsCancelled.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Delete_Session()
        {
            Program.Sessions.Remove(this);
            this.RemoveAllLectures();
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_delete_Session @SessionDate";
            c.Parameters.AddWithValue("@SessionDate", this.SessionDate);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        } 

    }

}



