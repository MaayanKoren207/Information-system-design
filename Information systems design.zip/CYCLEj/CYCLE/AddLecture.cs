﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class AddLecture : Form
    {
        private Session S_Exist;
        public AddLecture()
        {
            ///////StartTime_Lable ////Duration_Lable  //Topic_Lable ///SessionDT_Lable 
            //StartTime_Input  //Duration_Input //Topic_Input //SessionDT_Input
            //Search_SessionDT_Butt   //Back_Butt ///AddLecture_Butt
            //Insert_S_DT_Req_Lable  //Invalid_SessionDT_Lable //Ins_L_Info_Lable //Invalid_Lecture_Lable


            InitializeComponent();
            Topic_Input.DataSource = Enum.GetValues(typeof(LectureTopic));
            Topic_Input.SelectedIndex = -1;

            StartTime_Lable.Hide();
            Duration_Lable.Hide();
            Topic_Lable.Hide();

            StartTime_Input.Hide();
            Duration_Input.Hide();
            Topic_Input.Hide();
            TooLong.Hide();

            AddLecture_Butt.Hide();
            Invalid_SessionDT_Lable.Hide();
            Ins_L_Info_Lable.Hide();
            Invalid_Lecture_Lable.Hide();

        }

        private void AddLecture_Load(object sender, EventArgs e)
        {

        }

        private void Search_SessionDT_Butt_Click(object sender, EventArgs e)
        {
            S_Exist = Program.seekSession((DateTime.Parse(SessionDT_Input.Text)));
            if (Topic_Input.SelectedIndex.Equals(-1))
            {
                Topic_Input.SelectedIndex = 0; //default: NLP

            }
            if (S_Exist != null)
            {
                Ins_L_Info_Lable.Show();
                StartTime_Input.Value = SessionDT_Input.Value;
                StartTime_Lable.Show();
                Duration_Lable.Show();
                Topic_Lable.Show();
                StartTime_Input.Show();
                Duration_Input.Show();
                Topic_Input.Show();

                AddLecture_Butt.Show();
            }
            else
            {
                Invalid_SessionDT_Lable.Show();
            }
        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            Form ownerForm = this.Owner;
            ownerForm.Show();
            this.Hide();
        }

        private void AddLecture_Butt_Click(object sender, EventArgs e)
        {
            if (IsValidInput() && TotalTime())
            {
                Invalid_Lecture_Lable.Hide();

                Lecture l = new Lecture((DateTime.Parse(StartTime_Input.Text)), (int.Parse(Duration_Input.Text)), (LectureTopic)Enum.Parse(typeof(LectureTopic), Topic_Input.Text), S_Exist, true);

                HomePage mf = new HomePage();
                mf.Show();
                this.Close();
            }
            else if (!IsValidInput())
            {
                Invalid_Lecture_Lable.Show();
                if (Invalid_Lecture_Lable.Font.Size <= 20)
                    Invalid_Lecture_Lable.Font = new Font(Invalid_Lecture_Lable.Font.FontFamily, Invalid_Lecture_Lable.Font.Size + 1);
                else if (Invalid_Lecture_Lable.ForeColor == Color.Red)
                    Invalid_Lecture_Lable.ForeColor = Color.Gold;
                else
                    Invalid_Lecture_Lable.ForeColor = Color.Red;
            }
            else if (!TotalTime())
            {
                TooLong.Show();
                if (TooLong.Font.Size <= 20)
                    TooLong.Font = new Font(TooLong.Font.FontFamily, TooLong.Font.Size + 1);
                else if (TooLong.ForeColor == Color.Red)
                    TooLong.ForeColor = Color.Gold;
                else
                    TooLong.ForeColor = Color.Red;
            }
        }



        private bool IsValidInput()
        {
            if (!Int32.TryParse(Duration_Input.Text, out int Value))
            {
                return false; //Making sure Duration is all numbers
            }
            else if (SessionDT_Input.Text == null || Duration_Input.Text == null || StartTime_Input.Text == null)
            {
                return false; // Making sure no input is to stay null
            }
            else if (SessionDT_Input.Value.Date != StartTime_Input.Value.Date)
                return false;// Making sure the Lecture is set on the same date as the Session
            else
                return true;
        }

        private bool TotalTime()
        {
            int totalTime = 0;// Making sure a lecture dont exceed the duration of the session
            S_Exist = Program.seekSession((DateTime.Parse(SessionDT_Input.Text)));
            if (S_Exist != null)
            {
                foreach (Lecture L in S_Exist.Lectures)
                {
                    totalTime = totalTime + L.get_Duration();
                }
                if (totalTime + int.Parse(Duration_Input.Text) > S_Exist.get_Duration())
                    return false;
                else return true;
            }
            else if (S_Exist.get_Duration() < int.Parse(Duration_Input.Text))
                return false;
            else return true;


        }
    }
}
