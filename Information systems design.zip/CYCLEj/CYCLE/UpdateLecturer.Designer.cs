﻿namespace CYCLE
{
    partial class UpdateLecturer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.L_ID_Lable = new System.Windows.Forms.Label();
            this.FirstName_Lable = new System.Windows.Forms.Label();
            this.LastName_Lable = new System.Windows.Forms.Label();
            this.Email_Lable = new System.Windows.Forms.Label();
            this.PhoneNumber_Lable = new System.Windows.Forms.Label();
            this.Status_Lable = new System.Windows.Forms.Label();
            this.ID_Input = new System.Windows.Forms.TextBox();
            this.FirstName_Input = new System.Windows.Forms.TextBox();
            this.LastName_Input = new System.Windows.Forms.TextBox();
            this.Email_Input = new System.Windows.Forms.TextBox();
            this.PhoneNum_Input = new System.Windows.Forms.TextBox();
            this.Status_comboBox_Input = new System.Windows.Forms.ComboBox();
            this.L_Back = new System.Windows.Forms.Button();
            this.L_Update = new System.Windows.Forms.Button();
            this.L_Delete = new System.Windows.Forms.Button();
            this.L_Search = new System.Windows.Forms.Button();
            this.L_Valid_ID = new System.Windows.Forms.Label();
            this.L_Valid = new System.Windows.Forms.Label();
            this.ViewOptAss_Butt = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // L_ID_Lable
            // 
            this.L_ID_Lable.AutoSize = true;
            this.L_ID_Lable.BackColor = System.Drawing.Color.Transparent;
            this.L_ID_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.L_ID_Lable.Location = new System.Drawing.Point(13, 141);
            this.L_ID_Lable.Name = "L_ID_Lable";
            this.L_ID_Lable.Size = new System.Drawing.Size(98, 26);
            this.L_ID_Lable.TabIndex = 0;
            this.L_ID_Lable.Text = "ID Lecture";
            // 
            // FirstName_Lable
            // 
            this.FirstName_Lable.AutoSize = true;
            this.FirstName_Lable.BackColor = System.Drawing.Color.Transparent;
            this.FirstName_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.FirstName_Lable.Location = new System.Drawing.Point(8, 240);
            this.FirstName_Lable.Name = "FirstName_Lable";
            this.FirstName_Lable.Size = new System.Drawing.Size(105, 26);
            this.FirstName_Lable.TabIndex = 1;
            this.FirstName_Lable.Text = "First Name";
            // 
            // LastName_Lable
            // 
            this.LastName_Lable.AutoSize = true;
            this.LastName_Lable.BackColor = System.Drawing.Color.Transparent;
            this.LastName_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.LastName_Lable.Location = new System.Drawing.Point(9, 294);
            this.LastName_Lable.Name = "LastName_Lable";
            this.LastName_Lable.Size = new System.Drawing.Size(102, 26);
            this.LastName_Lable.TabIndex = 2;
            this.LastName_Lable.Text = "Last Name";
            // 
            // Email_Lable
            // 
            this.Email_Lable.AutoSize = true;
            this.Email_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Email_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Email_Lable.Location = new System.Drawing.Point(10, 354);
            this.Email_Lable.Name = "Email_Lable";
            this.Email_Lable.Size = new System.Drawing.Size(59, 26);
            this.Email_Lable.TabIndex = 3;
            this.Email_Lable.Text = "Email";
            // 
            // PhoneNumber_Lable
            // 
            this.PhoneNumber_Lable.AutoSize = true;
            this.PhoneNumber_Lable.BackColor = System.Drawing.Color.Transparent;
            this.PhoneNumber_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.PhoneNumber_Lable.Location = new System.Drawing.Point(358, 237);
            this.PhoneNumber_Lable.Name = "PhoneNumber_Lable";
            this.PhoneNumber_Lable.Size = new System.Drawing.Size(141, 26);
            this.PhoneNumber_Lable.TabIndex = 4;
            this.PhoneNumber_Lable.Text = "Phone Number";
            // 
            // Status_Lable
            // 
            this.Status_Lable.AutoSize = true;
            this.Status_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Status_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Status_Lable.Location = new System.Drawing.Point(358, 287);
            this.Status_Lable.Name = "Status_Lable";
            this.Status_Lable.Size = new System.Drawing.Size(65, 26);
            this.Status_Lable.TabIndex = 5;
            this.Status_Lable.Text = "Status";
            // 
            // ID_Input
            // 
            this.ID_Input.Location = new System.Drawing.Point(135, 143);
            this.ID_Input.Multiline = true;
            this.ID_Input.Name = "ID_Input";
            this.ID_Input.Size = new System.Drawing.Size(185, 27);
            this.ID_Input.TabIndex = 6;
            // 
            // FirstName_Input
            // 
            this.FirstName_Input.Location = new System.Drawing.Point(135, 239);
            this.FirstName_Input.Multiline = true;
            this.FirstName_Input.Name = "FirstName_Input";
            this.FirstName_Input.Size = new System.Drawing.Size(185, 27);
            this.FirstName_Input.TabIndex = 7;
            // 
            // LastName_Input
            // 
            this.LastName_Input.Location = new System.Drawing.Point(135, 293);
            this.LastName_Input.Multiline = true;
            this.LastName_Input.Name = "LastName_Input";
            this.LastName_Input.Size = new System.Drawing.Size(185, 27);
            this.LastName_Input.TabIndex = 8;
            // 
            // Email_Input
            // 
            this.Email_Input.Location = new System.Drawing.Point(135, 350);
            this.Email_Input.Multiline = true;
            this.Email_Input.Name = "Email_Input";
            this.Email_Input.Size = new System.Drawing.Size(185, 27);
            this.Email_Input.TabIndex = 9;
            // 
            // PhoneNum_Input
            // 
            this.PhoneNum_Input.Location = new System.Drawing.Point(519, 239);
            this.PhoneNum_Input.Multiline = true;
            this.PhoneNum_Input.Name = "PhoneNum_Input";
            this.PhoneNum_Input.Size = new System.Drawing.Size(185, 27);
            this.PhoneNum_Input.TabIndex = 10;
            // 
            // Status_comboBox_Input
            // 
            this.Status_comboBox_Input.BackColor = System.Drawing.Color.White;
            this.Status_comboBox_Input.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Status_comboBox_Input.Font = new System.Drawing.Font("Calibri", 12F);
            this.Status_comboBox_Input.FormattingEnabled = true;
            this.Status_comboBox_Input.Location = new System.Drawing.Point(519, 289);
            this.Status_comboBox_Input.Name = "Status_comboBox_Input";
            this.Status_comboBox_Input.Size = new System.Drawing.Size(185, 27);
            this.Status_comboBox_Input.TabIndex = 11;
            // 
            // L_Back
            // 
            this.L_Back.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.L_Back.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.L_Back.ForeColor = System.Drawing.Color.White;
            this.L_Back.Location = new System.Drawing.Point(12, 531);
            this.L_Back.Name = "L_Back";
            this.L_Back.Size = new System.Drawing.Size(140, 68);
            this.L_Back.TabIndex = 12;
            this.L_Back.Text = "Back";
            this.L_Back.UseVisualStyleBackColor = false;
            this.L_Back.Click += new System.EventHandler(this.L_Back_Click);
            // 
            // L_Update
            // 
            this.L_Update.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.L_Update.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.L_Update.ForeColor = System.Drawing.Color.White;
            this.L_Update.Location = new System.Drawing.Point(582, 531);
            this.L_Update.Name = "L_Update";
            this.L_Update.Size = new System.Drawing.Size(140, 68);
            this.L_Update.TabIndex = 13;
            this.L_Update.Text = "Update";
            this.L_Update.UseVisualStyleBackColor = false;
            this.L_Update.Click += new System.EventHandler(this.L_Update_Click);
            // 
            // L_Delete
            // 
            this.L_Delete.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.L_Delete.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.L_Delete.ForeColor = System.Drawing.Color.White;
            this.L_Delete.Location = new System.Drawing.Point(423, 531);
            this.L_Delete.Name = "L_Delete";
            this.L_Delete.Size = new System.Drawing.Size(140, 68);
            this.L_Delete.TabIndex = 14;
            this.L_Delete.Text = "Delete";
            this.L_Delete.UseVisualStyleBackColor = false;
            this.L_Delete.Click += new System.EventHandler(this.L_Delete_Click);
            // 
            // L_Search
            // 
            this.L_Search.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.L_Search.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_Search.ForeColor = System.Drawing.Color.White;
            this.L_Search.Location = new System.Drawing.Point(363, 141);
            this.L_Search.Name = "L_Search";
            this.L_Search.Size = new System.Drawing.Size(106, 28);
            this.L_Search.TabIndex = 15;
            this.L_Search.Text = "Search";
            this.L_Search.UseVisualStyleBackColor = false;
            this.L_Search.Click += new System.EventHandler(this.L_Search_Click);
            // 
            // L_Valid_ID
            // 
            this.L_Valid_ID.AutoSize = true;
            this.L_Valid_ID.BackColor = System.Drawing.Color.Transparent;
            this.L_Valid_ID.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.L_Valid_ID.ForeColor = System.Drawing.Color.Navy;
            this.L_Valid_ID.Location = new System.Drawing.Point(22, 52);
            this.L_Valid_ID.Name = "L_Valid_ID";
            this.L_Valid_ID.Size = new System.Drawing.Size(354, 33);
            this.L_Valid_ID.TabIndex = 16;
            this.L_Valid_ID.Text = "Please Input A Valid Lecturer ID";
            // 
            // L_Valid
            // 
            this.L_Valid.AutoSize = true;
            this.L_Valid.BackColor = System.Drawing.Color.Transparent;
            this.L_Valid.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.L_Valid.ForeColor = System.Drawing.Color.Navy;
            this.L_Valid.Location = new System.Drawing.Point(115, 189);
            this.L_Valid.Name = "L_Valid";
            this.L_Valid.Size = new System.Drawing.Size(221, 26);
            this.L_Valid.TabIndex = 17;
            this.L_Valid.Text = "Please Insert valid input!";
            // 
            // ViewOptAss_Butt
            // 
            this.ViewOptAss_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.ViewOptAss_Butt.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewOptAss_Butt.ForeColor = System.Drawing.Color.White;
            this.ViewOptAss_Butt.Location = new System.Drawing.Point(104, 440);
            this.ViewOptAss_Butt.Name = "ViewOptAss_Butt";
            this.ViewOptAss_Butt.Size = new System.Drawing.Size(496, 66);
            this.ViewOptAss_Butt.TabIndex = 18;
            this.ViewOptAss_Butt.Text = "View Lecturer Optional Assinings List";
            this.ViewOptAss_Butt.UseVisualStyleBackColor = false;
            this.ViewOptAss_Butt.Click += new System.EventHandler(this.ViewOptAss_Butt_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 43;
            this.pictureBox2.TabStop = false;
            // 
            // UpdateLecturer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.ViewOptAss_Butt);
            this.Controls.Add(this.L_Valid);
            this.Controls.Add(this.L_Valid_ID);
            this.Controls.Add(this.L_Search);
            this.Controls.Add(this.L_Delete);
            this.Controls.Add(this.L_Update);
            this.Controls.Add(this.L_Back);
            this.Controls.Add(this.Status_comboBox_Input);
            this.Controls.Add(this.PhoneNum_Input);
            this.Controls.Add(this.Email_Input);
            this.Controls.Add(this.LastName_Input);
            this.Controls.Add(this.FirstName_Input);
            this.Controls.Add(this.ID_Input);
            this.Controls.Add(this.Status_Lable);
            this.Controls.Add(this.PhoneNumber_Lable);
            this.Controls.Add(this.Email_Lable);
            this.Controls.Add(this.LastName_Lable);
            this.Controls.Add(this.FirstName_Lable);
            this.Controls.Add(this.L_ID_Lable);
            this.Name = "UpdateLecturer";
            this.Text = "UpdateLecturer";
            this.Load += new System.EventHandler(this.UpdateLecturer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label L_ID_Lable;
        private System.Windows.Forms.Label FirstName_Lable;
        private System.Windows.Forms.Label LastName_Lable;
        private System.Windows.Forms.Label Email_Lable;
        private System.Windows.Forms.Label PhoneNumber_Lable;
        private System.Windows.Forms.Label Status_Lable;
        private System.Windows.Forms.TextBox ID_Input;
        private System.Windows.Forms.TextBox FirstName_Input;
        private System.Windows.Forms.TextBox LastName_Input;
        private System.Windows.Forms.TextBox Email_Input;
        private System.Windows.Forms.TextBox PhoneNum_Input;
        private System.Windows.Forms.ComboBox Status_comboBox_Input;
        private System.Windows.Forms.Button L_Back;
        private System.Windows.Forms.Button L_Update;
        private System.Windows.Forms.Button L_Delete;
        private System.Windows.Forms.Button L_Search;
        private System.Windows.Forms.Label L_Valid_ID;
        private System.Windows.Forms.Label L_Valid;
        private System.Windows.Forms.Button ViewOptAss_Butt;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}