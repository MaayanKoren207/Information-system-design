﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class AddST : Form
    {
        private List<DateTime> DT;
        public Apprentice Candidate;
        public string ID;
        public AddST()
        {
            InitializeComponent();
            Warning.Hide();
            EmptyWarning.Hide();
            Datetimewarning.Hide();
            AverageScore.Hide();

            for (int i = 1; i < 6; i++)
            {
                ComboBox cat = (ComboBox)this.Controls["Cat" + i.ToString()];
                ComboBox rate = (ComboBox)this.Controls["CatRate" + i.ToString()];
                rate.SelectedIndex = -1;
                cat.DataSource = Enum.GetValues(typeof(SortingCategory));
                cat.SelectedIndex = i - 1;
            }


            SortingTestCRUD CRUD = SortingTestCRUD.CRUD;

            ID = CRUD.ID;
            Candidate = Program.seekAllApprentice(ID);
            CandidateID.Text = "ID: " + ID + "  " + Candidate.get_FirstName() + " " + Candidate.get_LastName();
            DT = new List<DateTime>();
            foreach (SortingTest st in Candidate.SortingTests)
            {
                if (!DT.Contains(st.get_TestDate()))
                    DT.Add(st.get_TestDate());
            }
        }

        private void AddST_Load(object sender, EventArgs e)
        {

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            SortingTestCRUD stc = new SortingTestCRUD();
            stc.Show();
            this.Close();
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            if (IsDupelicte())
            {
                EmptyWarning.Hide();
                Warning.Show();
                if (Warning.Font.Size <= 15)
                    Warning.Font = new Font(Warning.Font.FontFamily, Warning.Font.Size + 1);
                else if (Warning.ForeColor == Color.Red)
                    Warning.ForeColor = Color.Gold;
                else
                    Warning.ForeColor = Color.Red;
            }
            else if (isValid() == false)
            {
                Warning.Hide();
                EmptyWarning.Show();
                if (EmptyWarning.Font.Size <= 15)
                    EmptyWarning.Font = new Font(EmptyWarning.Font.FontFamily, EmptyWarning.Font.Size + 1);
                else if (EmptyWarning.ForeColor == Color.Red)
                    EmptyWarning.ForeColor = Color.Gold;
                else
                    EmptyWarning.ForeColor = Color.Red;
            }
            else
            {
                bool ST_Exist = false;
                Warning.Hide();
                EmptyWarning.Hide();

                var dt = new DateTime(
                        DateTimeInput.Value.Year,
                        DateTimeInput.Value.Month,
                        DateTimeInput.Value.Day,
                        DateTimeInput.Value.Hour,
                        DateTimeInput.Value.Minute,
                        DateTimeInput.Value.Second);
                foreach (CandidateRateByCat cat in Program.CandidateRateByCats)
                {
                    if (cat.sortingTest.get_TestDate() == dt && cat.SortingTest.Apprentice.getID() == Candidate.getID())
                    {
                        ST_Exist = true;
                        break;
                    }
                }
                if (!ST_Exist)
                {
                    Datetimewarning.Hide();
                    SortingTest st = new SortingTest(Candidate, dt, true);
                    for (int i = 1; i < 6; i++)
                    {
                        ComboBox cat = (ComboBox)this.Controls["Cat" + i.ToString()];
                        ComboBox rate = (ComboBox)this.Controls["CatRate" + i.ToString()];


                        SortingCategory selectedCategory = (SortingCategory)Enum.Parse(typeof(SortingCategory), cat.SelectedValue.ToString());

                        CategoryOfCandidate category = new CategoryOfCandidate(selectedCategory, false);


                        //CategoryOfCandidate category = new CategoryOfCandidate((SortingCategory)Enum.Parse(typeof(SortingCategory), cat.Text), false);


                        CandidateRateByCat newrate = new CandidateRateByCat(st, category, double.Parse(rate.SelectedItem.ToString()), true, false);
                    }
                }
                else Datetimewarning.Show();
            }

        }

        private bool isValid()
        {
            for (int i = 1; i < 6; i++)
            {
                ComboBox cat = (ComboBox)Controls["Cat" + i.ToString()];
                ComboBox rate = (ComboBox)this.Controls["CatRate" + i.ToString()];
                if (cat.SelectedItem == null || rate.SelectedItem == null)
                    return false;
            }
            return true;
        }

        private bool IsDupelicte()
        {
            object a1 = Cat1.SelectedValue;
            object a2 = Cat2.SelectedValue;
            object a3 = Cat3.SelectedValue;
            object a4 = Cat4.SelectedValue;
            object a5 = Cat5.SelectedValue;
            if (a1.ToString() == a2.ToString() || a1.ToString() == a3.ToString() || a1.ToString() == a4.ToString() || a1.ToString() == a5.ToString())
                return true;
            else if (a2.ToString() == a3.ToString() || a2.ToString() == a4.ToString() || a2.ToString() == a5.ToString())
                return true;
            else if (a3.ToString() == a4.ToString() || a3.ToString() == a5.ToString() || a4.ToString() == a5.ToString())
                return true;
            else return false;
        }

        private void CatRate1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
