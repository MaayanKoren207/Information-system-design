﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class AddProducts : Form
    {
        public AddProducts()

        {
            InitializeComponent();
            P_CategoryInput.DataSource = Enum.GetValues(typeof(ProductCategory));
            ErrorMSG.Hide();
        }

        private void AddProducts_Load(object sender, EventArgs e)
        {

        }




        private bool IsValidInput()
        {

            if (!Int32.TryParse(P_IDInput.Text, out int Value) || !Int32.TryParse(s: P_NumInput.Text, result: out Value) || !Double.TryParse(P_PriceInput.Text, out double value) || !Int32.TryParse(S_IDInputP.Text, out Value))
            {
                return false; //Making sure P_ID, S_ID, Price, Amount are all numbers
            }

            else if (P_IDInput.Text == null || P_NameInput.Text == null || P_NumInput.Text == null || P_PriceInput.Text == null || S_IDInputP.Text == null || P_CategoryInput.SelectedIndex < 0)
            {
                return false; // Making sure no input is to stay null
            }

            else if (Regex.IsMatch(P_NameInput.Text, @"^[a-zA-Z][a-z]*$") == false)
            {
                return false;// Making sure name containing only letters
            }

            else if (Double.TryParse(P_PriceInput.Text, out value) && value < 0 || int.TryParse(P_IDInput.Text, out Value) && Value < 0 || int.TryParse(S_IDInputP.Text, out Value) && Value < 0 || int.TryParse(P_NumInput.Text, out Value) && Value < 0)
                return false;

            else
                return true;
        }


        private void P_Back_Click_1(object sender, EventArgs e)
        {
            ProductCRUD p = new ProductCRUD();
            p.Show();
            this.Close();
        }

        private void P_AddNew_Click(object sender, EventArgs e)
        {
            if (!IsValidInput())
            {
                ErrorMSG.Show();
                if (ErrorMSG.Font.Size <= 20)
                    ErrorMSG.Font = new Font(ErrorMSG.Font.FontFamily, ErrorMSG.Font.Size + 1);
                else if (ErrorMSG.ForeColor == Color.Red)
                    ErrorMSG.ForeColor = Color.Gold;
                else
                    ErrorMSG.ForeColor = Color.Red;
            }
            else
            {
                bool P_Exist = false;
                ErrorMSG.Hide();
                foreach (Product P in Program.Products)
                {
                    if (P.get_ID() == P_IDInput.Text)
                    {
                        P_Exist = true;
                        break;
                    }
                }
                if (!P_Exist)
                {
                    if (Program.seekSupplier(S_IDInputP.Text.ToString()) == null)
                        ErrorMSG.Show();
                    else
                    {
                        Product P = new Product(Program.seekSupplier(S_IDInputP.Text.ToString()), P_IDInput.Text, P_NameInput.Text, int.Parse(P_NumInput.Text), int.Parse(P_PriceInput.Text), (ProductCategory)Enum.Parse(typeof(ProductCategory), P_CategoryInput.Text), true);
                        ProductCRUD p = new ProductCRUD();
                        p.Show();
                        this.Close();
                    }
                }
                else P_FormatText.Show();
            }
        }

        private void AddProducts_Load_1(object sender, EventArgs e)
        {

        }

        private void AddProducts_Load_2(object sender, EventArgs e)
        {

        }
    }
}