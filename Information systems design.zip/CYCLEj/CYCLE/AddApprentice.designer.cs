﻿namespace CYCLE
{
    partial class AddApprentice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.A_StatusEnumInput = new System.Windows.Forms.ComboBox();
            this.A_ID = new System.Windows.Forms.Label();
            this.A_FirstName = new System.Windows.Forms.Label();
            this.A_LastName = new System.Windows.Forms.Label();
            this.A_Age = new System.Windows.Forms.Label();
            this.A_Address = new System.Windows.Forms.Label();
            this.A_Email = new System.Windows.Forms.Label();
            this.A_PhoneNum = new System.Windows.Forms.Label();
            this.A_Status = new System.Windows.Forms.Label();
            this.A_IDInput = new System.Windows.Forms.TextBox();
            this.A_FnameInput = new System.Windows.Forms.TextBox();
            this.A_LnameInput = new System.Windows.Forms.TextBox();
            this.A_AgeInput = new System.Windows.Forms.TextBox();
            this.A_AddressInput = new System.Windows.Forms.TextBox();
            this.A_EmailInput = new System.Windows.Forms.TextBox();
            this.A_PhoneNumInput = new System.Windows.Forms.TextBox();
            this.A_AddNew = new System.Windows.Forms.Button();
            this.A_FormatText = new System.Windows.Forms.Label();
            this.A_Back = new System.Windows.Forms.Button();
            this.Is_Candidate = new System.Windows.Forms.Label();
            this.Is_C_Input = new System.Windows.Forms.ComboBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Invalid_App_Lable = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // A_StatusEnumInput
            // 
            this.A_StatusEnumInput.BackColor = System.Drawing.Color.White;
            this.A_StatusEnumInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.A_StatusEnumInput.Font = new System.Drawing.Font("Calibri", 12F);
            this.A_StatusEnumInput.FormattingEnabled = true;
            this.A_StatusEnumInput.Location = new System.Drawing.Point(522, 319);
            this.A_StatusEnumInput.Name = "A_StatusEnumInput";
            this.A_StatusEnumInput.Size = new System.Drawing.Size(185, 27);
            this.A_StatusEnumInput.TabIndex = 0;
            // 
            // A_ID
            // 
            this.A_ID.AutoSize = true;
            this.A_ID.BackColor = System.Drawing.Color.Transparent;
            this.A_ID.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A_ID.Location = new System.Drawing.Point(11, 170);
            this.A_ID.Name = "A_ID";
            this.A_ID.Size = new System.Drawing.Size(128, 26);
            this.A_ID.TabIndex = 1;
            this.A_ID.Text = "Apprentice ID";
            // 
            // A_FirstName
            // 
            this.A_FirstName.AutoSize = true;
            this.A_FirstName.BackColor = System.Drawing.Color.Transparent;
            this.A_FirstName.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A_FirstName.Location = new System.Drawing.Point(11, 223);
            this.A_FirstName.Name = "A_FirstName";
            this.A_FirstName.Size = new System.Drawing.Size(105, 26);
            this.A_FirstName.TabIndex = 2;
            this.A_FirstName.Text = "First Name";
            this.A_FirstName.Click += new System.EventHandler(this.A_FirstName_Click);
            // 
            // A_LastName
            // 
            this.A_LastName.AutoSize = true;
            this.A_LastName.BackColor = System.Drawing.Color.Transparent;
            this.A_LastName.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A_LastName.Location = new System.Drawing.Point(11, 272);
            this.A_LastName.Name = "A_LastName";
            this.A_LastName.Size = new System.Drawing.Size(102, 26);
            this.A_LastName.TabIndex = 3;
            this.A_LastName.Text = "Last Name";
            // 
            // A_Age
            // 
            this.A_Age.AutoSize = true;
            this.A_Age.BackColor = System.Drawing.Color.Transparent;
            this.A_Age.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_Age.Location = new System.Drawing.Point(7, 323);
            this.A_Age.Name = "A_Age";
            this.A_Age.Size = new System.Drawing.Size(142, 26);
            this.A_Age.TabIndex = 4;
            this.A_Age.Text = "Apprentice Age";
            // 
            // A_Address
            // 
            this.A_Address.AutoSize = true;
            this.A_Address.BackColor = System.Drawing.Color.Transparent;
            this.A_Address.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_Address.Location = new System.Drawing.Point(11, 373);
            this.A_Address.Name = "A_Address";
            this.A_Address.Size = new System.Drawing.Size(79, 26);
            this.A_Address.TabIndex = 5;
            this.A_Address.Text = "Address";
            // 
            // A_Email
            // 
            this.A_Email.AutoSize = true;
            this.A_Email.BackColor = System.Drawing.Color.Transparent;
            this.A_Email.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_Email.Location = new System.Drawing.Point(366, 167);
            this.A_Email.Name = "A_Email";
            this.A_Email.Size = new System.Drawing.Size(157, 26);
            this.A_Email.TabIndex = 6;
            this.A_Email.Text = "Email Apprentice";
            // 
            // A_PhoneNum
            // 
            this.A_PhoneNum.AutoSize = true;
            this.A_PhoneNum.BackColor = System.Drawing.Color.Transparent;
            this.A_PhoneNum.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_PhoneNum.Location = new System.Drawing.Point(366, 217);
            this.A_PhoneNum.Name = "A_PhoneNum";
            this.A_PhoneNum.Size = new System.Drawing.Size(141, 26);
            this.A_PhoneNum.TabIndex = 7;
            this.A_PhoneNum.Text = "Phone Number";
            // 
            // A_Status
            // 
            this.A_Status.AutoSize = true;
            this.A_Status.BackColor = System.Drawing.Color.Transparent;
            this.A_Status.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.A_Status.Location = new System.Drawing.Point(377, 316);
            this.A_Status.Name = "A_Status";
            this.A_Status.Size = new System.Drawing.Size(65, 26);
            this.A_Status.TabIndex = 8;
            this.A_Status.Text = "Status";
            // 
            // A_IDInput
            // 
            this.A_IDInput.Location = new System.Drawing.Point(158, 173);
            this.A_IDInput.Multiline = true;
            this.A_IDInput.Name = "A_IDInput";
            this.A_IDInput.Size = new System.Drawing.Size(185, 25);
            this.A_IDInput.TabIndex = 9;
            // 
            // A_FnameInput
            // 
            this.A_FnameInput.Location = new System.Drawing.Point(158, 223);
            this.A_FnameInput.Multiline = true;
            this.A_FnameInput.Name = "A_FnameInput";
            this.A_FnameInput.Size = new System.Drawing.Size(185, 25);
            this.A_FnameInput.TabIndex = 10;
            // 
            // A_LnameInput
            // 
            this.A_LnameInput.Location = new System.Drawing.Point(158, 272);
            this.A_LnameInput.Multiline = true;
            this.A_LnameInput.Name = "A_LnameInput";
            this.A_LnameInput.Size = new System.Drawing.Size(185, 25);
            this.A_LnameInput.TabIndex = 11;
            // 
            // A_AgeInput
            // 
            this.A_AgeInput.Location = new System.Drawing.Point(158, 325);
            this.A_AgeInput.Multiline = true;
            this.A_AgeInput.Name = "A_AgeInput";
            this.A_AgeInput.Size = new System.Drawing.Size(185, 25);
            this.A_AgeInput.TabIndex = 12;
            // 
            // A_AddressInput
            // 
            this.A_AddressInput.Location = new System.Drawing.Point(158, 373);
            this.A_AddressInput.Multiline = true;
            this.A_AddressInput.Name = "A_AddressInput";
            this.A_AddressInput.Size = new System.Drawing.Size(185, 25);
            this.A_AddressInput.TabIndex = 13;
            // 
            // A_EmailInput
            // 
            this.A_EmailInput.Location = new System.Drawing.Point(525, 170);
            this.A_EmailInput.Multiline = true;
            this.A_EmailInput.Name = "A_EmailInput";
            this.A_EmailInput.Size = new System.Drawing.Size(185, 25);
            this.A_EmailInput.TabIndex = 14;
            // 
            // A_PhoneNumInput
            // 
            this.A_PhoneNumInput.Location = new System.Drawing.Point(522, 222);
            this.A_PhoneNumInput.Multiline = true;
            this.A_PhoneNumInput.Name = "A_PhoneNumInput";
            this.A_PhoneNumInput.Size = new System.Drawing.Size(185, 25);
            this.A_PhoneNumInput.TabIndex = 15;
            // 
            // A_AddNew
            // 
            this.A_AddNew.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.A_AddNew.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A_AddNew.ForeColor = System.Drawing.SystemColors.Control;
            this.A_AddNew.Location = new System.Drawing.Point(582, 540);
            this.A_AddNew.Name = "A_AddNew";
            this.A_AddNew.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.A_AddNew.Size = new System.Drawing.Size(140, 68);
            this.A_AddNew.TabIndex = 16;
            this.A_AddNew.Text = "Add Apprentice";
            this.A_AddNew.UseVisualStyleBackColor = false;
            this.A_AddNew.Click += new System.EventHandler(this.A_AddNew_Click);
            // 
            // A_FormatText
            // 
            this.A_FormatText.AutoSize = true;
            this.A_FormatText.BackColor = System.Drawing.Color.Transparent;
            this.A_FormatText.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A_FormatText.ForeColor = System.Drawing.Color.Navy;
            this.A_FormatText.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.A_FormatText.Location = new System.Drawing.Point(45, 80);
            this.A_FormatText.Name = "A_FormatText";
            this.A_FormatText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.A_FormatText.Size = new System.Drawing.Size(526, 33);
            this.A_FormatText.TabIndex = 17;
            this.A_FormatText.Text = "Please Insert Input Only In The Correct Format!";
            this.A_FormatText.Click += new System.EventHandler(this.A_FormatText_Click);
            // 
            // A_Back
            // 
            this.A_Back.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.A_Back.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A_Back.ForeColor = System.Drawing.SystemColors.Control;
            this.A_Back.Location = new System.Drawing.Point(12, 540);
            this.A_Back.Name = "A_Back";
            this.A_Back.Size = new System.Drawing.Size(140, 68);
            this.A_Back.TabIndex = 18;
            this.A_Back.Text = "Back";
            this.A_Back.UseVisualStyleBackColor = false;
            this.A_Back.Click += new System.EventHandler(this.A_Back_Click);
            // 
            // Is_Candidate
            // 
            this.Is_Candidate.AutoSize = true;
            this.Is_Candidate.BackColor = System.Drawing.Color.Transparent;
            this.Is_Candidate.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Is_Candidate.Location = new System.Drawing.Point(376, 266);
            this.Is_Candidate.Name = "Is_Candidate";
            this.Is_Candidate.Size = new System.Drawing.Size(116, 26);
            this.Is_Candidate.TabIndex = 19;
            this.Is_Candidate.Text = "Is Candidate";
            // 
            // Is_C_Input
            // 
            this.Is_C_Input.BackColor = System.Drawing.Color.White;
            this.Is_C_Input.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Is_C_Input.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Is_C_Input.FormattingEnabled = true;
            this.Is_C_Input.Location = new System.Drawing.Point(522, 268);
            this.Is_C_Input.Name = "Is_C_Input";
            this.Is_C_Input.Size = new System.Drawing.Size(185, 27);
            this.Is_C_Input.TabIndex = 20;
            this.Is_C_Input.SelectedIndexChanged += new System.EventHandler(this.Is_C_Input_SelectedIndexChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 21;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Invalid_App_Lable
            // 
            this.Invalid_App_Lable.AutoSize = true;
            this.Invalid_App_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Invalid_App_Lable.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Invalid_App_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Invalid_App_Lable.Location = new System.Drawing.Point(165, 429);
            this.Invalid_App_Lable.Name = "Invalid_App_Lable";
            this.Invalid_App_Lable.Size = new System.Drawing.Size(379, 23);
            this.Invalid_App_Lable.TabIndex = 22;
            this.Invalid_App_Lable.Text = "Please Make Sure All fields Are Correctly Written";
            // 
            // AddApprentice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.Invalid_App_Lable);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Is_C_Input);
            this.Controls.Add(this.Is_Candidate);
            this.Controls.Add(this.A_Back);
            this.Controls.Add(this.A_FormatText);
            this.Controls.Add(this.A_AddNew);
            this.Controls.Add(this.A_PhoneNumInput);
            this.Controls.Add(this.A_EmailInput);
            this.Controls.Add(this.A_AddressInput);
            this.Controls.Add(this.A_AgeInput);
            this.Controls.Add(this.A_LnameInput);
            this.Controls.Add(this.A_FnameInput);
            this.Controls.Add(this.A_IDInput);
            this.Controls.Add(this.A_Status);
            this.Controls.Add(this.A_PhoneNum);
            this.Controls.Add(this.A_Email);
            this.Controls.Add(this.A_Address);
            this.Controls.Add(this.A_Age);
            this.Controls.Add(this.A_LastName);
            this.Controls.Add(this.A_FirstName);
            this.Controls.Add(this.A_ID);
            this.Controls.Add(this.A_StatusEnumInput);
            this.Name = "AddApprentice";
            this.Text = "AddApprentice";
            this.Load += new System.EventHandler(this.AddApprentice_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox A_StatusEnumInput;
        private System.Windows.Forms.Label A_ID;
        private System.Windows.Forms.Label A_FirstName;
        private System.Windows.Forms.Label A_LastName;
        private System.Windows.Forms.Label A_Age;
        private System.Windows.Forms.Label A_Address;
        private System.Windows.Forms.Label A_Email;
        private System.Windows.Forms.Label A_PhoneNum;
        private System.Windows.Forms.Label A_Status;
        private System.Windows.Forms.TextBox A_IDInput;
        private System.Windows.Forms.TextBox A_FnameInput;
        private System.Windows.Forms.TextBox A_LnameInput;
        private System.Windows.Forms.TextBox A_AgeInput;
        private System.Windows.Forms.TextBox A_AddressInput;
        private System.Windows.Forms.TextBox A_EmailInput;
        private System.Windows.Forms.TextBox A_PhoneNumInput;
        private System.Windows.Forms.Button A_AddNew;
        private System.Windows.Forms.Label A_FormatText;
        private System.Windows.Forms.Button A_Back;
        private System.Windows.Forms.Label Is_Candidate;
        private System.Windows.Forms.ComboBox Is_C_Input;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Invalid_App_Lable;
    }
}

