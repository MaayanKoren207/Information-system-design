﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CYCLE
{
    public enum ApprenticeStatus
    {
        [Description("Participates in current class")] ParticipatesInCurrentClass,
        [Description("Does not participate in current class")] DoesNotParticipateInCurrentClass,
        [Description("Wating for answer")] WatingForAnswer,
        Rejected
    }
}

