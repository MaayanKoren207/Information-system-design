﻿namespace CYCLE
{
    partial class AppHomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.View_App_Info_Butt = new System.Windows.Forms.Button();
            this.Add_Feedback_Butt = new System.Windows.Forms.Button();
            this.LogOut_Butt = new System.Windows.Forms.Button();
            this.ID_Lable = new System.Windows.Forms.Label();
            this.What_Lable = new System.Windows.Forms.Label();
            this.Welcome_Label = new System.Windows.Forms.Label();
            this.FullName_Text = new System.Windows.Forms.Label();
            this.FirstName_Lable = new System.Windows.Forms.Label();
            this.LastName_Lable = new System.Windows.Forms.Label();
            this.Age_Lable = new System.Windows.Forms.Label();
            this.Address_Lable = new System.Windows.Forms.Label();
            this.Email_Lable = new System.Windows.Forms.Label();
            this.PhoneNumber_Lable = new System.Windows.Forms.Label();
            this.ID_Text = new System.Windows.Forms.Label();
            this.FirstName_Text = new System.Windows.Forms.Label();
            this.LastName_Text = new System.Windows.Forms.Label();
            this.Age_Text = new System.Windows.Forms.Label();
            this.Address_Text = new System.Windows.Forms.Label();
            this.Email_Text = new System.Windows.Forms.Label();
            this.PhoneNumber_Text = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // View_App_Info_Butt
            // 
            this.View_App_Info_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.View_App_Info_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.View_App_Info_Butt.ForeColor = System.Drawing.Color.White;
            this.View_App_Info_Butt.Location = new System.Drawing.Point(449, 119);
            this.View_App_Info_Butt.Name = "View_App_Info_Butt";
            this.View_App_Info_Butt.Size = new System.Drawing.Size(155, 96);
            this.View_App_Info_Butt.TabIndex = 0;
            this.View_App_Info_Butt.Text = "View Personal Information";
            this.View_App_Info_Butt.UseVisualStyleBackColor = false;
            this.View_App_Info_Butt.Click += new System.EventHandler(this.View_App_Info_Butt_Click);
            // 
            // Add_Feedback_Butt
            // 
            this.Add_Feedback_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Add_Feedback_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Add_Feedback_Butt.ForeColor = System.Drawing.Color.White;
            this.Add_Feedback_Butt.Location = new System.Drawing.Point(57, 218);
            this.Add_Feedback_Butt.Name = "Add_Feedback_Butt";
            this.Add_Feedback_Butt.Size = new System.Drawing.Size(211, 96);
            this.Add_Feedback_Butt.TabIndex = 1;
            this.Add_Feedback_Butt.Text = "Add Lecture Feedback ";
            this.Add_Feedback_Butt.UseVisualStyleBackColor = false;
            this.Add_Feedback_Butt.Click += new System.EventHandler(this.Add_Feedback_Butt_Click);
            // 
            // LogOut_Butt
            // 
            this.LogOut_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.LogOut_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.LogOut_Butt.ForeColor = System.Drawing.Color.White;
            this.LogOut_Butt.Location = new System.Drawing.Point(12, 501);
            this.LogOut_Butt.Name = "LogOut_Butt";
            this.LogOut_Butt.Size = new System.Drawing.Size(211, 98);
            this.LogOut_Butt.TabIndex = 2;
            this.LogOut_Butt.Text = "Log Out";
            this.LogOut_Butt.UseVisualStyleBackColor = false;
            this.LogOut_Butt.Click += new System.EventHandler(this.LogOut_Butt_Click);
            // 
            // ID_Lable
            // 
            this.ID_Lable.AutoSize = true;
            this.ID_Lable.BackColor = System.Drawing.Color.Transparent;
            this.ID_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.ID_Lable.Location = new System.Drawing.Point(411, 235);
            this.ID_Lable.Name = "ID_Lable";
            this.ID_Lable.Size = new System.Drawing.Size(36, 26);
            this.ID_Lable.TabIndex = 3;
            this.ID_Lable.Text = "ID:";
            // 
            // What_Lable
            // 
            this.What_Lable.AutoSize = true;
            this.What_Lable.BackColor = System.Drawing.Color.Transparent;
            this.What_Lable.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.What_Lable.ForeColor = System.Drawing.Color.Navy;
            this.What_Lable.Location = new System.Drawing.Point(61, 89);
            this.What_Lable.Name = "What_Lable";
            this.What_Lable.Size = new System.Drawing.Size(322, 29);
            this.What_Lable.TabIndex = 4;
            this.What_Lable.Text = "What Would you like to do?";
            this.What_Lable.Click += new System.EventHandler(this.What_Lable_Click);
            // 
            // Welcome_Label
            // 
            this.Welcome_Label.AutoSize = true;
            this.Welcome_Label.BackColor = System.Drawing.Color.Transparent;
            this.Welcome_Label.Font = new System.Drawing.Font("Calibri", 36F);
            this.Welcome_Label.ForeColor = System.Drawing.Color.Navy;
            this.Welcome_Label.Location = new System.Drawing.Point(47, 30);
            this.Welcome_Label.Name = "Welcome_Label";
            this.Welcome_Label.Size = new System.Drawing.Size(208, 59);
            this.Welcome_Label.TabIndex = 5;
            this.Welcome_Label.Text = "Welcome";
            this.Welcome_Label.Click += new System.EventHandler(this.Welcome_Label_Click);
            // 
            // FullName_Text
            // 
            this.FullName_Text.AutoSize = true;
            this.FullName_Text.BackColor = System.Drawing.Color.Transparent;
            this.FullName_Text.Font = new System.Drawing.Font("Calibri", 36F);
            this.FullName_Text.ForeColor = System.Drawing.Color.Navy;
            this.FullName_Text.Location = new System.Drawing.Point(254, 30);
            this.FullName_Text.Name = "FullName_Text";
            this.FullName_Text.Size = new System.Drawing.Size(221, 59);
            this.FullName_Text.TabIndex = 6;
            this.FullName_Text.Text = "Full Name";
            this.FullName_Text.Click += new System.EventHandler(this.FullName_Text_Click);
            // 
            // FirstName_Lable
            // 
            this.FirstName_Lable.AutoSize = true;
            this.FirstName_Lable.BackColor = System.Drawing.Color.Transparent;
            this.FirstName_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.FirstName_Lable.Location = new System.Drawing.Point(411, 270);
            this.FirstName_Lable.Name = "FirstName_Lable";
            this.FirstName_Lable.Size = new System.Drawing.Size(111, 26);
            this.FirstName_Lable.TabIndex = 7;
            this.FirstName_Lable.Text = "First Name:";
            // 
            // LastName_Lable
            // 
            this.LastName_Lable.AutoSize = true;
            this.LastName_Lable.BackColor = System.Drawing.Color.Transparent;
            this.LastName_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.LastName_Lable.Location = new System.Drawing.Point(411, 300);
            this.LastName_Lable.Name = "LastName_Lable";
            this.LastName_Lable.Size = new System.Drawing.Size(108, 26);
            this.LastName_Lable.TabIndex = 8;
            this.LastName_Lable.Text = "Last Name:";
            // 
            // Age_Lable
            // 
            this.Age_Lable.AutoSize = true;
            this.Age_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Age_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Age_Lable.Location = new System.Drawing.Point(411, 334);
            this.Age_Lable.Name = "Age_Lable";
            this.Age_Lable.Size = new System.Drawing.Size(50, 26);
            this.Age_Lable.TabIndex = 9;
            this.Age_Lable.Text = "Age:";
            // 
            // Address_Lable
            // 
            this.Address_Lable.AutoSize = true;
            this.Address_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Address_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Address_Lable.Location = new System.Drawing.Point(411, 367);
            this.Address_Lable.Name = "Address_Lable";
            this.Address_Lable.Size = new System.Drawing.Size(85, 26);
            this.Address_Lable.TabIndex = 10;
            this.Address_Lable.Text = "Address:";
            this.Address_Lable.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Address_Lable.Click += new System.EventHandler(this.Address_Lable_Click);
            // 
            // Email_Lable
            // 
            this.Email_Lable.AutoSize = true;
            this.Email_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Email_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Email_Lable.Location = new System.Drawing.Point(410, 401);
            this.Email_Lable.Name = "Email_Lable";
            this.Email_Lable.Size = new System.Drawing.Size(65, 26);
            this.Email_Lable.TabIndex = 11;
            this.Email_Lable.Text = "Email:";
            // 
            // PhoneNumber_Lable
            // 
            this.PhoneNumber_Lable.AutoSize = true;
            this.PhoneNumber_Lable.BackColor = System.Drawing.Color.Transparent;
            this.PhoneNumber_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.PhoneNumber_Lable.Location = new System.Drawing.Point(410, 439);
            this.PhoneNumber_Lable.Name = "PhoneNumber_Lable";
            this.PhoneNumber_Lable.Size = new System.Drawing.Size(147, 26);
            this.PhoneNumber_Lable.TabIndex = 12;
            this.PhoneNumber_Lable.Text = "Phone Number:";
            // 
            // ID_Text
            // 
            this.ID_Text.AutoSize = true;
            this.ID_Text.BackColor = System.Drawing.Color.Transparent;
            this.ID_Text.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.ID_Text.Location = new System.Drawing.Point(580, 235);
            this.ID_Text.Name = "ID_Text";
            this.ID_Text.Size = new System.Drawing.Size(30, 26);
            this.ID_Text.TabIndex = 13;
            this.ID_Text.Text = "ID";
            // 
            // FirstName_Text
            // 
            this.FirstName_Text.AutoSize = true;
            this.FirstName_Text.BackColor = System.Drawing.Color.Transparent;
            this.FirstName_Text.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.FirstName_Text.Location = new System.Drawing.Point(580, 270);
            this.FirstName_Text.Name = "FirstName_Text";
            this.FirstName_Text.Size = new System.Drawing.Size(100, 26);
            this.FirstName_Text.TabIndex = 14;
            this.FirstName_Text.Text = "FirstName";
            // 
            // LastName_Text
            // 
            this.LastName_Text.AutoSize = true;
            this.LastName_Text.BackColor = System.Drawing.Color.Transparent;
            this.LastName_Text.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.LastName_Text.Location = new System.Drawing.Point(578, 300);
            this.LastName_Text.Name = "LastName_Text";
            this.LastName_Text.Size = new System.Drawing.Size(97, 26);
            this.LastName_Text.TabIndex = 15;
            this.LastName_Text.Text = "LastName";
            // 
            // Age_Text
            // 
            this.Age_Text.AutoSize = true;
            this.Age_Text.BackColor = System.Drawing.Color.Transparent;
            this.Age_Text.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Age_Text.Location = new System.Drawing.Point(580, 334);
            this.Age_Text.Name = "Age_Text";
            this.Age_Text.Size = new System.Drawing.Size(44, 26);
            this.Age_Text.TabIndex = 16;
            this.Age_Text.Text = "Age";
            // 
            // Address_Text
            // 
            this.Address_Text.AutoSize = true;
            this.Address_Text.BackColor = System.Drawing.Color.Transparent;
            this.Address_Text.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Address_Text.Location = new System.Drawing.Point(580, 367);
            this.Address_Text.Name = "Address_Text";
            this.Address_Text.Size = new System.Drawing.Size(79, 26);
            this.Address_Text.TabIndex = 17;
            this.Address_Text.Text = "Address";
            // 
            // Email_Text
            // 
            this.Email_Text.AutoSize = true;
            this.Email_Text.BackColor = System.Drawing.Color.Transparent;
            this.Email_Text.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Email_Text.Location = new System.Drawing.Point(578, 401);
            this.Email_Text.Name = "Email_Text";
            this.Email_Text.Size = new System.Drawing.Size(59, 26);
            this.Email_Text.TabIndex = 18;
            this.Email_Text.Text = "Email";
            // 
            // PhoneNumber_Text
            // 
            this.PhoneNumber_Text.AutoSize = true;
            this.PhoneNumber_Text.BackColor = System.Drawing.Color.Transparent;
            this.PhoneNumber_Text.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.PhoneNumber_Text.Location = new System.Drawing.Point(580, 439);
            this.PhoneNumber_Text.Name = "PhoneNumber_Text";
            this.PhoneNumber_Text.Size = new System.Drawing.Size(136, 26);
            this.PhoneNumber_Text.TabIndex = 19;
            this.PhoneNumber_Text.Text = "PhoneNumber";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(625, 10);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 23;
            this.pictureBox2.TabStop = false;
            // 
            // AppHomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.PhoneNumber_Text);
            this.Controls.Add(this.Email_Text);
            this.Controls.Add(this.Address_Text);
            this.Controls.Add(this.Age_Text);
            this.Controls.Add(this.LastName_Text);
            this.Controls.Add(this.FirstName_Text);
            this.Controls.Add(this.ID_Text);
            this.Controls.Add(this.PhoneNumber_Lable);
            this.Controls.Add(this.Email_Lable);
            this.Controls.Add(this.Address_Lable);
            this.Controls.Add(this.Age_Lable);
            this.Controls.Add(this.LastName_Lable);
            this.Controls.Add(this.FirstName_Lable);
            this.Controls.Add(this.FullName_Text);
            this.Controls.Add(this.Welcome_Label);
            this.Controls.Add(this.What_Lable);
            this.Controls.Add(this.ID_Lable);
            this.Controls.Add(this.LogOut_Butt);
            this.Controls.Add(this.Add_Feedback_Butt);
            this.Controls.Add(this.View_App_Info_Butt);
            this.Name = "AppHomePage";
            this.Text = "AppHomePage";
            this.Load += new System.EventHandler(this.AppHomePage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button View_App_Info_Butt;
        private System.Windows.Forms.Button Add_Feedback_Butt;
        private System.Windows.Forms.Button LogOut_Butt;
        private System.Windows.Forms.Label ID_Lable;
        private System.Windows.Forms.Label What_Lable;
        private System.Windows.Forms.Label Welcome_Label;
        private System.Windows.Forms.Label FullName_Text;
        private System.Windows.Forms.Label FirstName_Lable;
        private System.Windows.Forms.Label LastName_Lable;
        private System.Windows.Forms.Label Age_Lable;
        private System.Windows.Forms.Label Address_Lable;
        private System.Windows.Forms.Label Email_Lable;
        private System.Windows.Forms.Label PhoneNumber_Lable;
        private System.Windows.Forms.Label ID_Text;
        private System.Windows.Forms.Label FirstName_Text;
        private System.Windows.Forms.Label LastName_Text;
        private System.Windows.Forms.Label Age_Text;
        private System.Windows.Forms.Label Address_Text;
        private System.Windows.Forms.Label Email_Text;
        private System.Windows.Forms.Label PhoneNumber_Text;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}