﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class ViewLectureFeedbacks : Form
    {
        private Lecture lecture;

        public ViewLectureFeedbacks()
        {
            InitializeComponent();
            Topic_Input.DataSource = Enum.GetValues(typeof(LectureTopic));
            Topic_Input.SelectedIndex = -1;

            Feedback_DataGrid.Hide();
            Invalid_Lecture_Lable.Hide();
        }

        public ViewLectureFeedbacks(Lecture l)
        {
            InitializeComponent();
            Topic_Input.DataSource = Enum.GetValues(typeof(LectureTopic));
            Topic_Input.SelectedIndex = -1;

            Feedback_DataGrid.Hide();
            Invalid_Lecture_Lable.Hide();

            this.lecture = l;
            StartTime_Input.Text = lecture.get_StartTime().ToString();
            Topic_Input.Text = lecture.get_Topic().ToString();

        }
        private void ViewLectureFeedbacks_Load(object sender, EventArgs e)
        {

        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            LectureManage ac = new LectureManage();
            ac.Show();
            this.Hide();
        }

        private void Feedback_DataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void View_Lecture_FeedbackList_Butt_Click(object sender, EventArgs e)
        {
            lecture = Program.seekLecture((DateTime.Parse(StartTime_Input.Text)), (LectureTopic)Enum.Parse(typeof(LectureTopic), Topic_Input.Text));

            if (lecture != null)
            {
                Feedback_DataGrid.Show();

                var feedbacks = lecture.Feedbacks;

                Feedback_DataGrid.Name = "Feedbacks List";
                Feedback_DataGrid.ColumnCount = 6;
                Feedback_DataGrid.Columns[0].Name = "Feedback Date";
                Feedback_DataGrid.Columns[1].Name = "Apprentice ID";
                Feedback_DataGrid.Columns[2].Name = "Apprentice First Name";
                Feedback_DataGrid.Columns[3].Name = "Apprentice Last Name";

                Feedback_DataGrid.Columns[4].Name = "Feedback Rate";
                Feedback_DataGrid.Columns[5].Name = "Feedback Content";
                
                foreach (var f in feedbacks)
                {
                    Feedback_DataGrid.Rows.Add(
                        f.get_FeedbackDate(),
                        f.Apprentice.getID(),
                        f.Apprentice.get_FirstName(),
                        f.Apprentice.get_LastName(),
                        f.get_Rate(),
                        f.get_FeedbackText());
                }
                 
            }
            else
            {
                Invalid_Lecture_Lable.Show();
            }





        }
    }
}
