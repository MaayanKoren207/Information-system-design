﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class SessionOptions : Form
    {
        public SessionOptions()
        {
            InitializeComponent();
        }

        private void SessionOptions_Load(object sender, EventArgs e)
        {

        }

        private void To_S_Add_Click(object sender, EventArgs e)
        {

            AddSession add_S = new AddSession();
            add_S.Show();
            this.Hide();

        }

        private void To_S_Update_Click(object sender, EventArgs e)
        {
            UpdateSession update_S = new UpdateSession();
            update_S.Show();
            this.Hide();

        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            HomePage s = new HomePage();
            s.Show();
            this.Hide();
        }
    }
}
