﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class LecturerCRUD : Form
    {
        public LecturerCRUD()
        {
            InitializeComponent();
        }

        private void To_Add_Lecturer_Click(object sender, EventArgs e)
        {
            AddLecturer add_L = new AddLecturer();
            add_L.Show();
            this.Hide();
        }

        private void To_UpOrDel_Lecturer_Click(object sender, EventArgs e)
        {
            UpdateLecturer update_L = new UpdateLecturer();
            update_L.Show();
            this.Hide();
        }

        private void LecturerCRUD_Load(object sender, EventArgs e)
        {

        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            HomePage hp = new HomePage();
            hp.Show();
            this.Hide();
        }
    }
}
