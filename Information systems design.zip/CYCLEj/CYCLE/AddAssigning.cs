﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class AddAssigning : Form
    {
        private Lecturer L_Exist;
        private Lecture Lecture_Exist;

        private Assigning A_Exist;

        public AddAssigning()
        {
            //L_ID_Input    //StartTime_Input    //Topic_Input //AssStatus_Input  
            //Ins_Lable   // Invalid_L_ID_Lable  //Valid_L_ID_Lable //Invalid_Lecture_Lable //Ass_Add_Success
            //Back_Butt  //Add_Ass_Butt  //Search_Lecture_Butt //NewLectureQ_Butt
            //L_ID_Lable // StartTime_Lable //Topic_Lable // Status_Lable //NewLectureQ_Label

            InitializeComponent();
            AssStatus_Input.DataSource = Enum.GetValues(typeof(AssigningStatus));
            Topic_Input.DataSource = Enum.GetValues(typeof(LectureTopic));
            Topic_Input.SelectedIndex = -1;

            Invalid_L_ID_Lable.Hide();
            Valid_L_ID_Lable.Hide();
            Invalid_Lecture_Lable.Hide();
            NewLectureQ_Label.Hide();

            StartTime_Lable.Hide();
            Topic_Lable.Hide();
            Status_Lable.Hide();

            StartTime_Input.Hide();
            Topic_Input.Hide();
            AssStatus_Input.Hide();

            Add_Ass_Butt.Hide();
            Search_Lecture_Butt.Hide();
            NewLectureQ_Butt.Hide();

            AlreadyExist.Hide();


        }

        private void Ins_Lable_Click(object sender, EventArgs e)
        {

        }

        private void Search_Butt_Click(object sender, EventArgs e)
        {
            if (L_ID_Input.Text != null)
            {
                L_Exist = Program.seekLecturer(L_ID_Input.Text);

                if (L_Exist != null)
                {
                    Ins_Lable.Hide();
                    Valid_L_ID_Lable.Show();
                    StartTime_Lable.Show();

                    Topic_Lable.Show();
                    StartTime_Input.Show();
                    Topic_Input.Show();

                    Search_Lecture_Butt.Show();
                }
                else
                {
                    Invalid_L_ID_Lable.Show();
                }
            }
            else
            {
                Invalid_L_ID_Lable.Show();
            }

        }

        private void Search_Lecture_Butt_Click(object sender, EventArgs e)
        {
            if (Topic_Input.SelectedIndex.Equals(-1))
            {
                Topic_Input.SelectedIndex = 0; // NLP is default
            }

            Lecture_Exist = Program.seekLecture((DateTime.Parse(StartTime_Input.Text)), (LectureTopic)Enum.Parse(typeof(LectureTopic), Topic_Input.Text));
            if (Lecture_Exist != null)
            {
                Valid_L_ID_Lable.Hide();
                Add_Ass_Butt.Show();
            }
            else
            {
                Invalid_Lecture_Lable.Show();
                NewLectureQ_Label.Show();
                NewLectureQ_Butt.Show();
            }


        }

        private void Add_Ass_Butt_Click(object sender, EventArgs e)
        {
            A_Exist = Program.seekAssigning(Lecture_Exist.get_StartTime(), Lecture_Exist.get_Topic(), L_Exist.get_ID());

            if (A_Exist == null) // Assigning is not exist already
            {
                AssStatus_Input.SelectedIndex = 3;
                Assigning a = new Assigning(Lecture_Exist, L_Exist, (AssigningStatus)Enum.Parse(typeof(AssigningStatus), AssStatus_Input.Text), true);
            }
            else
            {
                AlreadyExist.Show();
            }

        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            AssigningManage hp = new AssigningManage();
            hp.Show();
            this.Close();
        }

        private void AddAssigning_Load(object sender, EventArgs e)
        {

        }

        private void NewLectureQ_Butt_Click(object sender, EventArgs e)
        {
            AddLecture al = new AddLecture();
            al.Owner = this;
            al.Show();
            this.Close();
        }

        private void StartTime_Input_ValueChanged(object sender, EventArgs e)
        {

        }

    }
}