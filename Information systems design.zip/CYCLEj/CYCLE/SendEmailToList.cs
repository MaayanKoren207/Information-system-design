﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;

namespace CYCLE
{
    public partial class SendEmailToList : Form
    {
        List<string> participatesEmailList = new List<string>();

        public SendEmailToList()
        {
            InitializeComponent();
        }

        public SendEmailToList(string sub, string[] contArr)
        {
            InitializeComponent();
            
            List<Apprentice> A_list = Program.get_Apprentices_by_Status(ApprenticeStatus.ParticipatesInCurrentClass);
            List<Employee> E_list = Program.get_Employees_by_Status(Status.Active);
            List<Lecturer> L_list = Program.get_Lecturers_by_Status(Status.Active);


            foreach (Apprentice a in A_list)
            {
                string st = a.get_Email();
                participatesEmailList.Add(st);
            }

            foreach (Employee e in E_list)
            {
                string str = e.get_Email();
                participatesEmailList.Add(str);
            }

            foreach (Lecturer l in L_list)
            {
                string str = l.get_Email();
                participatesEmailList.Add(str);
            }

            Send_To.Text = "HarmanIsrael" + ", " + "ActiveEmployeesList" + ", " + "ActiveApprenticesList" + ", " + "ActiveLecturerList";

            Subject_Input.Text = sub;
            ContentInput.Lines = contArr;
        }

        private void SendEmailToList_Load(object sender, EventArgs e)
        {

        }

        private void Send_Click(object sender, EventArgs e)
        {
            try
            {
                //inputUsers
                string toEmail;
                string subject = Subject_Input.Text;
                string body = ContentInput.Text;

                // Set up the SMTP client
                SmtpClient CycleMail = new SmtpClient();
                CycleMail.Port = 587;
                CycleMail.Host = "smtp.gmail.com";
                CycleMail.EnableSsl = true;
                CycleMail.Timeout = 10000;
                CycleMail.DeliveryMethod = SmtpDeliveryMethod.Network;
                CycleMail.UseDefaultCredentials = false;
                CycleMail.Credentials = new NetworkCredential("groupcycle29@gmail.com", "yuaxacmcvdnnvved");

                // Create the messages
                foreach (string email in participatesEmailList)
                {
                    toEmail = email;
                    MailMessage message = new MailMessage("groupcycle29@gmail.com", toEmail, subject, body);
                    message.BodyEncoding = UTF8Encoding.UTF8;
                    message.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
                    CycleMail.Send(message);
                }

                // Show a success message
                MessageBox.Show("Email sent successfully!");
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            Form ownerForm = this.Owner;
            ownerForm.Show();
            this.Hide();
        }
    }
}
