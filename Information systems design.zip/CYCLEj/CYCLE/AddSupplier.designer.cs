﻿namespace CYCLE
{
    partial class AddSupplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.S_FormatText = new System.Windows.Forms.Label();
            this.S_IDInput = new System.Windows.Forms.TextBox();
            this.S_ID = new System.Windows.Forms.Label();
            this.S_FullName = new System.Windows.Forms.Label();
            this.S_FullnameInput = new System.Windows.Forms.TextBox();
            this.S_Address = new System.Windows.Forms.Label();
            this.S_AddressInput = new System.Windows.Forms.TextBox();
            this.S_Contact_Full_Name = new System.Windows.Forms.Label();
            this.S_Contact_Full_Name_Input = new System.Windows.Forms.TextBox();
            this.S_PhoneNum = new System.Windows.Forms.Label();
            this.S_PhoneNumInput = new System.Windows.Forms.TextBox();
            this.S_Email = new System.Windows.Forms.Label();
            this.S_EmailInput = new System.Windows.Forms.TextBox();
            this.S_Bank_Account_info = new System.Windows.Forms.Label();
            this.S_Bank_Account_infoInput = new System.Windows.Forms.TextBox();
            this.S_AddNew = new System.Windows.Forms.Button();
            this.S_Back = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ErrorMSG = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // S_FormatText
            // 
            this.S_FormatText.AutoSize = true;
            this.S_FormatText.BackColor = System.Drawing.Color.Transparent;
            this.S_FormatText.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.S_FormatText.ForeColor = System.Drawing.Color.Navy;
            this.S_FormatText.Location = new System.Drawing.Point(46, 80);
            this.S_FormatText.Name = "S_FormatText";
            this.S_FormatText.Size = new System.Drawing.Size(526, 33);
            this.S_FormatText.TabIndex = 20;
            this.S_FormatText.Text = "Please Insert Input Only In The Correct Format!";
            // 
            // S_IDInput
            // 
            this.S_IDInput.Location = new System.Drawing.Point(126, 173);
            this.S_IDInput.Multiline = true;
            this.S_IDInput.Name = "S_IDInput";
            this.S_IDInput.Size = new System.Drawing.Size(185, 25);
            this.S_IDInput.TabIndex = 21;
            // 
            // S_ID
            // 
            this.S_ID.AutoSize = true;
            this.S_ID.BackColor = System.Drawing.Color.Transparent;
            this.S_ID.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_ID.Location = new System.Drawing.Point(6, 172);
            this.S_ID.Name = "S_ID";
            this.S_ID.Size = new System.Drawing.Size(105, 26);
            this.S_ID.TabIndex = 22;
            this.S_ID.Text = "Supplier ID";
            // 
            // S_FullName
            // 
            this.S_FullName.AutoSize = true;
            this.S_FullName.BackColor = System.Drawing.Color.Transparent;
            this.S_FullName.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_FullName.Location = new System.Drawing.Point(7, 229);
            this.S_FullName.Name = "S_FullName";
            this.S_FullName.Size = new System.Drawing.Size(99, 26);
            this.S_FullName.TabIndex = 23;
            this.S_FullName.Text = "Full Name";
            // 
            // S_FullnameInput
            // 
            this.S_FullnameInput.Location = new System.Drawing.Point(126, 230);
            this.S_FullnameInput.Multiline = true;
            this.S_FullnameInput.Name = "S_FullnameInput";
            this.S_FullnameInput.Size = new System.Drawing.Size(185, 25);
            this.S_FullnameInput.TabIndex = 24;
            // 
            // S_Address
            // 
            this.S_Address.AutoSize = true;
            this.S_Address.BackColor = System.Drawing.Color.Transparent;
            this.S_Address.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_Address.Location = new System.Drawing.Point(7, 291);
            this.S_Address.Name = "S_Address";
            this.S_Address.Size = new System.Drawing.Size(79, 26);
            this.S_Address.TabIndex = 25;
            this.S_Address.Text = "Address";
            // 
            // S_AddressInput
            // 
            this.S_AddressInput.Location = new System.Drawing.Point(126, 289);
            this.S_AddressInput.Multiline = true;
            this.S_AddressInput.Name = "S_AddressInput";
            this.S_AddressInput.Size = new System.Drawing.Size(185, 25);
            this.S_AddressInput.TabIndex = 26;
            // 
            // S_Contact_Full_Name
            // 
            this.S_Contact_Full_Name.AutoSize = true;
            this.S_Contact_Full_Name.BackColor = System.Drawing.Color.Transparent;
            this.S_Contact_Full_Name.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_Contact_Full_Name.Location = new System.Drawing.Point(7, 342);
            this.S_Contact_Full_Name.Name = "S_Contact_Full_Name";
            this.S_Contact_Full_Name.Size = new System.Drawing.Size(114, 26);
            this.S_Contact_Full_Name.TabIndex = 27;
            this.S_Contact_Full_Name.Text = "Contact Full";
            // 
            // S_Contact_Full_Name_Input
            // 
            this.S_Contact_Full_Name_Input.Location = new System.Drawing.Point(127, 344);
            this.S_Contact_Full_Name_Input.Multiline = true;
            this.S_Contact_Full_Name_Input.Name = "S_Contact_Full_Name_Input";
            this.S_Contact_Full_Name_Input.Size = new System.Drawing.Size(185, 25);
            this.S_Contact_Full_Name_Input.TabIndex = 28;
            // 
            // S_PhoneNum
            // 
            this.S_PhoneNum.AutoSize = true;
            this.S_PhoneNum.BackColor = System.Drawing.Color.Transparent;
            this.S_PhoneNum.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_PhoneNum.Location = new System.Drawing.Point(358, 165);
            this.S_PhoneNum.Name = "S_PhoneNum";
            this.S_PhoneNum.Size = new System.Drawing.Size(137, 26);
            this.S_PhoneNum.TabIndex = 29;
            this.S_PhoneNum.Text = "Contact Phone";
            // 
            // S_PhoneNumInput
            // 
            this.S_PhoneNumInput.Location = new System.Drawing.Point(508, 172);
            this.S_PhoneNumInput.Multiline = true;
            this.S_PhoneNumInput.Name = "S_PhoneNumInput";
            this.S_PhoneNumInput.Size = new System.Drawing.Size(185, 25);
            this.S_PhoneNumInput.TabIndex = 30;
            // 
            // S_Email
            // 
            this.S_Email.AutoSize = true;
            this.S_Email.BackColor = System.Drawing.Color.Transparent;
            this.S_Email.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_Email.Location = new System.Drawing.Point(365, 231);
            this.S_Email.Name = "S_Email";
            this.S_Email.Size = new System.Drawing.Size(59, 26);
            this.S_Email.TabIndex = 31;
            this.S_Email.Text = "Email";
            // 
            // S_EmailInput
            // 
            this.S_EmailInput.Location = new System.Drawing.Point(508, 229);
            this.S_EmailInput.Multiline = true;
            this.S_EmailInput.Name = "S_EmailInput";
            this.S_EmailInput.Size = new System.Drawing.Size(185, 25);
            this.S_EmailInput.TabIndex = 32;
            // 
            // S_Bank_Account_info
            // 
            this.S_Bank_Account_info.AutoSize = true;
            this.S_Bank_Account_info.BackColor = System.Drawing.Color.Transparent;
            this.S_Bank_Account_info.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_Bank_Account_info.Location = new System.Drawing.Point(362, 286);
            this.S_Bank_Account_info.Name = "S_Bank_Account_info";
            this.S_Bank_Account_info.Size = new System.Drawing.Size(129, 26);
            this.S_Bank_Account_info.TabIndex = 33;
            this.S_Bank_Account_info.Text = "Bank Account";
            // 
            // S_Bank_Account_infoInput
            // 
            this.S_Bank_Account_infoInput.Location = new System.Drawing.Point(508, 287);
            this.S_Bank_Account_infoInput.Multiline = true;
            this.S_Bank_Account_infoInput.Name = "S_Bank_Account_infoInput";
            this.S_Bank_Account_infoInput.Size = new System.Drawing.Size(185, 25);
            this.S_Bank_Account_infoInput.TabIndex = 34;
            // 
            // S_AddNew
            // 
            this.S_AddNew.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.S_AddNew.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_AddNew.ForeColor = System.Drawing.Color.White;
            this.S_AddNew.Location = new System.Drawing.Point(582, 531);
            this.S_AddNew.Name = "S_AddNew";
            this.S_AddNew.Size = new System.Drawing.Size(140, 68);
            this.S_AddNew.TabIndex = 35;
            this.S_AddNew.Text = "Add Supplier";
            this.S_AddNew.UseVisualStyleBackColor = false;
            this.S_AddNew.Click += new System.EventHandler(this.S_AddNew_Click_1);
            // 
            // S_Back
            // 
            this.S_Back.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.S_Back.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_Back.ForeColor = System.Drawing.Color.White;
            this.S_Back.Location = new System.Drawing.Point(8, 531);
            this.S_Back.Name = "S_Back";
            this.S_Back.Size = new System.Drawing.Size(140, 68);
            this.S_Back.TabIndex = 36;
            this.S_Back.Text = "Back";
            this.S_Back.UseVisualStyleBackColor = false;
            this.S_Back.Click += new System.EventHandler(this.S_Back_Click_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 42;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.label1.Location = new System.Drawing.Point(3, 364);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 26);
            this.label1.TabIndex = 43;
            this.label1.Text = " Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.label2.Location = new System.Drawing.Point(359, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 26);
            this.label2.TabIndex = 44;
            this.label2.Text = "Number";
            // 
            // ErrorMSG
            // 
            this.ErrorMSG.AutoSize = true;
            this.ErrorMSG.BackColor = System.Drawing.Color.Transparent;
            this.ErrorMSG.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.ErrorMSG.ForeColor = System.Drawing.Color.Navy;
            this.ErrorMSG.Location = new System.Drawing.Point(260, 410);
            this.ErrorMSG.Name = "ErrorMSG";
            this.ErrorMSG.Size = new System.Drawing.Size(221, 26);
            this.ErrorMSG.TabIndex = 45;
            this.ErrorMSG.Text = "Please Insert valid input!";
            // 
            // AddSupplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.ErrorMSG);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.S_Back);
            this.Controls.Add(this.S_AddNew);
            this.Controls.Add(this.S_Bank_Account_infoInput);
            this.Controls.Add(this.S_Bank_Account_info);
            this.Controls.Add(this.S_EmailInput);
            this.Controls.Add(this.S_Email);
            this.Controls.Add(this.S_PhoneNumInput);
            this.Controls.Add(this.S_PhoneNum);
            this.Controls.Add(this.S_Contact_Full_Name_Input);
            this.Controls.Add(this.S_Contact_Full_Name);
            this.Controls.Add(this.S_AddressInput);
            this.Controls.Add(this.S_Address);
            this.Controls.Add(this.S_FullnameInput);
            this.Controls.Add(this.S_FullName);
            this.Controls.Add(this.S_ID);
            this.Controls.Add(this.S_IDInput);
            this.Controls.Add(this.S_FormatText);
            this.Name = "AddSupplier";
            this.Text = "AddSupplier";
            this.Load += new System.EventHandler(this.AddSupplier_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label S_FormatText;
        private System.Windows.Forms.TextBox S_IDInput;
        private System.Windows.Forms.Label S_ID;
        private System.Windows.Forms.Label S_FullName;
        private System.Windows.Forms.TextBox S_FullnameInput;
        private System.Windows.Forms.Label S_Address;
        private System.Windows.Forms.TextBox S_AddressInput;
        private System.Windows.Forms.Label S_Contact_Full_Name;
        private System.Windows.Forms.TextBox S_Contact_Full_Name_Input;
        private System.Windows.Forms.Label S_PhoneNum;
        private System.Windows.Forms.TextBox S_PhoneNumInput;
        private System.Windows.Forms.Label S_Email;
        private System.Windows.Forms.TextBox S_EmailInput;
        private System.Windows.Forms.Label S_Bank_Account_info;
        private System.Windows.Forms.TextBox S_Bank_Account_infoInput;
        private System.Windows.Forms.Button S_AddNew;
        private System.Windows.Forms.Button S_Back;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label ErrorMSG;
    }
}