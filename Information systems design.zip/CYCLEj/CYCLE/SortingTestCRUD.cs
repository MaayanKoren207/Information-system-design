﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class SortingTestCRUD : Form
    {
        private Apprentice A_Exist;
        public string ID { get; set; }
        public static SortingTestCRUD CRUD;
        public SortingTestCRUD()
        {
            InitializeComponent();
            CRUD = this;
            ST_Add.Hide();
            ST_View.Hide();
            ST_Edit.Hide();
            
        }

        private void ID_Input_TextChanged(object sender, EventArgs e)
        {
            Warning.Hide();
            if (!Int32.TryParse(ID_Input.Text, out int Value))
            {
                Warning.Show();
                if (Warning.ForeColor == Color.Red)
                    Warning.ForeColor = Color.Gold;
                else Warning.ForeColor = Color.Red;
            }

            
            A_Exist = Program.seekAllApprentice(ID_Input.Text);
            if (A_Exist != null)//אם קיים חניך
                if (A_Exist.SortingTests != null && A_Exist.SortingTests.Any())//אם קיימים לו מיונים ולא ריקים
                {
                    ST_Add.Show();
                    ST_View.Show();
                    ST_Edit.Show();
                }
                else if (A_Exist.SortingTests != null && A_Exist.SortingTests.Any() == false)//קיים מיון אבל ריק
                    ST_Add.Show();
                else// לא קיים מיון
                    ST_Add.Show();
            ID = ID_Input.Text;
        }

        private void ST_View_Click(object sender, EventArgs e)
        {
            if (A_Exist != null)
            {
                ViewST view = new ViewST();
                view.Show();
                this.Hide();
            }
            else
            {
                ST_Add.Hide();
                ST_View.Hide();
                ST_Edit.Hide();
                Warning.Show();
            }
        }

        private void ST_Edit_Click(object sender, EventArgs e)
        {
            if (A_Exist != null)
            {
                EditST edit = new EditST();
                edit.Show();
                this.Hide();
            }
            else
            {
                ST_Add.Hide();
                ST_View.Hide();
                ST_Edit.Hide();
                Warning.Show();
            }
        }

        private void ST_Add_Click(object sender, EventArgs e)
        {
            if (A_Exist != null)
            {
                AddST add = new AddST();
                add.Show();
                this.Hide();
            }
            else
            {
                ST_Add.Hide();
                ST_View.Hide();
                ST_Edit.Hide();
                Warning.Show();
            }
        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            HomePage add = new HomePage();
            add.Show();
            this.Hide();
        }

        private void SortingTestCRUD_Load(object sender, EventArgs e)
        {

        }
    }
}
