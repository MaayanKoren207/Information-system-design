﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class EditST : Form
    {
        private List<DateTime> DT;
        public Apprentice Candidate;
        public string ID;
        public EditST()
        {
            InitializeComponent();
            DateDisplay.ValueMember = "DateTimeValue";
            DateDisplay.DisplayMember = "DisplayMember";
            for (int i = 1; i < 6; i++)
            {
                Label label = (Label)Controls["Cat" + i.ToString()];
                ComboBox rate = (ComboBox)this.Controls["CatRate" + i.ToString()];
                label.Visible = false;
                rate.Visible = false;
                rate.SelectedIndex = -1;
            }
            AverageScore.Hide();

            SortingTestCRUD CRUD = SortingTestCRUD.CRUD;
            ID = CRUD.ID;
            CandidateID.Text = "ID: " + ID;
            Candidate = Program.seekAllApprentice(ID);
            DT = new List<DateTime>();
            foreach (SortingTest st in Candidate.SortingTests)
            {
                if (!DT.Contains(st.get_TestDate()))
                    DT.Add(st.get_TestDate());
            }
            DateDisplay.DataSource = DT.Select(dt => new { DisplayMember = dt.ToString("dd/MM/yyyy HH:mm:ss"), DateTimeValue = dt }).ToList();
        }
        private void DateDisplay_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 1; i < 6; i++)
            {
                Label label = (Label)Controls["Cat" + i.ToString()];
                ComboBox rate = (ComboBox)this.Controls["CatRate" + i.ToString()];
                label.Visible = false;
                rate.Visible = false;
            }
            AverageScore.Hide();
            double count = 0;
            double sum = 0;
            int counter = 0;
            String Date = DateTime.Now.ToString(DateDisplay.Text);
            foreach (CandidateRateByCat cat in Program.CandidateRateByCats)
            {
                if (cat.sortingTest.get_TestDate().ToString() == Date && cat.SortingTest.Apprentice.getID() == Candidate.getID())
                {
                    counter++;
                    count++;
                    sum = sum + cat.get_RateInCat();
                    Label label = (Label)Controls["Cat" + counter.ToString()];
                    ComboBox rate = (ComboBox)this.Controls["CatRate" + counter.ToString()];
                    label.Visible = true;
                    rate.Visible = true;
                    label.Text = cat.categoryOfCandidate.get_CategoryOfCandidate().ToString();
                    rate.SelectedIndex = int.Parse(cat.get_RateInCat().ToString()) - 1;

                }
            }
            AverageScore.Show();
            AverageScore.Text = "Average Rate:  " + (sum/count).ToString();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            SortingTestCRUD stc = new SortingTestCRUD();
            stc.Show();
            this.Close();
        }


        private void UpdateButton_Click(object sender, EventArgs e)
        {
            double count = 0;
            double sum = 0;
            int counter = 0;
            String Date = DateTime.Now.ToString(DateDisplay.Text);
            foreach (CandidateRateByCat category in Program.CandidateRateByCats)
            {
                if (category.sortingTest.get_TestDate().ToString() == Date && category.SortingTest.Apprentice.getID() == Candidate.getID())
                {
                    counter++;
                    count++;
                    ComboBox rate = (ComboBox)this.Controls["CatRate" + counter.ToString()];
                    category.set_RateInCat(Convert.ToDouble(rate.SelectedItem));
                    category.Update_CandidateRateByCat(true);
                    sum = sum + category.get_RateInCat();
                }

            }
            AverageScore.Text = "Average Rate:  " + (sum/count).ToString();
        }

        private void EditST_Load(object sender, EventArgs e)
        {

        }
    }
}

