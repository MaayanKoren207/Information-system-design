﻿namespace CYCLE
{
    partial class AddProducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.P_ID = new System.Windows.Forms.Label();
            this.P_Name = new System.Windows.Forms.Label();
            this.Num_Units = new System.Windows.Forms.Label();
            this.P_price = new System.Windows.Forms.Label();
            this.P_Category = new System.Windows.Forms.Label();
            this.P_IDInput = new System.Windows.Forms.TextBox();
            this.P_NameInput = new System.Windows.Forms.TextBox();
            this.P_NumInput = new System.Windows.Forms.TextBox();
            this.P_PriceInput = new System.Windows.Forms.TextBox();
            this.P_Back = new System.Windows.Forms.Button();
            this.P_AddNew = new System.Windows.Forms.Button();
            this.P_CategoryInput = new System.Windows.Forms.ComboBox();
            this.S_ID = new System.Windows.Forms.Label();
            this.S_IDInputP = new System.Windows.Forms.TextBox();
            this.P_FormatText = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ErrorMSG = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // P_ID
            // 
            this.P_ID.AutoSize = true;
            this.P_ID.BackColor = System.Drawing.Color.Transparent;
            this.P_ID.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.P_ID.Location = new System.Drawing.Point(10, 234);
            this.P_ID.Name = "P_ID";
            this.P_ID.Size = new System.Drawing.Size(102, 26);
            this.P_ID.TabIndex = 0;
            this.P_ID.Text = "ID Product";
            // 
            // P_Name
            // 
            this.P_Name.AutoSize = true;
            this.P_Name.BackColor = System.Drawing.Color.Transparent;
            this.P_Name.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.P_Name.Location = new System.Drawing.Point(12, 284);
            this.P_Name.Name = "P_Name";
            this.P_Name.Size = new System.Drawing.Size(63, 26);
            this.P_Name.TabIndex = 1;
            this.P_Name.Text = "Name";
            // 
            // Num_Units
            // 
            this.Num_Units.AutoSize = true;
            this.Num_Units.BackColor = System.Drawing.Color.Transparent;
            this.Num_Units.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Num_Units.Location = new System.Drawing.Point(362, 170);
            this.Num_Units.Name = "Num_Units";
            this.Num_Units.Size = new System.Drawing.Size(156, 26);
            this.Num_Units.TabIndex = 2;
            this.Num_Units.Text = "Current Number ";
            // 
            // P_price
            // 
            this.P_price.AutoSize = true;
            this.P_price.BackColor = System.Drawing.Color.Transparent;
            this.P_price.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.P_price.Location = new System.Drawing.Point(362, 234);
            this.P_price.Name = "P_price";
            this.P_price.Size = new System.Drawing.Size(128, 26);
            this.P_price.TabIndex = 3;
            this.P_price.Text = "Price Per Unit";
            // 
            // P_Category
            // 
            this.P_Category.AutoSize = true;
            this.P_Category.BackColor = System.Drawing.Color.Transparent;
            this.P_Category.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.P_Category.Location = new System.Drawing.Point(358, 284);
            this.P_Category.Name = "P_Category";
            this.P_Category.Size = new System.Drawing.Size(160, 26);
            this.P_Category.TabIndex = 4;
            this.P_Category.Text = "Product Category";
            // 
            // P_IDInput
            // 
            this.P_IDInput.Location = new System.Drawing.Point(146, 233);
            this.P_IDInput.Multiline = true;
            this.P_IDInput.Name = "P_IDInput";
            this.P_IDInput.Size = new System.Drawing.Size(185, 25);
            this.P_IDInput.TabIndex = 5;
            // 
            // P_NameInput
            // 
            this.P_NameInput.Location = new System.Drawing.Point(146, 284);
            this.P_NameInput.Multiline = true;
            this.P_NameInput.Name = "P_NameInput";
            this.P_NameInput.Size = new System.Drawing.Size(185, 25);
            this.P_NameInput.TabIndex = 6;
            // 
            // P_NumInput
            // 
            this.P_NumInput.Location = new System.Drawing.Point(524, 177);
            this.P_NumInput.Multiline = true;
            this.P_NumInput.Name = "P_NumInput";
            this.P_NumInput.Size = new System.Drawing.Size(185, 25);
            this.P_NumInput.TabIndex = 7;
            // 
            // P_PriceInput
            // 
            this.P_PriceInput.Location = new System.Drawing.Point(524, 233);
            this.P_PriceInput.Multiline = true;
            this.P_PriceInput.Name = "P_PriceInput";
            this.P_PriceInput.Size = new System.Drawing.Size(185, 25);
            this.P_PriceInput.TabIndex = 8;
            // 
            // P_Back
            // 
            this.P_Back.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.P_Back.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.P_Back.ForeColor = System.Drawing.Color.White;
            this.P_Back.Location = new System.Drawing.Point(12, 531);
            this.P_Back.Name = "P_Back";
            this.P_Back.Size = new System.Drawing.Size(140, 68);
            this.P_Back.TabIndex = 10;
            this.P_Back.Text = "Back";
            this.P_Back.UseVisualStyleBackColor = false;
            this.P_Back.Click += new System.EventHandler(this.P_Back_Click_1);
            // 
            // P_AddNew
            // 
            this.P_AddNew.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.P_AddNew.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.P_AddNew.ForeColor = System.Drawing.Color.White;
            this.P_AddNew.Location = new System.Drawing.Point(586, 532);
            this.P_AddNew.Name = "P_AddNew";
            this.P_AddNew.Size = new System.Drawing.Size(140, 68);
            this.P_AddNew.TabIndex = 11;
            this.P_AddNew.Text = "Add Product";
            this.P_AddNew.UseVisualStyleBackColor = false;
            this.P_AddNew.Click += new System.EventHandler(this.P_AddNew_Click);
            // 
            // P_CategoryInput
            // 
            this.P_CategoryInput.BackColor = System.Drawing.Color.White;
            this.P_CategoryInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.P_CategoryInput.Font = new System.Drawing.Font("Calibri", 12F);
            this.P_CategoryInput.FormattingEnabled = true;
            this.P_CategoryInput.Location = new System.Drawing.Point(524, 284);
            this.P_CategoryInput.Name = "P_CategoryInput";
            this.P_CategoryInput.Size = new System.Drawing.Size(185, 27);
            this.P_CategoryInput.TabIndex = 19;
            // 
            // S_ID
            // 
            this.S_ID.AutoSize = true;
            this.S_ID.BackColor = System.Drawing.Color.Transparent;
            this.S_ID.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_ID.Location = new System.Drawing.Point(7, 176);
            this.S_ID.Name = "S_ID";
            this.S_ID.Size = new System.Drawing.Size(105, 26);
            this.S_ID.TabIndex = 20;
            this.S_ID.Text = "Supplier ID";
            // 
            // S_IDInputP
            // 
            this.S_IDInputP.Location = new System.Drawing.Point(146, 176);
            this.S_IDInputP.Multiline = true;
            this.S_IDInputP.Name = "S_IDInputP";
            this.S_IDInputP.Size = new System.Drawing.Size(185, 25);
            this.S_IDInputP.TabIndex = 21;
            // 
            // P_FormatText
            // 
            this.P_FormatText.AutoSize = true;
            this.P_FormatText.BackColor = System.Drawing.Color.Transparent;
            this.P_FormatText.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.P_FormatText.ForeColor = System.Drawing.Color.Navy;
            this.P_FormatText.Location = new System.Drawing.Point(45, 80);
            this.P_FormatText.Name = "P_FormatText";
            this.P_FormatText.Size = new System.Drawing.Size(526, 33);
            this.P_FormatText.TabIndex = 22;
            this.P_FormatText.Text = "Please Insert Input Only In The Correct Format!";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 41;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.label1.Location = new System.Drawing.Point(362, 196);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 26);
            this.label1.TabIndex = 42;
            this.label1.Text = "of Units";
            // 
            // ErrorMSG
            // 
            this.ErrorMSG.AutoSize = true;
            this.ErrorMSG.BackColor = System.Drawing.Color.Transparent;
            this.ErrorMSG.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.ErrorMSG.ForeColor = System.Drawing.Color.Navy;
            this.ErrorMSG.Location = new System.Drawing.Point(297, 369);
            this.ErrorMSG.Name = "ErrorMSG";
            this.ErrorMSG.Size = new System.Drawing.Size(221, 26);
            this.ErrorMSG.TabIndex = 43;
            this.ErrorMSG.Text = "Please Insert valid input!";
            // 
            // AddProducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.ErrorMSG);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.P_FormatText);
            this.Controls.Add(this.S_IDInputP);
            this.Controls.Add(this.S_ID);
            this.Controls.Add(this.P_CategoryInput);
            this.Controls.Add(this.P_AddNew);
            this.Controls.Add(this.P_Back);
            this.Controls.Add(this.P_PriceInput);
            this.Controls.Add(this.P_NumInput);
            this.Controls.Add(this.P_NameInput);
            this.Controls.Add(this.P_IDInput);
            this.Controls.Add(this.P_Category);
            this.Controls.Add(this.P_price);
            this.Controls.Add(this.Num_Units);
            this.Controls.Add(this.P_Name);
            this.Controls.Add(this.P_ID);
            this.Name = "AddProducts";
            this.Text = "AddProducts";
            this.Load += new System.EventHandler(this.AddProducts_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label P_ID;
        private System.Windows.Forms.Label P_Name;
        private System.Windows.Forms.Label Num_Units;
        private System.Windows.Forms.Label P_price;
        private System.Windows.Forms.Label P_Category;
        private System.Windows.Forms.TextBox P_IDInput;
        private System.Windows.Forms.TextBox P_NameInput;
        private System.Windows.Forms.TextBox P_NumInput;
        private System.Windows.Forms.TextBox P_PriceInput;
        private System.Windows.Forms.Button P_Back;
        private System.Windows.Forms.Button P_AddNew;
        private System.Windows.Forms.ComboBox P_CategoryInput;
        private System.Windows.Forms.Label S_ID;
        private System.Windows.Forms.TextBox S_IDInputP;
        private System.Windows.Forms.Label P_FormatText;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label ErrorMSG;
    }
}