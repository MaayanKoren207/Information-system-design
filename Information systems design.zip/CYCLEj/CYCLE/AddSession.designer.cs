﻿namespace CYCLE
{
    partial class AddSession
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SA_FormatText = new System.Windows.Forms.Label();
            this.SA_SessionDate = new System.Windows.Forms.Label();
            this.dateTimePickerSessionA = new System.Windows.Forms.DateTimePicker();
            this.SA_Duration = new System.Windows.Forms.Label();
            this.SA_DurationInput = new System.Windows.Forms.TextBox();
            this.TopicA = new System.Windows.Forms.Label();
            this.SA_TopicInput = new System.Windows.Forms.TextBox();
            this.SessionNumberInput = new System.Windows.Forms.TextBox();
            this.SA_Location = new System.Windows.Forms.Label();
            this.SA_LocationEnumInput = new System.Windows.Forms.ComboBox();
            this.S_AddNew = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.SA_Number = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Invalid_App_Lable = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // SA_FormatText
            // 
            this.SA_FormatText.AutoSize = true;
            this.SA_FormatText.BackColor = System.Drawing.Color.Transparent;
            this.SA_FormatText.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.SA_FormatText.ForeColor = System.Drawing.Color.Navy;
            this.SA_FormatText.Location = new System.Drawing.Point(11, 97);
            this.SA_FormatText.Name = "SA_FormatText";
            this.SA_FormatText.Size = new System.Drawing.Size(526, 33);
            this.SA_FormatText.TabIndex = 19;
            this.SA_FormatText.Text = "Please Insert Input Only In The Correct Format!";
            // 
            // SA_SessionDate
            // 
            this.SA_SessionDate.AutoSize = true;
            this.SA_SessionDate.BackColor = System.Drawing.Color.Transparent;
            this.SA_SessionDate.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SA_SessionDate.ForeColor = System.Drawing.Color.Black;
            this.SA_SessionDate.Location = new System.Drawing.Point(12, 202);
            this.SA_SessionDate.Name = "SA_SessionDate";
            this.SA_SessionDate.Size = new System.Drawing.Size(120, 26);
            this.SA_SessionDate.TabIndex = 46;
            this.SA_SessionDate.Text = "Session Date";
            // 
            // dateTimePickerSessionA
            // 
            this.dateTimePickerSessionA.CalendarFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.dateTimePickerSessionA.CustomFormat = "dd/MM/yyyy HH:mm:ss";
            this.dateTimePickerSessionA.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerSessionA.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerSessionA.Location = new System.Drawing.Point(143, 202);
            this.dateTimePickerSessionA.Name = "dateTimePickerSessionA";
            this.dateTimePickerSessionA.Size = new System.Drawing.Size(187, 27);
            this.dateTimePickerSessionA.TabIndex = 58;
            // 
            // SA_Duration
            // 
            this.SA_Duration.AutoSize = true;
            this.SA_Duration.BackColor = System.Drawing.Color.Transparent;
            this.SA_Duration.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SA_Duration.ForeColor = System.Drawing.Color.Black;
            this.SA_Duration.Location = new System.Drawing.Point(16, 263);
            this.SA_Duration.Name = "SA_Duration";
            this.SA_Duration.Size = new System.Drawing.Size(87, 26);
            this.SA_Duration.TabIndex = 59;
            this.SA_Duration.Text = "Duration";
            // 
            // SA_DurationInput
            // 
            this.SA_DurationInput.Location = new System.Drawing.Point(142, 263);
            this.SA_DurationInput.Multiline = true;
            this.SA_DurationInput.Name = "SA_DurationInput";
            this.SA_DurationInput.Size = new System.Drawing.Size(185, 25);
            this.SA_DurationInput.TabIndex = 60;
            this.SA_DurationInput.TextChanged += new System.EventHandler(this.SA_DurationInput_TextChanged);
            // 
            // TopicA
            // 
            this.TopicA.AutoSize = true;
            this.TopicA.BackColor = System.Drawing.Color.Transparent;
            this.TopicA.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TopicA.ForeColor = System.Drawing.Color.Black;
            this.TopicA.Location = new System.Drawing.Point(16, 323);
            this.TopicA.Name = "TopicA";
            this.TopicA.Size = new System.Drawing.Size(56, 26);
            this.TopicA.TabIndex = 61;
            this.TopicA.Text = "Topic";
            // 
            // SA_TopicInput
            // 
            this.SA_TopicInput.Location = new System.Drawing.Point(142, 323);
            this.SA_TopicInput.Multiline = true;
            this.SA_TopicInput.Name = "SA_TopicInput";
            this.SA_TopicInput.Size = new System.Drawing.Size(185, 25);
            this.SA_TopicInput.TabIndex = 62;
            // 
            // SessionNumberInput
            // 
            this.SessionNumberInput.Location = new System.Drawing.Point(526, 202);
            this.SessionNumberInput.Multiline = true;
            this.SessionNumberInput.Name = "SessionNumberInput";
            this.SessionNumberInput.Size = new System.Drawing.Size(185, 25);
            this.SessionNumberInput.TabIndex = 64;
            // 
            // SA_Location
            // 
            this.SA_Location.AutoSize = true;
            this.SA_Location.BackColor = System.Drawing.Color.Transparent;
            this.SA_Location.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SA_Location.ForeColor = System.Drawing.Color.Black;
            this.SA_Location.Location = new System.Drawing.Point(362, 260);
            this.SA_Location.Name = "SA_Location";
            this.SA_Location.Size = new System.Drawing.Size(153, 26);
            this.SA_Location.TabIndex = 65;
            this.SA_Location.Text = "Session Location";
            // 
            // SA_LocationEnumInput
            // 
            this.SA_LocationEnumInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SA_LocationEnumInput.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.SA_LocationEnumInput.FormattingEnabled = true;
            this.SA_LocationEnumInput.Location = new System.Drawing.Point(526, 260);
            this.SA_LocationEnumInput.Name = "SA_LocationEnumInput";
            this.SA_LocationEnumInput.Size = new System.Drawing.Size(185, 27);
            this.SA_LocationEnumInput.TabIndex = 74;
            // 
            // S_AddNew
            // 
            this.S_AddNew.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.S_AddNew.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.S_AddNew.ForeColor = System.Drawing.Color.White;
            this.S_AddNew.Location = new System.Drawing.Point(571, 522);
            this.S_AddNew.Name = "S_AddNew";
            this.S_AddNew.Size = new System.Drawing.Size(140, 68);
            this.S_AddNew.TabIndex = 77;
            this.S_AddNew.Text = "Add Session";
            this.S_AddNew.UseVisualStyleBackColor = false;
            this.S_AddNew.Click += new System.EventHandler(this.S_AddNew_Click);
            // 
            // Back
            // 
            this.Back.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Back.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Back.ForeColor = System.Drawing.Color.White;
            this.Back.Location = new System.Drawing.Point(21, 522);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(140, 68);
            this.Back.TabIndex = 78;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = false;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // SA_Number
            // 
            this.SA_Number.AutoSize = true;
            this.SA_Number.BackColor = System.Drawing.Color.Transparent;
            this.SA_Number.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SA_Number.ForeColor = System.Drawing.Color.Black;
            this.SA_Number.Location = new System.Drawing.Point(362, 198);
            this.SA_Number.Name = "SA_Number";
            this.SA_Number.Size = new System.Drawing.Size(150, 26);
            this.SA_Number.TabIndex = 63;
            this.SA_Number.Text = "Session Number";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(612, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 80;
            this.pictureBox2.TabStop = false;
            // 
            // Invalid_App_Lable
            // 
            this.Invalid_App_Lable.AutoSize = true;
            this.Invalid_App_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Invalid_App_Lable.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Invalid_App_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Invalid_App_Lable.Location = new System.Drawing.Point(158, 374);
            this.Invalid_App_Lable.Name = "Invalid_App_Lable";
            this.Invalid_App_Lable.Size = new System.Drawing.Size(379, 23);
            this.Invalid_App_Lable.TabIndex = 81;
            this.Invalid_App_Lable.Text = "Please Make Sure All fields Are Correctly Written";
            // 
            // AddSession
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.Invalid_App_Lable);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.S_AddNew);
            this.Controls.Add(this.SA_LocationEnumInput);
            this.Controls.Add(this.SA_Location);
            this.Controls.Add(this.SessionNumberInput);
            this.Controls.Add(this.SA_Number);
            this.Controls.Add(this.SA_TopicInput);
            this.Controls.Add(this.TopicA);
            this.Controls.Add(this.SA_DurationInput);
            this.Controls.Add(this.SA_Duration);
            this.Controls.Add(this.dateTimePickerSessionA);
            this.Controls.Add(this.SA_SessionDate);
            this.Controls.Add(this.SA_FormatText);
            this.Name = "AddSession";
            this.Text = "AddSession";
            this.Load += new System.EventHandler(this.AddSession_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SA_FormatText;
        private System.Windows.Forms.Label SA_SessionDate;
        private System.Windows.Forms.DateTimePicker dateTimePickerSessionA;
        private System.Windows.Forms.Label SA_Duration;
        private System.Windows.Forms.TextBox SA_DurationInput;
        private System.Windows.Forms.Label TopicA;
        private System.Windows.Forms.TextBox SA_TopicInput;
        private System.Windows.Forms.TextBox SessionNumberInput;
        private System.Windows.Forms.Label SA_Location;
        private System.Windows.Forms.ComboBox SA_LocationEnumInput;
        private System.Windows.Forms.Button S_AddNew;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Label SA_Number;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Invalid_App_Lable;
    }
}