﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;

namespace CYCLE
{
    static class Program
    {
        public static System.Collections.Generic.List<Lecturer> Lecturers;
        public static System.Collections.Generic.List<Session> Sessions;
        public static System.Collections.Generic.List<Lecture> Lectures;
        public static System.Collections.Generic.List<Assigning> Assignings;

        public static System.Collections.Generic.List<Product> Products;
        public static System.Collections.Generic.List<Supplier> Suppliers;
        public static System.Collections.Generic.List<Order> Orders;

        public static System.Collections.Generic.List<Employee> Employees;

        public static System.Collections.Generic.List<Apprentice> Apprentices;
        public static System.Collections.Generic.List<SortingTest> SortingTests;
        public static System.Collections.Generic.List<CategoryOfCandidate> CategoryOfCandidates;
        public static System.Collections.Generic.List<CandidateRateByCat> CandidateRateByCats;

        public static System.Collections.Generic.List<Feedback> Feedbacks;

        [STAThread]

        public static Apprentice seekApprentice(string id, int i)
        {
            foreach (Apprentice a in Apprentices)
            {
                if (a.getID() == id && a.get_IsCandidate() == i)
                    return a;
            }
            return null;
        }

        public static Apprentice seekAllApprentice(string id)
        {
            if (seekApprentice(id, 0) != null)
                return seekApprentice(id, 0);
            else if (seekApprentice(id, 1) != null)
                return seekApprentice(id, 1);
            else return null;
        }
        public static Apprentice seekApprenticeByStatus(string id, ApprenticeStatus status, int i)
        {
            foreach (Apprentice a in Apprentices)
            {
                if (a.getID() == id && a.get_IsCandidate() == i && a.get_ApprenticeStatus().Equals(status))
                    return a;
            }
            return null;
        }


        public static Lecturer seekLecturer(string id)
        {
            foreach (Lecturer l in Lecturers)
            {
                if (l.get_ID() == id)
                    return l;
            }
            return null;
        }

        public static Session seekSession(DateTime dt)
        {
            foreach (Session s in Sessions)
            {
                if (s.get_SessionDate() == dt)
                    return s;
            }
            return null;
        }

        public static Lecture seekLecture(DateTime dt, LectureTopic topic)
        {
            foreach (Lecture l in Lectures)
            {
                if (l.get_Topic().Equals(topic) && l.get_StartTime().Equals(dt))
                {
                    return l;
                }
            }
            return null;
        }

        public static Assigning seekAssigning(DateTime dt, LectureTopic topic, string id)
        {
            foreach (Assigning a in Assignings)
            {
                if (a.Lecture.get_StartTime().Equals(dt) && a.Lecture.get_Topic().Equals(topic) && a.Lecturer.get_ID().Equals(id))
                {
                    return a;
                }
            }
            return null;
        }

        public static Feedback seekFeedback(DateTime dt, LectureTopic topic, string id)
        {
            foreach (Feedback f in Feedbacks)
            {
                if (f.Lecture.get_StartTime().Equals(dt) && f.Lecture.get_Topic().Equals(topic) && f.Apprentice.getID().Equals(id))
                {
                    return f;
                }
            }
            return null;
        }

        public static Supplier seekSupplier(string id)
        {
            foreach (Supplier s in Suppliers)
            {
                if (s.get_ID() == id)
                    return s;
            }

            return null;
        }


        public static Product seekProduct(string id)
        {
            foreach (Product p in Products)
            {
                if (p.get_ID() == id)
                    return p;
            }

            return null;
        }

        public static Employee seekEmployee(string id)
        {
            foreach (Employee s in Employees)
            {
                if (s.getID() == id)
                    return s;
            }

            return null;
        }

        public static Employee seekEmployeeByStatus(string id, Status st)
        {
            foreach (Employee s in Employees)
            {
                if (s.getID() == id && s.get_status().Equals(st))
                    return s;
            }

            return null;
        }

        public static List<Employee> get_Employees_by_Status(Status status)
        {
            List<Employee> list = new List<Employee>();

            foreach (Employee e in Employees)
            {
                if (e.get_status() == status)
                {
                    list.Add(e);
                }
            }
            return list;
        }

        public static List<Lecturer> get_Lecturers_by_Status(Status status)
        {
            List<Lecturer> list = new List<Lecturer>();

            foreach (Lecturer l in Lecturers)
            {
                if (l.get_Status() == status)
                {
                    list.Add(l);
                }
            }
            return list;
        }

        public static List<Apprentice> get_Apprentices_by_Status(ApprenticeStatus status)
        {
            List<Apprentice> list = new List<Apprentice>();

            foreach (Apprentice a in Apprentices)
            {
                if (a.get_ApprenticeStatus() == status)
                {
                    list.Add(a);
                }
            }
            return list;
        }

        public static void initLists()
        {
            init_Employees();
            init_Apprentices();

            init_Lecturers();
            init_Sessions();
            init_Lectures();
            init_Assignings();

            init_suppliers();
            init_products();
            init_orders();

            init_SortingTests();
            init_CandidateRatingCat();
            init_CandidateRateByCat();

            init_Feedbacks();
        }



        public static void init_Lecturers()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Lecturers";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            Lecturers = new List<Lecturer>();

            while (rdr.Read())
            {
                Status s = (Status)Enum.Parse(typeof(Status), rdr.GetValue(5).ToString());
                Lecturer l = new Lecturer(rdr.GetValue(0).ToString(), rdr.GetValue(1).ToString(), rdr.GetValue(2).ToString(), rdr.GetValue(3).ToString(), rdr.GetValue(4).ToString(), s, false);
                Lecturers.Add(l);
            }
        }

        public static void init_Sessions()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Sessions";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            Sessions = new List<Session>();

            while (rdr.Read())
            {
                Location l = (Location)Enum.Parse(typeof(Location), rdr.GetValue(4).ToString());
                Session s = new Session(DateTime.Parse(rdr.GetValue(0).ToString()), int.Parse(rdr.GetValue(1).ToString()), rdr.GetValue(2).ToString(), int.Parse(rdr.GetValue(3).ToString()), l, int.Parse(rdr.GetValue(5).ToString()), false);
                Sessions.Add(s);
            }
        }

        public static void init_Lectures()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Lectures";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            Lectures = new List<Lecture>();

            while (rdr.Read())
            {
                Session s = seekSession(DateTime.Parse((rdr.GetValue(3).ToString())));
                LectureTopic lt = (LectureTopic)Enum.Parse(typeof(LectureTopic), rdr.GetValue(2).ToString());
                Lecture l = new Lecture(DateTime.Parse((rdr.GetValue(0).ToString())), int.Parse((rdr.GetValue(1).ToString())), lt, s, false);
                Lectures.Add(l);
            }
        }

        public static void init_Assignings()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Assignings";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            Assignings = new List<Assigning>();

            while (rdr.Read())
            {
                LectureTopic lt = (LectureTopic)Enum.Parse(typeof(LectureTopic), rdr.GetValue(1).ToString());
                Lecture l = seekLecture(DateTime.Parse((rdr.GetValue(0).ToString())), lt);
                Lecturer lr = seekLecturer(rdr.GetValue(2).ToString());
                AssigningStatus s = (AssigningStatus)Enum.Parse(typeof(AssigningStatus), rdr.GetValue(3).ToString());
                Assigning a = new Assigning(l, lr, s, false);
                Assignings.Add(a);
            }
        }

        public static void init_Feedbacks()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Feedbacks";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            Feedbacks = new List<Feedback>();

            while (rdr.Read())
            {
                LectureTopic lt = (LectureTopic)Enum.Parse(typeof(LectureTopic), rdr.GetValue(4).ToString());
                Lecture l = seekLecture(DateTime.Parse((rdr.GetValue(1).ToString())), lt);
                Apprentice a = seekAllApprentice(rdr.GetValue(5).ToString());
                Feedback f = new Feedback(l, a, DateTime.Parse((rdr.GetValue(0).ToString())), int.Parse((rdr.GetValue(2).ToString())), rdr.GetValue(3).ToString(), false);
                Feedbacks.Add(f);
            }
        }

        public static void init_suppliers()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Suppliers";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            Suppliers = new List<Supplier>();

            while (rdr.Read())
            {

                Supplier s = new Supplier(rdr.GetValue(0).ToString(), rdr.GetValue(1).ToString(), rdr.GetValue(2).ToString(), rdr.GetValue(3).ToString(), rdr.GetValue(4).ToString(), rdr.GetValue(5).ToString(), rdr.GetValue(6).ToString(), false);
                Suppliers.Add(s);
            }
        }

        public static void init_products()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Products";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);
            Products = new List<Product>();
            while (rdr.Read())

            {
                ProductCategory pc = (ProductCategory)Enum.Parse(typeof(ProductCategory), rdr.GetValue(5).ToString());
                Product p = new Product(seekSupplier(rdr.GetValue(0).ToString()), (rdr.GetValue(1).ToString()), (rdr.GetValue(2).ToString()), int.Parse(rdr.GetValue(3).ToString()), double.Parse(rdr.GetValue(4).ToString()), pc, false);
                Products.Add(p);
                if (seekSupplier(rdr.GetValue(0).ToString()) != null)
                    seekSupplier(rdr.GetValue(0).ToString()).AddProducts(p);
            }
        }

        public static void init_orders()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Orders";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);
            Orders = new List<Order>();
            while (rdr.Read())
            {
                Order o = new Order(seekSupplier(rdr.GetValue(4).ToString()), (rdr.GetValue(0).ToString()), DateTime.Parse((rdr.GetValue(1).ToString())), DateTime.Parse((rdr.GetValue(2).ToString())), Convert.ToBoolean(rdr.GetValue(3)), false);
                Orders.Add(o);
                seekSupplier(rdr.GetValue(4).ToString()).AddOrders(o);
            }
        }

        public static void init_Employees()
        {
            SqlCommand c1 = new SqlCommand();
            c1.CommandText = "EXECUTE Get_all_Employees";
            SQL_CON SC1 = new SQL_CON();
            SqlDataReader rdr = SC1.execute_query(c1);
            Employees = new List<Employee>();
            while (rdr.Read())
            {
                Status s = (Status)Enum.Parse(typeof(Status), rdr.GetValue(7).ToString());
                EmployeeType et = (EmployeeType)Enum.Parse(typeof(EmployeeType), rdr.GetValue(4).ToString());
                Employee e = new Employee(rdr.GetValue(0).ToString(), rdr.GetValue(1).ToString(), rdr.GetValue(2).ToString(), rdr.GetValue(3).ToString(), et, rdr.GetValue(5).ToString(), DateTime.Parse(rdr.GetValue(6).ToString()), s, false);
                Employees.Add(e);
            }
        }

        public static void init_Apprentices()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE Get_all_Apprentices";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);
            Apprentices = new List<Apprentice>();
            while (rdr.Read())
            {
                ApprenticeStatus s = (ApprenticeStatus)Enum.Parse(typeof(ApprenticeStatus), rdr.GetValue(7).ToString());
                Apprentice a = new Apprentice(rdr.GetValue(0).ToString(), rdr.GetValue(1).ToString(), rdr.GetValue(2).ToString(), int.Parse(rdr.GetValue(3).ToString()), rdr.GetValue(4).ToString(), rdr.GetValue(5).ToString(), rdr.GetValue(6).ToString(), s, int.Parse(rdr.GetValue(8).ToString()), false);
                Apprentices.Add(a);
            }
        }

        public static void init_SortingTests()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_SortingTests";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);
            SortingTests = new List<SortingTest>();
            while (rdr.Read())
            {
                SortingTest st = new SortingTest(seekAllApprentice(rdr.GetValue(1).ToString()), Convert.ToDateTime(rdr.GetValue(0).ToString()), false);
                SortingTests.Add(st);
                if (seekAllApprentice(rdr.GetValue(1).ToString()) != null)
                    seekAllApprentice(rdr.GetValue(1).ToString()).AddSortingTests(st);
            }
        }

        public static void init_CandidateRatingCat()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_CandidatesCategories";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);
            CategoryOfCandidates = new List<CategoryOfCandidate>();
            while (rdr.Read())
            {
                SortingCategory sc = ((SortingCategory)Enum.Parse(typeof(SortingCategory), rdr.GetValue(0).ToString()));
                CategoryOfCandidate cat = new CategoryOfCandidate(sc, false);
                CategoryOfCandidates.Add(cat);
            }
        }


        public static void init_CandidateRateByCat()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_RatingCandidatesByCategories";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);
            CandidateRateByCats = new List<CandidateRateByCat>();
            while (rdr.Read())
            {
                SortingTest st = new SortingTest(seekAllApprentice(rdr.GetValue(1).ToString()), Convert.ToDateTime(rdr.GetValue(0).ToString()), false);
                SortingCategory sc = (SortingCategory)Enum.Parse(typeof(SortingCategory), rdr.GetValue(2).ToString());
                CategoryOfCandidate coc = new CategoryOfCandidate(sc, false);
                CandidateRateByCat rate = new CandidateRateByCat(st, coc, double.Parse(rdr.GetValue(3).ToString()), false);
                CandidateRateByCats.Add(rate);
            }
        }


        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            initLists();

           // Application.Run(new Login());
            //Application.Run(new LectureManage());
            Application.Run(new Login());
            //Application.Run(new Login());


        }

    }
}

