﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class SupplierCRUD : Form
    {
        public SupplierCRUD()
        {
            InitializeComponent();
        }

       
        

        private void SupplierCRUD_Load(object sender, EventArgs e)
        {

        }

        private void To_S_Add_Click(object sender, EventArgs e)
        {
            AddSupplier AS = new AddSupplier();
            AS.Show();
            this.Hide();
        }

        private void To_S_Update_Click(object sender, EventArgs e)
        {
            UpdateDeleteS UDS = new UpdateDeleteS();
            UDS.Show();
            this.Hide();
        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            HomePage hp = new HomePage();
            hp.Show();
            this.Hide();
        }
    }
}
