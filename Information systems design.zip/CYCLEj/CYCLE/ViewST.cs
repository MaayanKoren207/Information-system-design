﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class ViewST : Form
    {
        private List<DateTime> DT;
        public Apprentice Candidate;
        public string ID;
        public ViewST()
        {
            InitializeComponent();
            DateDisplay.ValueMember = "DateTimeValue";
            DateDisplay.DisplayMember = "DateTimeValue";
            for (int i = 1; i < 6; i++)
            {
                Label label = (Label)Controls["Cat" + i.ToString()];
                Label Prg = (Label)Controls["Prg" + i.ToString()];
                ComboBox Prg_input = (ComboBox)this.Controls["Percentage" + i.ToString()];
                label.Visible = false;
                Prg.Visible = false;
                Prg_input.Visible = false;
                for (int j = 0; j <= 100; j++)
                    Prg_input.Items.Add(j);
                Prg_input.SelectedIndex = 20;
            }
            AverageScore.Hide();
            Prg_Error.Hide();

            SortingTestCRUD CRUD = SortingTestCRUD.CRUD;
            ID = CRUD.ID;
            Candidate = Program.seekAllApprentice(ID);
            CandidateID.Text = "ID: " + ID + "  " + Candidate.get_FirstName() + " " + Candidate.get_LastName();
            DT = new List<DateTime>();
            foreach (SortingTest st in Candidate.SortingTests)
            {
                if (!DT.Contains(st.get_TestDate()))
                    DT.Add(st.get_TestDate());
            }
            DateDisplay.DataSource = DT.Select(dt => new { DateTimeValue = dt.ToString("dd/MM/yyyy HH:mm:ss") }).ToList();


        }

        private void DateDisplay_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 1; i < 6; i++)
            {
                Label label = (Label)Controls["Cat" + i.ToString()];
                label.Visible = false;
            }
            AverageScore.Hide();
            double count = 0;
            double sum = 0;
            int counter = 0;
            String Date = DateTime.Now.ToString(DateDisplay.Text);
            foreach (CandidateRateByCat cat in Program.CandidateRateByCats)
            {
                if (cat.sortingTest.get_TestDate().ToString() == Date && cat.SortingTest.Apprentice.getID() == Candidate.getID())
                {
                    counter++;
                    count++;
                    sum = sum + cat.get_RateInCat();
                    Label label = (Label)Controls["Cat" + counter.ToString()];
                    label.Visible = true;
                    label.Text = cat.categoryOfCandidate.get_CategoryOfCandidate().ToString() + "  " + cat.get_RateInCat();
                }
            }
            AverageScore.Show();
            AverageScore.Text = "Average Rate:  " + (sum / count).ToString();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            SortingTestCRUD stc = new SortingTestCRUD();
            stc.Show();
            this.Close();
        }

        private void ViewST_Load(object sender, EventArgs e)
        {

        }

        private void ChangeRateCalc_Click(object sender, EventArgs e)
        {
            for (int i = 1; i < 6; i++)
            {
                Label Prg = (Label)Controls["Prg" + i.ToString()];
                ComboBox Prg_input = (ComboBox)this.Controls["Percentage" + i.ToString()];
                Prg.Visible = true;
                Prg_input.Visible = true;


            }
        }

        private void Calc_Click(object sender, EventArgs e)
        {
            double rate = 0;
            if (Is100Percent())
            {
                Prg_Error.Hide();
                for (int i = 1; i < 6; i++)
                {
                    ComboBox Prg_input = (ComboBox)this.Controls["Percentage" + i.ToString()];
                }
                int counter = 0;
                String Date = DateTime.Now.ToString(DateDisplay.Text);
                foreach (CandidateRateByCat cat in Program.CandidateRateByCats)
                {
                    if (cat.sortingTest.get_TestDate().ToString() == Date && cat.SortingTest.Apprentice.getID() == Candidate.getID())
                    {
                        counter++;
                        ComboBox Prg_input = (ComboBox)this.Controls["Percentage" + counter.ToString()];
                        rate = cat.get_RateInCat() * ((double)(int)Prg_input.SelectedItem / 100) + rate;
                    }
                }
                AverageScore.Text = "Average Rate:  " + rate;
            }
            else
            {
                Prg_Error.Show();
            }
        }

        private bool Is100Percent()
        {
            int MaxNum = 0;
            for (int i = 1; i < 6; i++)
            {
                ComboBox Prg_input = (ComboBox)this.Controls["Percentage" + i.ToString()];
                MaxNum = MaxNum + (int)Prg_input.SelectedItem;
            }
            if (MaxNum != 100)
                return false;
            else return true;
        }
    }

}
