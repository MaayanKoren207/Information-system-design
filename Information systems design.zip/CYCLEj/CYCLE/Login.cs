﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{

    public partial class Login : Form
    {

        private Employee employee; //205569957     karin
        private Apprentice apprentice; //  344405955  Maya


        public Login()
        {
            ////UserName_Lable //Password_Lable
            //UserName_Input //Password_Input
            //Welcome_Lable  //Invalid_Info_Lable
            //Login_Butt

            InitializeComponent();
            Invalid_Info_Lable.Hide();

        }

        private void Login_Butt_Click(object sender, EventArgs e)
        {
            if (UserName_Input.Text != null && Password_Input.Text != null)
            {
                Employee employee = Program.seekEmployeeByStatus(Password_Input.Text, Status.Active);

                if (employee != null)
                {
                    if (UserName_Input.Text.Equals(employee.get_FirstName()))
                    {
                        HomePage hp = new HomePage(employee);
                        hp.Show();
                        this.Hide();
                    }
                    else
                    {
                        Invalid_Info_Lable.Show();
                        Password_Input.Text = "";
                        UserName_Input.Text = "";
                    }
                }
                else
                {
                    Apprentice apprentice = Program.seekApprenticeByStatus(Password_Input.Text, ApprenticeStatus.ParticipatesInCurrentClass, 0);

                    if (apprentice != null)
                    {
                        if (UserName_Input.Text.Equals(apprentice.get_FirstName()))
                        {
                            AppHomePage ahp = new AppHomePage(apprentice);
                            ahp.Show();
                            this.Hide();
                        }
                        else
                        {
                            Invalid_Info_Lable.Show();
                            Password_Input.Text = "";
                            UserName_Input.Text = "";
                        }

                    }
                    else
                    {
                        Invalid_Info_Lable.Show();

                    }
                }

            }
            else
            {
                MessageBox.Show("Please Insert UserName and Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void Password_Input_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
