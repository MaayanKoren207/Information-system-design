﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class EmployeeCRUD : Form
    {
        public EmployeeCRUD()
        {
            InitializeComponent();
        }

        private void To_E_Update_Click(object sender, EventArgs e)
        {
            UpdateEmployee update_A = new UpdateEmployee();
            update_A.Show();
            this.Hide();
            
        }

        private void EmployeeCRUD_Load(object sender, EventArgs e)
        {

        }

        private void To_E_Add_Click(object sender, EventArgs e)
        {
            AddEmployee add_E = new AddEmployee();
            add_E.Show();
            this.Hide();
        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            HomePage hp = new HomePage();
            hp.Show();
            this.Hide();
        }
    }
}
