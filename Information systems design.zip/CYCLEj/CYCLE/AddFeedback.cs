﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class AddFeedback : Form
    {
        private Lecture Lecture_Exist;
        private Apprentice Apprentice;

        public AddFeedback()
        {
            InitializeComponent();
            Invalid_Lecture_Lable.Hide();

            Topic_Input.DataSource = Enum.GetValues(typeof(LectureTopic));
            Topic_Input.SelectedIndex = -1;
            EmptyMSG.Hide();
            FeedbackText_Label.Hide();
            Rate_Label.Hide();
            FeedbackText_Input.Hide();
            Rate_Input.Hide();

            Add_Feedback_Butt.Hide();

        }

        public AddFeedback(Apprentice apprentice)
        {
            InitializeComponent();
            this.Apprentice = apprentice;

            Topic_Input.DataSource = Enum.GetValues(typeof(LectureTopic));
            Topic_Input.SelectedIndex = -1;

            Invalid_Lecture_Lable.Hide();

            FeedbackText_Label.Hide();
            Rate_Label.Hide();
            FeedbackText_Input.Hide();
            Rate_Input.Hide();
            F_ExitError.Hide();

            Add_Feedback_Butt.Hide();

            A_ID_Input.Text = Apprentice.getID();
            A_Name_Input.Text = Apprentice.get_FirstName();
        }



        private void AddFeedback_Load(object sender, EventArgs e)
        {

        }


        private void Fil_Feedback_Butt_Click(object sender, EventArgs e)
        {
            if (Topic_Input.SelectedIndex == -1)
                Topic_Input.SelectedIndex = 0;
            Lecture_Exist = Program.seekLecture((DateTime.Parse(LectureDate_Input.Text)), (LectureTopic)Enum.Parse(typeof(LectureTopic), Topic_Input.Text));
            if (Lecture_Exist != null)
            {
                Invalid_Lecture_Lable.Hide();

                int[] values = { 1, 2, 3, 4, 5 };
                foreach (int value in values)
                {
                    Rate_Input.Items.Add(value);
                }
                Rate_Input.SelectedIndex = -1;

                FeedbackText_Label.Show();
                Rate_Label.Show();
                FeedbackText_Input.Show();
                Rate_Input.Show();

                Add_Feedback_Butt.Show();
            }
            else
            {
                Invalid_Lecture_Lable.Show();
                FeedbackText_Label.Hide();
                Rate_Label.Hide();
                FeedbackText_Input.Hide();
                Rate_Input.Hide();
                Add_Feedback_Butt.Hide();
                EmptyMSG.Hide();

            }
        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            HomePage ac = new HomePage();
            ac.Show();
            this.Close();
        }

        private void Add_Feedback_Butt_Click(object sender, EventArgs e)
        {
            if (!DoesExist())
            {
                F_ExitError.Hide();
                if (FeedbackText_Input.Text == null || Rate_Input.Text == null)
                    EmptyMSG.Show();
                else
                {
                    Feedback f = new Feedback(Lecture_Exist, Apprentice, DateTime.Parse(Date_Input.Text), int.Parse(Rate_Input.Text), FeedbackText_Input.Text, true);
                    HomePage ac = new HomePage();
                    ac.Show();
                    this.Close();
                }
            }
            else
            {
                F_ExitError.Show();
            }
        }

        private void Date_Input_ValueChanged(object sender, EventArgs e)
        {

        }

        private bool DoesExist()
        {
            foreach (Feedback F in Program.Feedbacks)
            {
                if (Apprentice.getID() == F.Apprentice.getID() && (LectureTopic)Topic_Input.SelectedValue == F.Lecture.get_Topic() && LectureDate_Input.Value == F.Lecture.get_StartTime())
                    return true;
            }
            return false;
        }
    }
}
