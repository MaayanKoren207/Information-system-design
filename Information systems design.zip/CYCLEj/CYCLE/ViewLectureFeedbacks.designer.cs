﻿namespace CYCLE
{
    partial class ViewLectureFeedbacks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Topic_Lable = new System.Windows.Forms.Label();
            this.Back_Butt = new System.Windows.Forms.Button();
            this.Feedback_DataGrid = new System.Windows.Forms.DataGridView();
            this.Topic_Input = new System.Windows.Forms.ComboBox();
            this.StartTime_Lable = new System.Windows.Forms.Label();
            this.StartTime_Input = new System.Windows.Forms.DateTimePicker();
            this.Invalid_Lecture_Lable = new System.Windows.Forms.Label();
            this.View_Lecture_FeedbackList_Butt = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Text_ViewLectureFeedback = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Feedback_DataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Topic_Lable
            // 
            this.Topic_Lable.AutoSize = true;
            this.Topic_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Topic_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Topic_Lable.Location = new System.Drawing.Point(78, 142);
            this.Topic_Lable.Name = "Topic_Lable";
            this.Topic_Lable.Size = new System.Drawing.Size(56, 26);
            this.Topic_Lable.TabIndex = 0;
            this.Topic_Lable.Text = "Topic";
            // 
            // Back_Butt
            // 
            this.Back_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Back_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Back_Butt.ForeColor = System.Drawing.Color.White;
            this.Back_Butt.Location = new System.Drawing.Point(12, 531);
            this.Back_Butt.Name = "Back_Butt";
            this.Back_Butt.Size = new System.Drawing.Size(140, 68);
            this.Back_Butt.TabIndex = 1;
            this.Back_Butt.Text = "Back";
            this.Back_Butt.UseVisualStyleBackColor = false;
            this.Back_Butt.Click += new System.EventHandler(this.Back_Butt_Click);
            // 
            // Feedback_DataGrid
            // 
            this.Feedback_DataGrid.BackgroundColor = System.Drawing.Color.White;
            this.Feedback_DataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Feedback_DataGrid.Location = new System.Drawing.Point(42, 236);
            this.Feedback_DataGrid.Name = "Feedback_DataGrid";
            this.Feedback_DataGrid.Size = new System.Drawing.Size(599, 275);
            this.Feedback_DataGrid.TabIndex = 2;
            this.Feedback_DataGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Feedback_DataGrid_CellContentClick);
            // 
            // Topic_Input
            // 
            this.Topic_Input.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Topic_Input.Enabled = false;
            this.Topic_Input.Font = new System.Drawing.Font("Calibri", 12F);
            this.Topic_Input.FormattingEnabled = true;
            this.Topic_Input.Location = new System.Drawing.Point(197, 147);
            this.Topic_Input.Name = "Topic_Input";
            this.Topic_Input.Size = new System.Drawing.Size(185, 27);
            this.Topic_Input.TabIndex = 3;
            // 
            // StartTime_Lable
            // 
            this.StartTime_Lable.AutoSize = true;
            this.StartTime_Lable.BackColor = System.Drawing.Color.Transparent;
            this.StartTime_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.StartTime_Lable.Location = new System.Drawing.Point(76, 100);
            this.StartTime_Lable.Name = "StartTime_Lable";
            this.StartTime_Lable.Size = new System.Drawing.Size(100, 26);
            this.StartTime_Lable.TabIndex = 4;
            this.StartTime_Lable.Text = "Start Time";
            // 
            // StartTime_Input
            // 
            this.StartTime_Input.CustomFormat = "dd/MM/yyyy HH:mm:ss";
            this.StartTime_Input.Enabled = false;
            this.StartTime_Input.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.StartTime_Input.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.StartTime_Input.Location = new System.Drawing.Point(197, 106);
            this.StartTime_Input.Name = "StartTime_Input";
            this.StartTime_Input.Size = new System.Drawing.Size(185, 27);
            this.StartTime_Input.TabIndex = 5;
            // 
            // Invalid_Lecture_Lable
            // 
            this.Invalid_Lecture_Lable.AutoSize = true;
            this.Invalid_Lecture_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Invalid_Lecture_Lable.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Invalid_Lecture_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Invalid_Lecture_Lable.Location = new System.Drawing.Point(193, 194);
            this.Invalid_Lecture_Lable.Name = "Invalid_Lecture_Lable";
            this.Invalid_Lecture_Lable.Size = new System.Drawing.Size(253, 23);
            this.Invalid_Lecture_Lable.TabIndex = 6;
            this.Invalid_Lecture_Lable.Text = "Please Insert Valid Lecture Info!";
            // 
            // View_Lecture_FeedbackList_Butt
            // 
            this.View_Lecture_FeedbackList_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.View_Lecture_FeedbackList_Butt.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.View_Lecture_FeedbackList_Butt.ForeColor = System.Drawing.Color.White;
            this.View_Lecture_FeedbackList_Butt.Location = new System.Drawing.Point(407, 106);
            this.View_Lecture_FeedbackList_Butt.Name = "View_Lecture_FeedbackList_Butt";
            this.View_Lecture_FeedbackList_Butt.Size = new System.Drawing.Size(131, 57);
            this.View_Lecture_FeedbackList_Butt.TabIndex = 7;
            this.View_Lecture_FeedbackList_Butt.Text = "View Feedback List";
            this.View_Lecture_FeedbackList_Butt.UseVisualStyleBackColor = false;
            this.View_Lecture_FeedbackList_Butt.Click += new System.EventHandler(this.View_Lecture_FeedbackList_Butt_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 44;
            this.pictureBox2.TabStop = false;
            // 
            // Text_ViewLectureFeedback
            // 
            this.Text_ViewLectureFeedback.AutoSize = true;
            this.Text_ViewLectureFeedback.BackColor = System.Drawing.Color.Transparent;
            this.Text_ViewLectureFeedback.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.Text_ViewLectureFeedback.ForeColor = System.Drawing.Color.Navy;
            this.Text_ViewLectureFeedback.Location = new System.Drawing.Point(75, 43);
            this.Text_ViewLectureFeedback.Name = "Text_ViewLectureFeedback";
            this.Text_ViewLectureFeedback.Size = new System.Drawing.Size(358, 33);
            this.Text_ViewLectureFeedback.TabIndex = 45;
            this.Text_ViewLectureFeedback.Text = "Please Insert The Following Info";
            // 
            // ViewLectureFeedbacks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.Text_ViewLectureFeedback);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.View_Lecture_FeedbackList_Butt);
            this.Controls.Add(this.Invalid_Lecture_Lable);
            this.Controls.Add(this.StartTime_Input);
            this.Controls.Add(this.StartTime_Lable);
            this.Controls.Add(this.Topic_Input);
            this.Controls.Add(this.Feedback_DataGrid);
            this.Controls.Add(this.Back_Butt);
            this.Controls.Add(this.Topic_Lable);
            this.Name = "ViewLectureFeedbacks";
            this.Text = "ViewLectureFeedbacks";
            this.Load += new System.EventHandler(this.ViewLectureFeedbacks_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Feedback_DataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Topic_Lable;
        private System.Windows.Forms.Button Back_Butt;
        private System.Windows.Forms.DataGridView Feedback_DataGrid;
        private System.Windows.Forms.ComboBox Topic_Input;
        private System.Windows.Forms.Label StartTime_Lable;
        private System.Windows.Forms.DateTimePicker StartTime_Input;
        private System.Windows.Forms.Label Invalid_Lecture_Lable;
        private System.Windows.Forms.Button View_Lecture_FeedbackList_Butt;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Text_ViewLectureFeedback;
    }
}