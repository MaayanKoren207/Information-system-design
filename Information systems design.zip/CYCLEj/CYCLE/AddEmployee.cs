﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CYCLE
{
    public partial class AddEmployee : Form
    {
        public AddEmployee()
        {
            InitializeComponent();
            E_StatusEnumInput.DataSource = Enum.GetValues(typeof(Status));
            E_EmployeeTypeInput.DataSource = Enum.GetValues(typeof(EmployeeType));
            E_StatusEnumInput.SelectedIndex = -1;
            E_EmployeeTypeInput.SelectedIndex = -1;
            E_FormatText.Hide();
        }

        private void AddEmployee_Load(object sender, EventArgs e)
        {

        }

        private void E_PhoneNumInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void E_StartingDateInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void E_AddNew_Click(object sender, EventArgs e)
        {
            if (IsValidInput())
            {

                if (E_StatusEnumInput.Equals(-1))
                {
                    E_StatusEnumInput.SelectedIndex = 0;  //Active Employee by default

                }

                if (E_EmployeeTypeInput.Equals(-1))
                {
                    E_EmployeeTypeInput.SelectedIndex = 3;  //Mentor
                }

                E_FormatText.Hide();

                Employee E = new Employee(E_IDInput.Text, E_FnameInput.Text, E_LnameInput.Text, E_PhoneNumInput.Text, (EmployeeType)Enum.Parse(typeof(EmployeeType), E_EmployeeTypeInput.Text), E_EmpolyeeInput.Text, DateTime.Parse(dateTimePickerEmployee.Text), (Status)Enum.Parse(typeof(Status), E_StatusEnumInput.Text), true);
                EmployeeCRUD ac = new EmployeeCRUD();
                ac.Show();
                this.Close();
            }
            else
            {
                E_FormatText.Show();
                if (E_FormatText.Font.Size <= 20)
                    E_FormatText.Font = new Font(E_FormatText.Font.FontFamily, E_FormatText.Font.Size + 1);
                else if (E_FormatText.ForeColor == Color.Red)
                    E_FormatText.ForeColor = Color.Gold;
                else
                    E_FormatText.ForeColor = Color.Red;
            }
        }

        private void E_back1_Click(object sender, EventArgs e)
        {
            EmployeeCRUD ac = new EmployeeCRUD();
            ac.Show();
            this.Close();
        }


        private bool IsValidInput()
        {
            if (!Int32.TryParse(E_IDInput.Text, out int Value) || !Int32.TryParse(E_PhoneNumInput.Text, out Value))
                return false; //Making sure ID, PhoneNum are all numbers

            else if (E_IDInput.Text == null || E_FnameInput.Text == null || E_LnameInput.Text == null || E_EmpolyeeInput.Text == null || E_PhoneNumInput.Text == null || DateTime.Parse(dateTimePickerEmployee.Text) == null)
                return false; // Making sure no input is to stay null

            else if (100000000 > int.Parse(E_IDInput.Text) || int.Parse(E_IDInput.Text) > 999999999)
                return false;// Making sure ID is a number in the right length

            else if (Regex.IsMatch(E_EmpolyeeInput.Text, @"^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$") == false)
                return false;// Making sure the email is in the right format

            else if (Regex.IsMatch(E_FnameInput.Text, @"^[a-zA-Z][a-z]*$") == false || Regex.IsMatch(E_LnameInput.Text, @"^[a-zA-Z][a-z]*$") == false)
                return false;// Making sure full name containing only letters

            else if (E_IDInput.Text.Length != 9 || E_PhoneNumInput.Text.Length != 10)
                return false;// Making sure ID and PhoneNum are the right length

            else if (Program.seekEmployee(E_IDInput.Text) != null)
                return false; // Making sure Employee ID is not already exist

            else
                return true;
        }

        private void E_LnameInput_TextChanged(object sender, EventArgs e)
        {

        }
    }
}