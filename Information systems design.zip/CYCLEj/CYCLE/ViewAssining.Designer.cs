﻿namespace CYCLE
{
    partial class ViewAssining
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.L_ID_Lable = new System.Windows.Forms.Label();
            this.L_ID_Input = new System.Windows.Forms.TextBox();
            this.ViewAss_Butt = new System.Windows.Forms.Button();
            this.Ass_DataGrid = new System.Windows.Forms.DataGridView();
            this.aSSIGNINGLECTURERSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sAD_29DataSet = new CYCLE.SAD_29DataSet();
            this.aSSIGNING_LECTURERSTableAdapter = new CYCLE.SAD_29DataSetTableAdapters.ASSIGNING_LECTURERSTableAdapter();
            this.Invalid_ID_Lable = new System.Windows.Forms.Label();
            this.Back_Butt = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Ass_DataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aSSIGNINGLECTURERSBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAD_29DataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // L_ID_Lable
            // 
            this.L_ID_Lable.AutoSize = true;
            this.L_ID_Lable.BackColor = System.Drawing.Color.Transparent;
            this.L_ID_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.L_ID_Lable.Location = new System.Drawing.Point(124, 93);
            this.L_ID_Lable.Name = "L_ID_Lable";
            this.L_ID_Lable.Size = new System.Drawing.Size(105, 26);
            this.L_ID_Lable.TabIndex = 0;
            this.L_ID_Lable.Text = "Lecturer ID";
            // 
            // L_ID_Input
            // 
            this.L_ID_Input.Location = new System.Drawing.Point(259, 97);
            this.L_ID_Input.Multiline = true;
            this.L_ID_Input.Name = "L_ID_Input";
            this.L_ID_Input.Size = new System.Drawing.Size(185, 27);
            this.L_ID_Input.TabIndex = 1;
            // 
            // ViewAss_Butt
            // 
            this.ViewAss_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.ViewAss_Butt.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.ViewAss_Butt.ForeColor = System.Drawing.Color.White;
            this.ViewAss_Butt.Location = new System.Drawing.Point(472, 93);
            this.ViewAss_Butt.Name = "ViewAss_Butt";
            this.ViewAss_Butt.Size = new System.Drawing.Size(128, 34);
            this.ViewAss_Butt.TabIndex = 2;
            this.ViewAss_Butt.Text = "View";
            this.ViewAss_Butt.UseVisualStyleBackColor = false;
            this.ViewAss_Butt.Click += new System.EventHandler(this.ViewAss_Butt_Click);
            // 
            // Ass_DataGrid
            // 
            this.Ass_DataGrid.BackgroundColor = System.Drawing.Color.White;
            this.Ass_DataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Ass_DataGrid.Location = new System.Drawing.Point(60, 203);
            this.Ass_DataGrid.Name = "Ass_DataGrid";
            this.Ass_DataGrid.Size = new System.Drawing.Size(556, 178);
            this.Ass_DataGrid.TabIndex = 3;
            this.Ass_DataGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Ass_DataGrid_CellContentClick);
            // 
            // aSSIGNINGLECTURERSBindingSource
            // 
            this.aSSIGNINGLECTURERSBindingSource.DataMember = "ASSIGNING_LECTURERS";
            this.aSSIGNINGLECTURERSBindingSource.DataSource = this.sAD_29DataSet;
            // 
            // sAD_29DataSet
            // 
            this.sAD_29DataSet.DataSetName = "SAD_29DataSet";
            this.sAD_29DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // aSSIGNING_LECTURERSTableAdapter
            // 
            this.aSSIGNING_LECTURERSTableAdapter.ClearBeforeFill = true;
            // 
            // Invalid_ID_Lable
            // 
            this.Invalid_ID_Lable.AutoSize = true;
            this.Invalid_ID_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Invalid_ID_Lable.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Invalid_ID_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Invalid_ID_Lable.Location = new System.Drawing.Point(450, 141);
            this.Invalid_ID_Lable.Name = "Invalid_ID_Lable";
            this.Invalid_ID_Lable.Size = new System.Drawing.Size(240, 23);
            this.Invalid_ID_Lable.TabIndex = 4;
            this.Invalid_ID_Lable.Text = "Please Insert Valid Lecturer ID";
            // 
            // Back_Butt
            // 
            this.Back_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Back_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Back_Butt.ForeColor = System.Drawing.Color.White;
            this.Back_Butt.Location = new System.Drawing.Point(12, 531);
            this.Back_Butt.Name = "Back_Butt";
            this.Back_Butt.Size = new System.Drawing.Size(140, 68);
            this.Back_Butt.TabIndex = 5;
            this.Back_Butt.Text = "Back";
            this.Back_Butt.UseVisualStyleBackColor = false;
            this.Back_Butt.Click += new System.EventHandler(this.Back_Butt_Click);
            // 
            // ViewAssining
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.Back_Butt);
            this.Controls.Add(this.Invalid_ID_Lable);
            this.Controls.Add(this.Ass_DataGrid);
            this.Controls.Add(this.ViewAss_Butt);
            this.Controls.Add(this.L_ID_Input);
            this.Controls.Add(this.L_ID_Lable);
            this.Name = "ViewAssining";
            this.Text = "ViewAssining";
            this.Load += new System.EventHandler(this.ViewAssining_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Ass_DataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aSSIGNINGLECTURERSBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAD_29DataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label L_ID_Lable;
        private System.Windows.Forms.TextBox L_ID_Input;
        private System.Windows.Forms.Button ViewAss_Butt;
        private System.Windows.Forms.DataGridView Ass_DataGrid;
        private SAD_29DataSet sAD_29DataSet;
        private System.Windows.Forms.BindingSource aSSIGNINGLECTURERSBindingSource;
        private SAD_29DataSetTableAdapters.ASSIGNING_LECTURERSTableAdapter aSSIGNING_LECTURERSTableAdapter;
        private System.Windows.Forms.Label Invalid_ID_Lable;
        private System.Windows.Forms.Button Back_Butt;
    }
}