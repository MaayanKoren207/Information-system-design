﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CYCLE
{
    public partial class AssigningManage : Form
    {
        public AssigningManage()
        {
            InitializeComponent();
        }

        private void Back_Butt_Click(object sender, EventArgs e)
        {
            HomePage ac = new HomePage();
            ac.Show();
            this.Hide();
        }

        private void Add_Ass_Butt_Click(object sender, EventArgs e)
        {
            AddAssigning ac = new AddAssigning();
            ac.Show();
            this.Hide();
        }

        private void FindLecturerForAssigning_Butt_Click(object sender, EventArgs e)
        {
            FindLecturerForAssigning ac = new FindLecturerForAssigning();
            ac.Show();
            this.Hide();
        }

        private void ViewOptAss_Butt_Click(object sender, EventArgs e)
        {
            ViewAssining la = new ViewAssining();
            la.Owner = this;
            la.Show();
            this.Hide();
        }

        private void AssigningManage_Load(object sender, EventArgs e)
        {

        }
    }
}
