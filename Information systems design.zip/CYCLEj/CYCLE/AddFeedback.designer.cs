﻿namespace CYCLE
{
    partial class AddFeedback
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.A_ID_Label = new System.Windows.Forms.Label();
            this.A_Name_Lable = new System.Windows.Forms.Label();
            this.Date_Lable = new System.Windows.Forms.Label();
            this.Date_Input = new System.Windows.Forms.DateTimePicker();
            this.A_ID_Input = new System.Windows.Forms.TextBox();
            this.A_Name_Input = new System.Windows.Forms.TextBox();
            this.Ins_Lable = new System.Windows.Forms.Label();
            this.LectureDate_Label = new System.Windows.Forms.Label();
            this.Topic_Label = new System.Windows.Forms.Label();
            this.LectureDate_Input = new System.Windows.Forms.DateTimePicker();
            this.Topic_Input = new System.Windows.Forms.ComboBox();
            this.Fil_Feedback_Butt = new System.Windows.Forms.Button();
            this.FeedbackText_Input = new System.Windows.Forms.TextBox();
            this.FeedbackText_Label = new System.Windows.Forms.Label();
            this.Rate_Label = new System.Windows.Forms.Label();
            this.Rate_Input = new System.Windows.Forms.ComboBox();
            this.Add_Feedback_Butt = new System.Windows.Forms.Button();
            this.Back_Butt = new System.Windows.Forms.Button();
            this.Invalid_Lecture_Lable = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.F_ExitError = new System.Windows.Forms.Label();
            this.EmptyMSG = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // A_ID_Label
            // 
            this.A_ID_Label.AutoSize = true;
            this.A_ID_Label.BackColor = System.Drawing.Color.Transparent;
            this.A_ID_Label.Font = new System.Drawing.Font("Calibri", 14F);
            this.A_ID_Label.Location = new System.Drawing.Point(30, 87);
            this.A_ID_Label.Name = "A_ID_Label";
            this.A_ID_Label.Size = new System.Drawing.Size(28, 23);
            this.A_ID_Label.TabIndex = 0;
            this.A_ID_Label.Text = "ID";
            // 
            // A_Name_Lable
            // 
            this.A_Name_Lable.AutoSize = true;
            this.A_Name_Lable.BackColor = System.Drawing.Color.Transparent;
            this.A_Name_Lable.Font = new System.Drawing.Font("Calibri", 14F);
            this.A_Name_Lable.Location = new System.Drawing.Point(25, 118);
            this.A_Name_Lable.Name = "A_Name_Lable";
            this.A_Name_Lable.Size = new System.Drawing.Size(55, 23);
            this.A_Name_Lable.TabIndex = 1;
            this.A_Name_Lable.Text = "Name";
            // 
            // Date_Lable
            // 
            this.Date_Lable.AutoSize = true;
            this.Date_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Date_Lable.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Date_Lable.Location = new System.Drawing.Point(271, 83);
            this.Date_Lable.Name = "Date_Lable";
            this.Date_Lable.Size = new System.Drawing.Size(52, 26);
            this.Date_Lable.TabIndex = 2;
            this.Date_Lable.Text = "Date";
            // 
            // Date_Input
            // 
            this.Date_Input.CustomFormat = "dd/MM/yyyy HH:mm:ss";
            this.Date_Input.Font = new System.Drawing.Font("Calibri", 12F);
            this.Date_Input.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date_Input.Location = new System.Drawing.Point(329, 83);
            this.Date_Input.Name = "Date_Input";
            this.Date_Input.Size = new System.Drawing.Size(165, 27);
            this.Date_Input.TabIndex = 3;
            this.Date_Input.ValueChanged += new System.EventHandler(this.Date_Input_ValueChanged);
            // 
            // A_ID_Input
            // 
            this.A_ID_Input.BackColor = System.Drawing.Color.White;
            this.A_ID_Input.Location = new System.Drawing.Point(94, 89);
            this.A_ID_Input.Multiline = true;
            this.A_ID_Input.Name = "A_ID_Input";
            this.A_ID_Input.ReadOnly = true;
            this.A_ID_Input.Size = new System.Drawing.Size(136, 20);
            this.A_ID_Input.TabIndex = 4;
            // 
            // A_Name_Input
            // 
            this.A_Name_Input.BackColor = System.Drawing.Color.White;
            this.A_Name_Input.Location = new System.Drawing.Point(94, 120);
            this.A_Name_Input.Multiline = true;
            this.A_Name_Input.Name = "A_Name_Input";
            this.A_Name_Input.ReadOnly = true;
            this.A_Name_Input.Size = new System.Drawing.Size(136, 20);
            this.A_Name_Input.TabIndex = 5;
            // 
            // Ins_Lable
            // 
            this.Ins_Lable.AutoSize = true;
            this.Ins_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Ins_Lable.Font = new System.Drawing.Font("Calibri", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ins_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Ins_Lable.Location = new System.Drawing.Point(170, 23);
            this.Ins_Lable.Name = "Ins_Lable";
            this.Ins_Lable.Size = new System.Drawing.Size(387, 36);
            this.Ins_Lable.TabIndex = 6;
            this.Ins_Lable.Text = "Please Insert The Following Info";
            // 
            // LectureDate_Label
            // 
            this.LectureDate_Label.AutoSize = true;
            this.LectureDate_Label.BackColor = System.Drawing.Color.Transparent;
            this.LectureDate_Label.Font = new System.Drawing.Font("Calibri", 14F);
            this.LectureDate_Label.Location = new System.Drawing.Point(91, 174);
            this.LectureDate_Label.Name = "LectureDate_Label";
            this.LectureDate_Label.Size = new System.Drawing.Size(107, 23);
            this.LectureDate_Label.TabIndex = 7;
            this.LectureDate_Label.Text = "Lecture Date";
            // 
            // Topic_Label
            // 
            this.Topic_Label.AutoSize = true;
            this.Topic_Label.BackColor = System.Drawing.Color.Transparent;
            this.Topic_Label.Font = new System.Drawing.Font("Calibri", 14F);
            this.Topic_Label.Location = new System.Drawing.Point(405, 174);
            this.Topic_Label.Name = "Topic_Label";
            this.Topic_Label.Size = new System.Drawing.Size(110, 23);
            this.Topic_Label.TabIndex = 8;
            this.Topic_Label.Text = "Lecture Topic";
            // 
            // LectureDate_Input
            // 
            this.LectureDate_Input.CustomFormat = "dd/MM/yyyy HH:mm:ss";
            this.LectureDate_Input.Font = new System.Drawing.Font("Calibri", 12F);
            this.LectureDate_Input.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.LectureDate_Input.Location = new System.Drawing.Point(204, 170);
            this.LectureDate_Input.Name = "LectureDate_Input";
            this.LectureDate_Input.Size = new System.Drawing.Size(178, 27);
            this.LectureDate_Input.TabIndex = 9;
            // 
            // Topic_Input
            // 
            this.Topic_Input.BackColor = System.Drawing.Color.White;
            this.Topic_Input.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Topic_Input.Font = new System.Drawing.Font("Calibri", 12F);
            this.Topic_Input.FormattingEnabled = true;
            this.Topic_Input.Location = new System.Drawing.Point(521, 174);
            this.Topic_Input.Name = "Topic_Input";
            this.Topic_Input.Size = new System.Drawing.Size(185, 27);
            this.Topic_Input.TabIndex = 10;
            // 
            // Fil_Feedback_Butt
            // 
            this.Fil_Feedback_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Fil_Feedback_Butt.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Fil_Feedback_Butt.ForeColor = System.Drawing.Color.White;
            this.Fil_Feedback_Butt.Location = new System.Drawing.Point(585, 220);
            this.Fil_Feedback_Butt.Name = "Fil_Feedback_Butt";
            this.Fil_Feedback_Butt.Size = new System.Drawing.Size(121, 34);
            this.Fil_Feedback_Butt.TabIndex = 11;
            this.Fil_Feedback_Butt.Text = "Fill Feedback";
            this.Fil_Feedback_Butt.UseVisualStyleBackColor = false;
            this.Fil_Feedback_Butt.Click += new System.EventHandler(this.Fil_Feedback_Butt_Click);
            // 
            // FeedbackText_Input
            // 
            this.FeedbackText_Input.AcceptsTab = true;
            this.FeedbackText_Input.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.FeedbackText_Input.Location = new System.Drawing.Point(91, 289);
            this.FeedbackText_Input.Multiline = true;
            this.FeedbackText_Input.Name = "FeedbackText_Input";
            this.FeedbackText_Input.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.FeedbackText_Input.Size = new System.Drawing.Size(516, 167);
            this.FeedbackText_Input.TabIndex = 12;
            // 
            // FeedbackText_Label
            // 
            this.FeedbackText_Label.AutoSize = true;
            this.FeedbackText_Label.BackColor = System.Drawing.Color.Transparent;
            this.FeedbackText_Label.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FeedbackText_Label.Location = new System.Drawing.Point(87, 263);
            this.FeedbackText_Label.Name = "FeedbackText_Label";
            this.FeedbackText_Label.Size = new System.Drawing.Size(148, 23);
            this.FeedbackText_Label.TabIndex = 13;
            this.FeedbackText_Label.Text = "Feedback Content";
            // 
            // Rate_Label
            // 
            this.Rate_Label.AutoSize = true;
            this.Rate_Label.BackColor = System.Drawing.Color.Transparent;
            this.Rate_Label.Font = new System.Drawing.Font("Calibri", 14F);
            this.Rate_Label.Location = new System.Drawing.Point(88, 477);
            this.Rate_Label.Name = "Rate_Label";
            this.Rate_Label.Size = new System.Drawing.Size(44, 23);
            this.Rate_Label.TabIndex = 14;
            this.Rate_Label.Text = "Rate";
            // 
            // Rate_Input
            // 
            this.Rate_Input.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Rate_Input.FormattingEnabled = true;
            this.Rate_Input.Location = new System.Drawing.Point(138, 477);
            this.Rate_Input.Name = "Rate_Input";
            this.Rate_Input.Size = new System.Drawing.Size(136, 21);
            this.Rate_Input.TabIndex = 15;
            // 
            // Add_Feedback_Butt
            // 
            this.Add_Feedback_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Add_Feedback_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Add_Feedback_Butt.ForeColor = System.Drawing.Color.White;
            this.Add_Feedback_Butt.Location = new System.Drawing.Point(582, 531);
            this.Add_Feedback_Butt.Name = "Add_Feedback_Butt";
            this.Add_Feedback_Butt.Size = new System.Drawing.Size(140, 68);
            this.Add_Feedback_Butt.TabIndex = 16;
            this.Add_Feedback_Butt.Text = "Add Feedback";
            this.Add_Feedback_Butt.UseVisualStyleBackColor = false;
            this.Add_Feedback_Butt.Click += new System.EventHandler(this.Add_Feedback_Butt_Click);
            // 
            // Back_Butt
            // 
            this.Back_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Back_Butt.Font = new System.Drawing.Font("Calibri", 15.75F);
            this.Back_Butt.ForeColor = System.Drawing.Color.White;
            this.Back_Butt.Location = new System.Drawing.Point(12, 531);
            this.Back_Butt.Name = "Back_Butt";
            this.Back_Butt.Size = new System.Drawing.Size(140, 68);
            this.Back_Butt.TabIndex = 17;
            this.Back_Butt.Text = "Back";
            this.Back_Butt.UseVisualStyleBackColor = false;
            this.Back_Butt.Click += new System.EventHandler(this.Back_Butt_Click);
            // 
            // Invalid_Lecture_Lable
            // 
            this.Invalid_Lecture_Lable.AutoSize = true;
            this.Invalid_Lecture_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Invalid_Lecture_Lable.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.Invalid_Lecture_Lable.ForeColor = System.Drawing.Color.Navy;
            this.Invalid_Lecture_Lable.Location = new System.Drawing.Point(349, 231);
            this.Invalid_Lecture_Lable.Name = "Invalid_Lecture_Lable";
            this.Invalid_Lecture_Lable.Size = new System.Drawing.Size(217, 23);
            this.Invalid_Lecture_Lable.TabIndex = 18;
            this.Invalid_Lecture_Lable.Text = "Please Insert Valid Lecture!";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(623, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 81;
            this.pictureBox2.TabStop = false;
            // 
            // F_ExitError
            // 
            this.F_ExitError.AutoSize = true;
            this.F_ExitError.BackColor = System.Drawing.Color.Transparent;
            this.F_ExitError.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.F_ExitError.Location = new System.Drawing.Point(280, 475);
            this.F_ExitError.Name = "F_ExitError";
            this.F_ExitError.Size = new System.Drawing.Size(357, 23);
            this.F_ExitError.TabIndex = 82;
            this.F_ExitError.Text = "Feedback Already Registered For This Lecture";
            // 
            // EmptyMSG
            // 
            this.EmptyMSG.AutoSize = true;
            this.EmptyMSG.BackColor = System.Drawing.Color.Transparent;
            this.EmptyMSG.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.EmptyMSG.Location = new System.Drawing.Point(273, 518);
            this.EmptyMSG.Name = "EmptyMSG";
            this.EmptyMSG.Size = new System.Drawing.Size(261, 23);
            this.EmptyMSG.TabIndex = 83;
            this.EmptyMSG.Text = "Please Make Sure To Fill All Fields";
            // 
            // AddFeedback
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.EmptyMSG);
            this.Controls.Add(this.F_ExitError);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Invalid_Lecture_Lable);
            this.Controls.Add(this.Back_Butt);
            this.Controls.Add(this.Add_Feedback_Butt);
            this.Controls.Add(this.Rate_Input);
            this.Controls.Add(this.Rate_Label);
            this.Controls.Add(this.FeedbackText_Label);
            this.Controls.Add(this.FeedbackText_Input);
            this.Controls.Add(this.Fil_Feedback_Butt);
            this.Controls.Add(this.Topic_Input);
            this.Controls.Add(this.LectureDate_Input);
            this.Controls.Add(this.Topic_Label);
            this.Controls.Add(this.LectureDate_Label);
            this.Controls.Add(this.Ins_Lable);
            this.Controls.Add(this.A_Name_Input);
            this.Controls.Add(this.A_ID_Input);
            this.Controls.Add(this.Date_Input);
            this.Controls.Add(this.Date_Lable);
            this.Controls.Add(this.A_Name_Lable);
            this.Controls.Add(this.A_ID_Label);
            this.ForeColor = System.Drawing.Color.Navy;
            this.Name = "AddFeedback";
            this.Text = "AddFeedback";
            this.Load += new System.EventHandler(this.AddFeedback_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label A_ID_Label;
        private System.Windows.Forms.Label A_Name_Lable;
        private System.Windows.Forms.Label Date_Lable;
        private System.Windows.Forms.DateTimePicker Date_Input;
        private System.Windows.Forms.TextBox A_ID_Input;
        private System.Windows.Forms.TextBox A_Name_Input;
        private System.Windows.Forms.Label Ins_Lable;
        private System.Windows.Forms.Label LectureDate_Label;
        private System.Windows.Forms.Label Topic_Label;
        private System.Windows.Forms.DateTimePicker LectureDate_Input;
        private System.Windows.Forms.ComboBox Topic_Input;
        private System.Windows.Forms.Button Fil_Feedback_Butt;
        private System.Windows.Forms.TextBox FeedbackText_Input;
        private System.Windows.Forms.Label FeedbackText_Label;
        private System.Windows.Forms.Label Rate_Label;
        private System.Windows.Forms.ComboBox Rate_Input;
        private System.Windows.Forms.Button Add_Feedback_Butt;
        private System.Windows.Forms.Button Back_Butt;
        private System.Windows.Forms.Label Invalid_Lecture_Lable;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label F_ExitError;
        private System.Windows.Forms.Label EmptyMSG;
    }
}