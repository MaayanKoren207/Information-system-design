﻿namespace CYCLE
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EmployeesCRUD_Butt = new System.Windows.Forms.Button();
            this.LecturersCRUD_Butt = new System.Windows.Forms.Button();
            this.Products_CRUD_Butt = new System.Windows.Forms.Button();
            this.ApprenticesCRUD_Butt = new System.Windows.Forms.Button();
            this.SuppliersCRUD_Butt = new System.Windows.Forms.Button();
            this.Sessions_Butt = new System.Windows.Forms.Button();
            this.Lectures_Butt = new System.Windows.Forms.Button();
            this.DashBoard_Butt = new System.Windows.Forms.Button();
            this.LogOut_Butt = new System.Windows.Forms.Button();
            this.SortingTest_Butt = new System.Windows.Forms.Button();
            this.Assigning_Butt = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.Welcome_Lable = new System.Windows.Forms.Label();
            this.FullName = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // EmployeesCRUD_Butt
            // 
            this.EmployeesCRUD_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.EmployeesCRUD_Butt.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.EmployeesCRUD_Butt.ForeColor = System.Drawing.SystemColors.Control;
            this.EmployeesCRUD_Butt.Location = new System.Drawing.Point(899, 370);
            this.EmployeesCRUD_Butt.Name = "EmployeesCRUD_Butt";
            this.EmployeesCRUD_Butt.Size = new System.Drawing.Size(214, 73);
            this.EmployeesCRUD_Butt.TabIndex = 1;
            this.EmployeesCRUD_Butt.Text = "Employees";
            this.EmployeesCRUD_Butt.UseVisualStyleBackColor = false;
            this.EmployeesCRUD_Butt.Click += new System.EventHandler(this.EmployeesCRUD_Butt_Click_1);
            // 
            // LecturersCRUD_Butt
            // 
            this.LecturersCRUD_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.LecturersCRUD_Butt.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.LecturersCRUD_Butt.ForeColor = System.Drawing.SystemColors.Control;
            this.LecturersCRUD_Butt.Location = new System.Drawing.Point(899, 212);
            this.LecturersCRUD_Butt.Name = "LecturersCRUD_Butt";
            this.LecturersCRUD_Butt.Size = new System.Drawing.Size(214, 73);
            this.LecturersCRUD_Butt.TabIndex = 2;
            this.LecturersCRUD_Butt.Text = "Lecturers";
            this.LecturersCRUD_Butt.UseVisualStyleBackColor = false;
            this.LecturersCRUD_Butt.Click += new System.EventHandler(this.LecturersCRUD_Butt_Click);
            // 
            // Products_CRUD_Butt
            // 
            this.Products_CRUD_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Products_CRUD_Butt.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.Products_CRUD_Butt.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Products_CRUD_Butt.Location = new System.Drawing.Point(899, 133);
            this.Products_CRUD_Butt.Name = "Products_CRUD_Butt";
            this.Products_CRUD_Butt.Size = new System.Drawing.Size(214, 73);
            this.Products_CRUD_Butt.TabIndex = 3;
            this.Products_CRUD_Butt.Text = "Products";
            this.Products_CRUD_Butt.UseVisualStyleBackColor = false;
            this.Products_CRUD_Butt.Click += new System.EventHandler(this.Products_CRUD_Butt_Click);
            // 
            // ApprenticesCRUD_Butt
            // 
            this.ApprenticesCRUD_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.ApprenticesCRUD_Butt.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.ApprenticesCRUD_Butt.ForeColor = System.Drawing.SystemColors.Control;
            this.ApprenticesCRUD_Butt.Location = new System.Drawing.Point(899, 449);
            this.ApprenticesCRUD_Butt.Name = "ApprenticesCRUD_Butt";
            this.ApprenticesCRUD_Butt.Size = new System.Drawing.Size(214, 73);
            this.ApprenticesCRUD_Butt.TabIndex = 6;
            this.ApprenticesCRUD_Butt.Text = "Apprentices";
            this.ApprenticesCRUD_Butt.UseVisualStyleBackColor = false;
            this.ApprenticesCRUD_Butt.Click += new System.EventHandler(this.ApprenticesCRUD_Butt_Click);
            // 
            // SuppliersCRUD_Butt
            // 
            this.SuppliersCRUD_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.SuppliersCRUD_Butt.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.SuppliersCRUD_Butt.ForeColor = System.Drawing.SystemColors.Control;
            this.SuppliersCRUD_Butt.Location = new System.Drawing.Point(899, 291);
            this.SuppliersCRUD_Butt.Name = "SuppliersCRUD_Butt";
            this.SuppliersCRUD_Butt.Size = new System.Drawing.Size(214, 73);
            this.SuppliersCRUD_Butt.TabIndex = 5;
            this.SuppliersCRUD_Butt.Text = "Suppliers";
            this.SuppliersCRUD_Butt.UseVisualStyleBackColor = false;
            this.SuppliersCRUD_Butt.Click += new System.EventHandler(this.SuppliersCRUD_Butt_Click_1);
            // 
            // Sessions_Butt
            // 
            this.Sessions_Butt.BackColor = System.Drawing.Color.MediumPurple;
            this.Sessions_Butt.Font = new System.Drawing.Font("Calibri", 18F);
            this.Sessions_Butt.ForeColor = System.Drawing.SystemColors.Control;
            this.Sessions_Butt.Location = new System.Drawing.Point(360, 246);
            this.Sessions_Butt.Name = "Sessions_Butt";
            this.Sessions_Butt.Size = new System.Drawing.Size(202, 40);
            this.Sessions_Butt.TabIndex = 4;
            this.Sessions_Butt.Text = "Sessions";
            this.Sessions_Butt.UseVisualStyleBackColor = false;
            this.Sessions_Butt.Click += new System.EventHandler(this.Sessions_Butt_Click);
            // 
            // Lectures_Butt
            // 
            this.Lectures_Butt.BackColor = System.Drawing.Color.MediumPurple;
            this.Lectures_Butt.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Lectures_Butt.ForeColor = System.Drawing.SystemColors.Control;
            this.Lectures_Butt.Location = new System.Drawing.Point(595, 245);
            this.Lectures_Butt.Name = "Lectures_Butt";
            this.Lectures_Butt.Size = new System.Drawing.Size(202, 40);
            this.Lectures_Butt.TabIndex = 7;
            this.Lectures_Butt.Text = "Lectures";
            this.Lectures_Butt.UseVisualStyleBackColor = false;
            this.Lectures_Butt.Click += new System.EventHandler(this.Lectures_Butt_Click);
            // 
            // DashBoard_Butt
            // 
            this.DashBoard_Butt.BackColor = System.Drawing.Color.MediumPurple;
            this.DashBoard_Butt.Font = new System.Drawing.Font("Calibri", 18F);
            this.DashBoard_Butt.ForeColor = System.Drawing.SystemColors.Control;
            this.DashBoard_Butt.Location = new System.Drawing.Point(484, 447);
            this.DashBoard_Butt.Name = "DashBoard_Butt";
            this.DashBoard_Butt.Size = new System.Drawing.Size(202, 40);
            this.DashBoard_Butt.TabIndex = 8;
            this.DashBoard_Butt.Text = "Dashboard";
            this.DashBoard_Butt.UseVisualStyleBackColor = false;
            this.DashBoard_Butt.Click += new System.EventHandler(this.DashBoard_Butt_Click);
            // 
            // LogOut_Butt
            // 
            this.LogOut_Butt.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.LogOut_Butt.Font = new System.Drawing.Font("Calibri", 20.25F);
            this.LogOut_Butt.ForeColor = System.Drawing.Color.White;
            this.LogOut_Butt.Location = new System.Drawing.Point(12, 464);
            this.LogOut_Butt.Name = "LogOut_Butt";
            this.LogOut_Butt.Size = new System.Drawing.Size(140, 68);
            this.LogOut_Butt.TabIndex = 9;
            this.LogOut_Butt.Text = "LogOut";
            this.LogOut_Butt.UseVisualStyleBackColor = false;
            this.LogOut_Butt.Click += new System.EventHandler(this.LogOut_Butt_Click);
            // 
            // SortingTest_Butt
            // 
            this.SortingTest_Butt.BackColor = System.Drawing.Color.MediumPurple;
            this.SortingTest_Butt.Font = new System.Drawing.Font("Calibri", 18F);
            this.SortingTest_Butt.ForeColor = System.Drawing.SystemColors.Control;
            this.SortingTest_Butt.Location = new System.Drawing.Point(238, 447);
            this.SortingTest_Butt.Name = "SortingTest_Butt";
            this.SortingTest_Butt.Size = new System.Drawing.Size(202, 40);
            this.SortingTest_Butt.TabIndex = 10;
            this.SortingTest_Butt.Text = "Sorting Test";
            this.SortingTest_Butt.UseVisualStyleBackColor = false;
            this.SortingTest_Butt.Click += new System.EventHandler(this.SortingTest_Butt_Click);
            // 
            // Assigning_Butt
            // 
            this.Assigning_Butt.BackColor = System.Drawing.Color.MediumPurple;
            this.Assigning_Butt.Font = new System.Drawing.Font("Calibri", 18F);
            this.Assigning_Butt.ForeColor = System.Drawing.SystemColors.Control;
            this.Assigning_Butt.Location = new System.Drawing.Point(114, 246);
            this.Assigning_Butt.Name = "Assigning_Butt";
            this.Assigning_Butt.Size = new System.Drawing.Size(202, 40);
            this.Assigning_Butt.TabIndex = 11;
            this.Assigning_Butt.Text = "Assigning";
            this.Assigning_Butt.UseVisualStyleBackColor = false;
            this.Assigning_Butt.Click += new System.EventHandler(this.Assigning_Butt_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CYCLE.Properties.Resources.LOgo_קטן_מאוד;
            this.pictureBox2.Location = new System.Drawing.Point(1009, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(99, 101);
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = global::CYCLE.Properties.Resources.תמונות_לסשן;
            this.pictureBox1.Location = new System.Drawing.Point(360, 128);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(202, 115);
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.BackgroundImage = global::CYCLE.Properties.Resources.לוח_זמנים;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox3.Location = new System.Drawing.Point(114, 125);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(202, 115);
            this.pictureBox3.TabIndex = 15;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.BackgroundImage = global::CYCLE.Properties.Resources.הרצאה;
            this.pictureBox4.Location = new System.Drawing.Point(595, 125);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(202, 115);
            this.pictureBox4.TabIndex = 16;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.BackgroundImage = global::CYCLE.Properties.Resources.דשבורד;
            this.pictureBox5.Location = new System.Drawing.Point(484, 326);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(202, 115);
            this.pictureBox5.TabIndex = 17;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.BackgroundImage = global::CYCLE.Properties.Resources.מבחן;
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Location = new System.Drawing.Point(238, 326);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(202, 115);
            this.pictureBox6.TabIndex = 18;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // Welcome_Lable
            // 
            this.Welcome_Lable.AutoSize = true;
            this.Welcome_Lable.BackColor = System.Drawing.Color.Transparent;
            this.Welcome_Lable.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Welcome_Lable.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Welcome_Lable.Location = new System.Drawing.Point(262, 32);
            this.Welcome_Lable.Name = "Welcome_Lable";
            this.Welcome_Lable.Size = new System.Drawing.Size(219, 59);
            this.Welcome_Lable.TabIndex = 19;
            this.Welcome_Lable.Text = "Welcome ";
            // 
            // FullName
            // 
            this.FullName.AutoSize = true;
            this.FullName.BackColor = System.Drawing.Color.Transparent;
            this.FullName.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FullName.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.FullName.Location = new System.Drawing.Point(487, 32);
            this.FullName.Name = "FullName";
            this.FullName.Size = new System.Drawing.Size(210, 59);
            this.FullName.TabIndex = 20;
            this.FullName.Text = "FullName";
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.BackgroundImage = global::CYCLE.Properties.Resources.מסך_לעיצוב;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1120, 544);
            this.Controls.Add(this.FullName);
            this.Controls.Add(this.Welcome_Lable);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Assigning_Butt);
            this.Controls.Add(this.SortingTest_Butt);
            this.Controls.Add(this.LogOut_Butt);
            this.Controls.Add(this.DashBoard_Butt);
            this.Controls.Add(this.Lectures_Butt);
            this.Controls.Add(this.ApprenticesCRUD_Butt);
            this.Controls.Add(this.SuppliersCRUD_Butt);
            this.Controls.Add(this.Sessions_Butt);
            this.Controls.Add(this.Products_CRUD_Butt);
            this.Controls.Add(this.LecturersCRUD_Butt);
            this.Controls.Add(this.EmployeesCRUD_Butt);
            this.Name = "HomePage";
            this.Text = "0.";
            this.Load += new System.EventHandler(this.HomePage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button EmployeesCRUD_Butt;
        private System.Windows.Forms.Button LecturersCRUD_Butt;
        private System.Windows.Forms.Button Products_CRUD_Butt;
        private System.Windows.Forms.Button ApprenticesCRUD_Butt;
        private System.Windows.Forms.Button SuppliersCRUD_Butt;
        private System.Windows.Forms.Button Sessions_Butt;
        private System.Windows.Forms.Button Lectures_Butt;
        private System.Windows.Forms.Button DashBoard_Butt;
        private System.Windows.Forms.Button LogOut_Butt;
        private System.Windows.Forms.Button SortingTest_Butt;
        private System.Windows.Forms.Button Assigning_Butt;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label Welcome_Lable;
        private System.Windows.Forms.Label FullName;
    }
}